import { useState } from 'react';
import { ArrowLeft, Plus, Trash2, Edit2, Save, X } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface InteractiveExerciseAdminProps {
  onBack: () => void;
}

type ExerciseType = 'drag-drop' | 'ordering' | 'click' | 'matching' | 'simulation';

interface DragDropExercise {
  id: string;
  type: 'drag-drop';
  subject: 'math' | 'english' | 'ukrainian';
  level: number;
  title: string;
  categories: Array<{ id: string; name: string; color: string }>;
  items: Array<{ id: string; text: string; category: string; emoji: string }>;
}

interface OrderingExercise {
  id: string;
  type: 'ordering';
  subject: 'math' | 'english' | 'ukrainian';
  level: number;
  sentences: Array<{ sentence: string[]; emoji: string }>;
}

interface ClickObjectExercise {
  id: string;
  type: 'click';
  subject: 'math' | 'english' | 'ukrainian';
  level: number;
  questions: Array<{
    prompt: string;
    objects: Array<{
      id: string;
      emoji: string;
      label: string;
      isCorrect: boolean;
      position: { x: string; y: string };
    }>;
  }>;
}

interface MatchingExercise {
  id: string;
  type: 'matching';
  subject: 'math' | 'english' | 'ukrainian';
  level: number;
  title: string;
  pairs: Array<{
    id: string;
    left: string;
    right: string;
    leftEmoji: string;
    rightEmoji: string;
  }>;
}

interface SimulationExercise {
  id: string;
  type: 'simulation';
  subject: 'math' | 'english' | 'ukrainian';
  level: number;
  title: string;
  scenarios: Array<{
    id: string;
    title: string;
    description: string;
    emoji: string;
    choices: Array<{
      text: string;
      points: number;
      feedback: string;
      emoji: string;
    }>;
  }>;
}

type Exercise = DragDropExercise | OrderingExercise | ClickObjectExercise | MatchingExercise | SimulationExercise;

export function InteractiveExerciseAdmin({ onBack }: InteractiveExerciseAdminProps) {
  const { language } = useLanguage();
  const [selectedType, setSelectedType] = useState<ExerciseType>('drag-drop');
  const [exercises, setExercises] = useState<Exercise[]>(() => {
    const stored = localStorage.getItem('admin_interactive_exercises');
    return stored ? JSON.parse(stored) : [];
  });
  const [editingId, setEditingId] = useState<string | null>(null);

  const saveExercises = (newExercises: Exercise[]) => {
    setExercises(newExercises);
    localStorage.setItem('admin_interactive_exercises', JSON.stringify(newExercises));
  };

  const deleteExercise = (id: string) => {
    if (confirm(language === 'uk' ? 'Видалити цю вправу?' : 'Delete this exercise?')) {
      const updated = exercises.filter(e => e.id !== id);
      saveExercises(updated);
    }
  };

  const exerciseTypes = [
    {
      type: 'drag-drop' as ExerciseType,
      name: language === 'uk' ? 'Перетягування' : 'Drag & Drop',
      emoji: '🎯',
      description: language === 'uk' ? 'Розподіл за категоріями' : 'Categorize items',
    },
    {
      type: 'ordering' as ExerciseType,
      name: language === 'uk' ? 'Складання' : 'Ordering',
      emoji: '🧩',
      description: language === 'uk' ? 'Впорядкування речень' : 'Sentence ordering',
    },
    {
      type: 'click' as ExerciseType,
      name: language === 'uk' ? 'Клік на об\'єкт' : 'Click Object',
      emoji: '🔍',
      description: language === 'uk' ? 'Знайди правильний об\'єкт' : 'Find correct object',
    },
    {
      type: 'matching' as ExerciseType,
      name: language === 'uk' ? 'З\'єднування' : 'Matching',
      emoji: '🔗',
      description: language === 'uk' ? 'З\'єднай пари' : 'Match pairs',
    },
    {
      type: 'simulation' as ExerciseType,
      name: language === 'uk' ? 'Симуляція' : 'Simulation',
      emoji: '🎮',
      description: language === 'uk' ? 'Інтерактивні сценарії' : 'Interactive scenarios',
    },
  ];

  const filteredExercises = exercises.filter(e => e.type === selectedType);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-700 hover:text-gray-900 mb-6 font-semibold"
        >
          <ArrowLeft size={20} />
          {language === 'uk' ? 'Назад до адмін-панелі' : 'Back to Admin Panel'}
        </button>

        <div className="bg-white rounded-3xl shadow-2xl p-6 md:p-8 border-4 border-purple-200">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-800 mb-2">
            {language === 'uk' ? '🎨 Управління інтерактивними вправами' : '🎨 Interactive Exercise Management'}
          </h1>
          <p className="text-gray-600 mb-8">
            {language === 'uk'
              ? 'Створюйте та редагуйте різні типи інтерактивних вправ для учнів'
              : 'Create and edit different types of interactive exercises for students'}
          </p>
          
          {/* Info banner */}
          <div className="bg-gradient-to-r from-green-100 to-blue-100 border-4 border-green-300 rounded-2xl p-4 mb-8">
            <p className="text-center text-gray-800 font-semibold">
              ✨ {language === 'uk' 
                ? 'Вправи, які ви створюєте тут, будуть автоматично доступні для учнів у розділі вправ!' 
                : 'Exercises you create here will automatically be available to students in the exercise section!'}
            </p>
          </div>

          {/* Exercise Type Selection */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 mb-8">
            {exerciseTypes.map((type) => (
              <button
                key={type.type}
                onClick={() => setSelectedType(type.type)}
                className={`p-4 rounded-2xl border-4 transition-all ${
                  selectedType === type.type
                    ? 'bg-gradient-to-br from-purple-500 to-pink-500 text-white border-purple-300 shadow-lg scale-105'
                    : 'bg-white text-gray-800 border-gray-200 hover:border-purple-300'
                }`}
              >
                <div className="text-4xl mb-2">{type.emoji}</div>
                <div className="font-bold text-sm">{type.name}</div>
              </button>
            ))}
          </div>

          {/* Exercise Builder based on type */}
          {selectedType === 'drag-drop' && (
            <DragDropBuilder
              exercises={filteredExercises as DragDropExercise[]}
              onSave={(exercise) => {
                const updated = editingId
                  ? exercises.map(e => e.id === editingId ? exercise : e)
                  : [...exercises, exercise];
                saveExercises(updated);
                setEditingId(null);
              }}
              onDelete={deleteExercise}
              editingId={editingId}
              setEditingId={setEditingId}
            />
          )}

          {selectedType === 'ordering' && (
            <OrderingBuilder
              exercises={filteredExercises as OrderingExercise[]}
              onSave={(exercise) => {
                const updated = editingId
                  ? exercises.map(e => e.id === editingId ? exercise : e)
                  : [...exercises, exercise];
                saveExercises(updated);
                setEditingId(null);
              }}
              onDelete={deleteExercise}
              editingId={editingId}
              setEditingId={setEditingId}
            />
          )}

          {selectedType === 'click' && (
            <ClickObjectBuilder
              exercises={filteredExercises as ClickObjectExercise[]}
              onSave={(exercise) => {
                const updated = editingId
                  ? exercises.map(e => e.id === editingId ? exercise : e)
                  : [...exercises, exercise];
                saveExercises(updated);
                setEditingId(null);
              }}
              onDelete={deleteExercise}
              editingId={editingId}
              setEditingId={setEditingId}
            />
          )}

          {selectedType === 'matching' && (
            <MatchingBuilder
              exercises={filteredExercises as MatchingExercise[]}
              onSave={(exercise) => {
                const updated = editingId
                  ? exercises.map(e => e.id === editingId ? exercise : e)
                  : [...exercises, exercise];
                saveExercises(updated);
                setEditingId(null);
              }}
              onDelete={deleteExercise}
              editingId={editingId}
              setEditingId={setEditingId}
            />
          )}

          {selectedType === 'simulation' && (
            <SimulationBuilder
              exercises={filteredExercises as SimulationExercise[]}
              onSave={(exercise) => {
                const updated = editingId
                  ? exercises.map(e => e.id === editingId ? exercise : e)
                  : [...exercises, exercise];
                saveExercises(updated);
                setEditingId(null);
              }}
              onDelete={deleteExercise}
              editingId={editingId}
              setEditingId={setEditingId}
            />
          )}
        </div>
      </div>
    </div>
  );
}

// Drag & Drop Builder Component
function DragDropBuilder({
  exercises,
  onSave,
  onDelete,
  editingId,
  setEditingId,
}: {
  exercises: DragDropExercise[];
  onSave: (exercise: DragDropExercise) => void;
  onDelete: (id: string) => void;
  editingId: string | null;
  setEditingId: (id: string | null) => void;
}) {
  const { language } = useLanguage();
  const [formData, setFormData] = useState<DragDropExercise>({
    id: Date.now().toString(),
    type: 'drag-drop',
    subject: 'math',
    level: 1,
    title: '',
    categories: [
      { id: '1', name: '', color: 'bg-gradient-to-br from-blue-400 to-blue-600' },
      { id: '2', name: '', color: 'bg-gradient-to-br from-purple-400 to-purple-600' },
    ],
    items: [
      { id: '1', text: '', category: '1', emoji: '' },
      { id: '2', text: '', category: '2', emoji: '' },
    ],
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title || formData.categories.some(c => !c.name) || formData.items.some(i => !i.text)) {
      alert(language === 'uk' ? 'Заповніть всі поля!' : 'Fill in all fields!');
      return;
    }
    onSave(formData);
    setFormData({
      id: Date.now().toString(),
      type: 'drag-drop',
      subject: 'math',
      level: 1,
      title: '',
      categories: [
        { id: '1', name: '', color: 'bg-gradient-to-br from-blue-400 to-blue-600' },
        { id: '2', name: '', color: 'bg-gradient-to-br from-purple-400 to-purple-600' },
      ],
      items: [
        { id: '1', text: '', category: '1', emoji: '' },
        { id: '2', text: '', category: '2', emoji: '' },
      ],
    });
  };

  const addCategory = () => {
    const newId = (formData.categories.length + 1).toString();
    setFormData({
      ...formData,
      categories: [
        ...formData.categories,
        { id: newId, name: '', color: 'bg-gradient-to-br from-green-400 to-green-600' },
      ],
    });
  };

  const addItem = () => {
    const newId = (formData.items.length + 1).toString();
    setFormData({
      ...formData,
      items: [...formData.items, { id: newId, text: '', category: '1', emoji: '' }],
    });
  };

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-800 mb-6">
        {language === 'uk' ? '🎯 Конструктор перетягування' : '🎯 Drag & Drop Builder'}
      </h2>

      {/* Form */}
      <form onSubmit={handleSubmit} className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl p-6 mb-6 border-4 border-purple-200">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">
              {language === 'uk' ? 'Предмет' : 'Subject'}
            </label>
            <select
              value={formData.subject}
              onChange={(e) => setFormData({ ...formData, subject: e.target.value as any })}
              className="w-full p-3 rounded-xl border-2 border-purple-300 focus:border-purple-500 outline-none"
            >
              <option value="math">{language === 'uk' ? 'Математика' : 'Math'}</option>
              <option value="english">{language === 'uk' ? 'Англійська' : 'English'}</option>
              <option value="ukrainian">{language === 'uk' ? 'Українська' : 'Ukrainian'}</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">
              {language === 'uk' ? 'Рівень' : 'Level'}
            </label>
            <input
              type="number"
              min="1"
              max="10"
              value={formData.level}
              onChange={(e) => setFormData({ ...formData, level: parseInt(e.target.value) })}
              className="w-full p-3 rounded-xl border-2 border-purple-300 focus:border-purple-500 outline-none"
            />
          </div>
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">
              {language === 'uk' ? 'Назва' : 'Title'}
            </label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              className="w-full p-3 rounded-xl border-2 border-purple-300 focus:border-purple-500 outline-none"
              placeholder={language === 'uk' ? 'Назва вправи' : 'Exercise title'}
            />
          </div>
        </div>

        {/* Categories */}
        <div className="mb-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-bold text-gray-800">
              {language === 'uk' ? 'Категорії' : 'Categories'}
            </h3>
            <button
              type="button"
              onClick={addCategory}
              className="bg-green-500 text-white px-4 py-2 rounded-xl font-bold hover:bg-green-600 flex items-center gap-2"
            >
              <Plus size={20} />
              {language === 'uk' ? 'Додати' : 'Add'}
            </button>
          </div>
          {formData.categories.map((category, index) => (
            <div key={category.id} className="flex gap-4 mb-3">
              <input
                type="text"
                value={category.name}
                onChange={(e) => {
                  const updated = [...formData.categories];
                  updated[index].name = e.target.value;
                  setFormData({ ...formData, categories: updated });
                }}
                className="flex-1 p-3 rounded-xl border-2 border-purple-300 focus:border-purple-500 outline-none"
                placeholder={language === 'uk' ? `Категорія ${index + 1}` : `Category ${index + 1}`}
              />
              <button
                type="button"
                onClick={() => {
                  const updated = formData.categories.filter((_, i) => i !== index);
                  setFormData({ ...formData, categories: updated });
                }}
                className="bg-red-500 text-white px-4 py-2 rounded-xl hover:bg-red-600"
              >
                <Trash2 size={20} />
              </button>
            </div>
          ))}
        </div>

        {/* Items */}
        <div className="mb-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-bold text-gray-800">
              {language === 'uk' ? 'Елементи' : 'Items'}
            </h3>
            <button
              type="button"
              onClick={addItem}
              className="bg-green-500 text-white px-4 py-2 rounded-xl font-bold hover:bg-green-600 flex items-center gap-2"
            >
              <Plus size={20} />
              {language === 'uk' ? 'Додати' : 'Add'}
            </button>
          </div>
          {formData.items.map((item, index) => (
            <div key={item.id} className="grid grid-cols-1 md:grid-cols-4 gap-3 mb-3">
              <input
                type="text"
                value={item.text}
                onChange={(e) => {
                  const updated = [...formData.items];
                  updated[index].text = e.target.value;
                  setFormData({ ...formData, items: updated });
                }}
                className="p-3 rounded-xl border-2 border-purple-300 focus:border-purple-500 outline-none"
                placeholder={language === 'uk' ? 'Текст' : 'Text'}
              />
              <input
                type="text"
                value={item.emoji}
                onChange={(e) => {
                  const updated = [...formData.items];
                  updated[index].emoji = e.target.value;
                  setFormData({ ...formData, items: updated });
                }}
                className="p-3 rounded-xl border-2 border-purple-300 focus:border-purple-500 outline-none"
                placeholder="🎯 Emoji"
              />
              <select
                value={item.category}
                onChange={(e) => {
                  const updated = [...formData.items];
                  updated[index].category = e.target.value;
                  setFormData({ ...formData, items: updated });
                }}
                className="p-3 rounded-xl border-2 border-purple-300 focus:border-purple-500 outline-none"
              >
                {formData.categories.map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.name || `Category ${cat.id}`}
                  </option>
                ))}
              </select>
              <button
                type="button"
                onClick={() => {
                  const updated = formData.items.filter((_, i) => i !== index);
                  setFormData({ ...formData, items: updated });
                }}
                className="bg-red-500 text-white px-4 py-2 rounded-xl hover:bg-red-600"
              >
                <Trash2 size={20} />
              </button>
            </div>
          ))}
        </div>

        <button
          type="submit"
          className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white font-bold py-4 rounded-xl hover:shadow-lg transition-all flex items-center justify-center gap-2"
        >
          <Save size={24} />
          {language === 'uk' ? 'Зберегти вправу' : 'Save Exercise'}
        </button>
      </form>

      {/* List of existing exercises */}
      <div className="space-y-4">
        <h3 className="text-xl font-bold text-gray-800">
          {language === 'uk' ? 'Створені вправи' : 'Created Exercises'}
        </h3>
        {exercises.length === 0 ? (
          <p className="text-gray-600 text-center py-8">
            {language === 'uk' ? 'Немає створених вправ' : 'No exercises created yet'}
          </p>
        ) : (
          exercises.map((exercise) => (
            <div
              key={exercise.id}
              className="bg-white rounded-xl p-4 border-2 border-gray-200 flex justify-between items-center"
            >
              <div>
                <h4 className="font-bold text-lg">{exercise.title}</h4>
                <p className="text-sm text-gray-600">
                  {exercise.subject.toUpperCase()} - Level {exercise.level}
                </p>
                <p className="text-xs text-gray-500">
                  {exercise.items.length} items, {exercise.categories.length} categories
                </p>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => {
                    setFormData(exercise);
                    setEditingId(exercise.id);
                  }}
                  className="bg-blue-500 text-white px-4 py-2 rounded-xl hover:bg-blue-600"
                >
                  <Edit2 size={20} />
                </button>
                <button
                  onClick={() => onDelete(exercise.id)}
                  className="bg-red-500 text-white px-4 py-2 rounded-xl hover:bg-red-600"
                >
                  <Trash2 size={20} />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

// Similar builder components for other exercise types (abbreviated for brevity)
// OrderingBuilder, ClickObjectBuilder, MatchingBuilder, SimulationBuilder would follow the same pattern
// I'll create placeholder components for now

function OrderingBuilder(props: any) {
  const { language } = useLanguage();
  return (
    <div className="text-center py-12">
      <p className="text-2xl">🧩 {language === 'uk' ? 'Конструктор складання речень' : 'Sentence Ordering Builder'}</p>
      <p className="text-gray-600 mt-4">{language === 'uk' ? 'Функціонал в розробці...' : 'Coming soon...'}</p>
    </div>
  );
}

function ClickObjectBuilder(props: any) {
  const { language } = useLanguage();
  return (
    <div className="text-center py-12">
      <p className="text-2xl">🔍 {language === 'uk' ? 'Конструктор пошуку об\'єктів' : 'Click Object Builder'}</p>
      <p className="text-gray-600 mt-4">{language === 'uk' ? 'Функціонал в розробці...' : 'Coming soon...'}</p>
    </div>
  );
}

function MatchingBuilder(props: any) {
  const { language } = useLanguage();
  return (
    <div className="text-center py-12">
      <p className="text-2xl">🔗 {language === 'uk' ? 'Конструктор з\'єднування' : 'Matching Builder'}</p>
      <p className="text-gray-600 mt-4">{language === 'uk' ? 'Функціонал в розробці...' : 'Coming soon...'}</p>
    </div>
  );
}

function SimulationBuilder(props: any) {
  const { language } = useLanguage();
  return (
    <div className="text-center py-12">
      <p className="text-2xl">🎮 {language === 'uk' ? 'Конструктор симуляцій' : 'Simulation Builder'}</p>
      <p className="text-gray-600 mt-4">{language === 'uk' ? 'Функціонал в розробці...' : 'Coming soon...'}</p>
    </div>
  );
}