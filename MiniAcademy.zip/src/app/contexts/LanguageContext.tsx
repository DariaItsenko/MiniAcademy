import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

type Language = 'en' | 'uk';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const translations: Record<Language, Record<string, string>> = {
  en: {
    // Auth Screen
    'auth.welcome': 'Welcome back!',
    'auth.createAccount': 'Create your account',
    'auth.username': 'Username',
    'auth.password': 'Password',
    'auth.enterUsername': 'Enter your username',
    'auth.enterPassword': 'Enter your password',
    'auth.login': 'Login',
    'auth.signup': 'Sign Up',
    'auth.noAccount': "Don't have an account? Sign up",
    'auth.hasAccount': 'Already have an account? Login',
    'auth.selectGrade': 'Select Your Grade',
    'auth.fillAllFields': 'Please fill in all fields',
    'auth.invalidCredentials': 'Invalid username or password',
    'auth.usernameExists': 'Username already exists',
    'auth.email': 'Email Address',
    'auth.enterEmail': 'Enter your email',
    'auth.age': 'Age',
    'auth.selectAge': 'Select your age',
    
    // Home Screen
    'home.title': 'Elementary Learning Hub',
    'home.subtitle': 'Choose your subject to start learning!',
    'home.logout': 'Logout',
    'home.admin': 'Admin',
    'home.tagline': 'Perfect for elementary grades • Interactive learning • Expert instructors',
    
    // Subjects
    'subject.math': 'Math',
    'subject.english': 'English',
    'subject.ukrainian': 'Ukrainian',
    
    // Account Page
    'account.title': "'s Account",
    'account.subtitle': 'Learning Progress & Grades',
    'account.overallGrade': 'Overall Grade',
    'account.totalStars': 'Total Stars',
    'account.gradingScale': '12-Point Grading Scale',
    'account.backToHome': 'Back to Home',
    'account.changeGrade': 'Change Grade',
    'account.currentGrade': 'Current Grade',
    'account.excellent': 'Excellent',
    'account.veryGood': 'Very Good',
    'account.good': 'Good',
    'account.satisfactory': 'Satisfactory',
    'account.sufficient': 'Sufficient',
    'account.needsImprovement': 'Needs Improvement',
    
    // Levels - Math
    'level.math.1.title': 'Addition & Subtraction',
    'level.math.1.desc': 'Master basic addition and subtraction with numbers up to 100',
    'level.math.2.title': 'Multiplication Tables',
    'level.math.2.desc': 'Learn multiplication tables from 1 to 10',
    'level.math.3.title': 'Division Basics',
    'level.math.3.desc': 'Understand division and solve simple division problems',
    'level.math.4.title': 'Advanced Problem Solving',
    'level.math.4.desc': 'Apply all operations to solve word problems',
    
    // Levels - English
    'level.english.1.title': 'Alphabet & Phonics',
    'level.english.1.desc': 'Learn letter sounds and simple word formation',
    'level.english.2.title': 'Reading Simple Sentences',
    'level.english.2.desc': 'Practice reading and understanding basic sentences',
    'level.english.3.title': 'Story Writing',
    'level.english.3.desc': 'Create your own short stories with proper structure',
    'level.english.4.title': 'Advanced Grammar',
    'level.english.4.desc': 'Master punctuation, tenses, and sentence structure',
    
    // Webinar
    'webinar.backToSubject': 'Back to Subject',
    'webinar.liveWebinar': 'Live Webinar',
    'webinar.date': 'Date',
    'webinar.time': 'Time',
    'webinar.students': 'Students',
    'webinar.enrolled': 'enrolled',
    'webinar.level': 'Level',
    'webinar.about': 'About This Webinar',
    'webinar.objectives': 'Learning Objectives',
    'webinar.agenda': 'Webinar Agenda',
    'webinar.instructor': 'Instructor',
    'webinar.expertTeacher': 'Expert Teacher',
    'webinar.materials': 'Materials Needed',
    'webinar.join': 'Join Webinar',
    'webinar.registered': "You're Registered",
    'webinar.reminder': "We'll send you a reminder",
    'webinar.startsOn': 'Live Session Starts on',
    
    // Subject View
    'subjectView.backToHome': 'Back to Home',
    'subjectView.upcomingWebinars': 'Upcoming Webinars',
    'subjectView.learningPath': 'Learning Path',
    'subjectView.level': 'Level',
    'subjectView.locked': 'Locked',
    'subjectView.start': 'Start',
    'subjectView.continue': 'Continue',
    'subjectView.completed': 'Completed',
    'subjectView.watchVideo': 'Watch Explanation',
    'subjectView.videoExplanation': 'Video Explanation',
    'subjectView.close': 'Close',
    
    // Exercise
    'exercise.level': 'Level',
    'exercise.question': 'Question',
    'exercise.submit': 'Submit',
    'exercise.nextQuestion': 'Next Question',
    'exercise.finish': 'Finish Exercise',
    'exercise.congratulations': 'Congratulations!',
    'exercise.completed': "You've completed Level",
    'exercise.earned': 'You earned',
    'exercise.stars': 'stars',
    'exercise.backToLevels': 'Back to Levels',
    
    // Grades
    'grade.1': 'Grade 1',
    'grade.2': 'Grade 2',
    'grade.3': 'Grade 3',
    'grade.4': 'Grade 4',
    'grade.5': 'Grade 5',
    
    // Account Page - Badges and Features
    'account.achievementsAndBadges': 'Achievements & Badges',
    'account.learningProgress': 'Learning Progress',
    'account.starsEarned': 'Stars Earned',
    'account.dayStreak': 'Day Streak',
    'account.avatarShop': 'Avatar Shop',
    'account.parentProgressReports': 'Parent Progress Reports',
    'account.parentEmail': "Parent's Email Address",
    'account.parentEmailDescription': '📨 Weekly progress reports will be sent to this email automatically!',
    'account.save': 'Save',
    'account.emailConfigured': 'Email Configured',
    'account.reportsWillBeSent': 'Reports will be sent to:',
    'account.lastReportSent': 'Last report sent:',
    'account.sendReportNow': 'Send Report Now',
    'account.reportIncludes': 'Report includes:',
    'account.totalStarsEarned': 'Total stars earned',
    'account.overallGradeNum': 'Overall grade',
    'account.currentStreak': 'Current streak',
    'account.pointsEarned': 'Points earned',
    'account.progressAllSubjects': 'Progress in all subjects',
    'account.achievementsBadges': 'Achievements & badges earned',
    'account.earned': 'Earned!',
    'account.locked': 'Locked',
    
    // Topic Groups & Subtopics
    'topic.chooseToStart': 'Choose a topic to start learning!',
    'topic.backToTopics': 'Back to Topics',
    'topic.videos': 'videos',
    'topic.exercises': 'exercises',
    'topic.watchNow': 'Watch Now',
    'topic.videoPlayer': 'Video Player',
    'topic.noVideosYet': 'No videos available yet. Check back soon!',
    'topic.readingMaterial': 'Reading Material',
    'topic.keyPoints': 'Key Points to Remember:',
    'topic.examples': 'Examples:',
    'topic.noLecturesYet': 'No lectures available yet. Check back soon!',
    'topic.workedExamples': 'Worked Examples',
    'topic.problem': 'Problem:',
    'topic.stepByStep': 'Step-by-Step Solution:',
    'topic.finalAnswer': 'Final Answer:',
    'topic.helpfulTips': 'Helpful Tips:',
    'topic.noExamplesYet': 'No worked examples available yet. Check back soon!',
    'topic.practiceExercises': 'Practice Exercises',
    'topic.readyToTest': 'Ready to test your knowledge?',
    'topic.completeExercises': 'interactive exercises with hints and animations!',
    'topic.startExercises': 'Start Exercises',
    'topic.exercise': 'Exercise',
    
    // Enhanced Exercise View
    'enhancedExercise.backToLessons': 'Back to Lessons',
    'enhancedExercise.questionOf': 'Question',
    'enhancedExercise.of': 'of',
    'enhancedExercise.questionTime': 'Question Time!',
    'enhancedExercise.checkAnswer': 'Check Answer',
    'enhancedExercise.nextQuestion': 'Next Question',
    'enhancedExercise.finish': 'Finish!',
    'enhancedExercise.hint': 'Hint:',
    'enhancedExercise.correct': 'Correct!',
    'enhancedExercise.notQuite': 'Not quite!',
    'enhancedExercise.funFact': 'Fun Fact:',
    'enhancedExercise.amazingWork': 'Amazing Work!',
    'enhancedExercise.youCompleted': 'You completed',
    'enhancedExercise.yourScore': 'Your Score:',
    'enhancedExercise.continueLearning': 'Continue Learning',
    'enhancedExercise.leftColumn': 'Left Column',
    'enhancedExercise.rightColumn': 'Right Column',
    
    // Avatar Shop
    'avatarShop.title': 'Avatar Shop',
    'avatarShop.yourPoints': 'Your Points',
    'avatarShop.hair': 'Hair',
    'avatarShop.clothes': 'Clothes',
    'avatarShop.accessories': 'Accessories',
    'avatarShop.skin': 'Skin',
    'avatarShop.owned': 'Owned',
    'avatarShop.equipped': 'Equipped',
    'avatarShop.buy': 'Buy',
    'avatarShop.equip': 'Equip',
    'avatarShop.unequip': 'Unequip',
    'avatarShop.notEnoughPoints': 'Not enough points',
    'avatarShop.backToAccount': 'Back to Account',
  },
  uk: {
    // Auth Screen
    'auth.welcome': 'З поверненням!',
    'auth.createAccount': 'Створіть обліковий запис',
    'auth.username': "Ім'я користувача",
    'auth.password': 'Пароль',
    'auth.enterUsername': "Введіть ім'я користувача",
    'auth.enterPassword': 'Введіть пароль',
    'auth.login': 'Увійти',
    'auth.signup': 'Зареєструватися',
    'auth.noAccount': 'Немає облікового запису? Зареєструйтеся',
    'auth.hasAccount': 'Вже є обліковий запис? Увійдіть',
    'auth.selectGrade': 'Оберіть ваш клас',
    'auth.fillAllFields': "Будь ласка, заповніть всі поля",
    'auth.invalidCredentials': "Невірне ім'я користувача або пароль",
    'auth.usernameExists': "Ім'я користувача вже існує",
    'auth.email': 'Email адреса',
    'auth.enterEmail': 'Введіть ваш email',
    'auth.age': 'Вік',
    'auth.selectAge': 'Оберіть ваш вік',
    
    // Home Screen
    'home.title': 'Навчальний центр початкової школи',
    'home.subtitle': 'Оберіть предмет для початку навчання!',
    'home.logout': 'Вийти',
    'home.admin': 'Адміністратор',
    'home.tagline': 'Для учнів початкової школи • Інтерактивне навчання • Експерти-викладачі',
    
    // Subjects
    'subject.math': 'Математика',
    'subject.english': 'Англійська',
    'subject.ukrainian': 'Українська',
    
    // Account Page
    'account.title': ' - Обліковий запис',
    'account.subtitle': 'Навчальний прогрес та оцінки',
    'account.overallGrade': 'Загальна оцінка',
    'account.totalStars': 'Всього зірок',
    'account.gradingScale': '12-бальна шкала оцінювання',
    'account.backToHome': 'Назад на головну',
    'account.changeGrade': 'Змінити клас',
    'account.currentGrade': 'Поточний клас',
    'account.excellent': 'Відмінно',
    'account.veryGood': 'Дуже добре',
    'account.good': 'Добре',
    'account.satisfactory': 'Задовільно',
    'account.sufficient': 'Достатньо',
    'account.needsImprovement': 'Потребує покращення',
    
    // Levels - Math
    'level.math.1.title': 'Додавання та віднімання',
    'level.math.1.desc': 'Опануйте базове додавання та віднімання з числами до 100',
    'level.math.2.title': 'Таблиця множення',
    'level.math.2.desc': 'Вивчіть таблицю множення від 1 до 10',
    'level.math.3.title': 'Основи ділення',
    'level.math.3.desc': 'Зрозумійте ділення та розв\'яжіть прості задачі на ділення',
    'level.math.4.title': 'Складне розв\'язання задач',
    'level.math.4.desc': 'Застосуйте всі операції для розв\'язання текстових задач',
    
    // Levels - English
    'level.english.1.title': 'Алфавіт та фонетика',
    'level.english.1.desc': 'Вивчіть звуки літер та просте словотворення',
    'level.english.2.title': 'Читання простих речень',
    'level.english.2.desc': 'Практикуйте читання та розуміння базових речень',
    'level.english.3.title': 'Написання оповідань',
    'level.english.3.desc': 'Створіть власні короткі оповідання з правильною структурою',
    'level.english.4.title': 'Поглиблена граматика',
    'level.english.4.desc': 'Опануйте пунктуацію, часи та структуру речень',
    
    // Webinar
    'webinar.backToSubject': 'Назад до предмета',
    'webinar.liveWebinar': 'Вебінар наживо',
    'webinar.date': 'Дата',
    'webinar.time': 'Час',
    'webinar.students': 'Учні',
    'webinar.enrolled': 'зареєстровані',
    'webinar.level': 'Рівень',
    'webinar.about': 'Про цей вебінар',
    'webinar.objectives': 'Навчальні цілі',
    'webinar.agenda': 'Програма вебінару',
    'webinar.instructor': 'Викладач',
    'webinar.expertTeacher': 'Експерт-викладач',
    'webinar.materials': 'Необхідні матеріали',
    'webinar.join': 'Приєднатися до вебінару',
    'webinar.registered': 'Ви зареєстровані',
    'webinar.reminder': 'Ми надішлемо вам нагадування',
    'webinar.startsOn': 'Онлайн заняття починається',
    
    // Subject View
    'subjectView.backToHome': 'Назад на головну',
    'subjectView.upcomingWebinars': 'Майбутні вебінари',
    'subjectView.learningPath': 'Шлях навчання',
    'subjectView.level': 'Рівень',
    'subjectView.locked': 'Заблоковано',
    'subjectView.start': 'Почати',
    'subjectView.continue': 'Продовжити',
    'subjectView.completed': 'Завершено',
    'subjectView.watchVideo': 'Дивитися пояснення',
    'subjectView.videoExplanation': 'Відео пояснення',
    'subjectView.close': 'Закрити',
    
    // Exercise
    'exercise.level': 'Рівень',
    'exercise.question': 'Запитання',
    'exercise.submit': 'Відправити',
    'exercise.nextQuestion': 'Наступне запитання',
    'exercise.finish': 'Завершити вправу',
    'exercise.congratulations': 'Вітаємо!',
    'exercise.completed': 'Ви завершили рівень',
    'exercise.earned': 'Ви заробили',
    'exercise.stars': 'зірок',
    'exercise.backToLevels': 'Назад до рівнів',
    
    // Grades
    'grade.1': '1 клас',
    'grade.2': '2 клас',
    'grade.3': '3 клас',
    'grade.4': '4 клас',
    'grade.5': '5 клас',
    
    // Account Page - Badges and Features
    'account.achievementsAndBadges': 'Досягнення та нагороди',
    'account.learningProgress': 'Навчальний прогрес',
    'account.starsEarned': 'Зірок зібрано',
    'account.dayStreak': 'Дні підряд',
    'account.avatarShop': 'Магазин аватарів',
    'account.parentProgressReports': 'Звіти про прогрес для батьків',
    'account.parentEmail': 'Email батьків',
    'account.parentEmailDescription': '📨 Щотижневі звіти будуть надсилатися на цей email автоматично!',
    'account.save': 'Зберегти',
    'account.emailConfigured': 'Email налаштовано',
    'account.reportsWillBeSent': 'Звіти надсилатимуться на:',
    'account.lastReportSent': 'Останній звіт надіслано:',
    'account.sendReportNow': 'Надіслати звіт зараз',
    'account.reportIncludes': 'Звіт включає:',
    'account.totalStarsEarned': 'Всього зірок зібрано',
    'account.overallGradeNum': 'Загальна оцінка',
    'account.currentStreak': 'Поточна серія',
    'account.pointsEarned': 'Балів зароблено',
    'account.progressAllSubjects': 'Прогрес у всіх предметах',
    'account.achievementsBadges': 'Досягнення та нагороди',
    'account.earned': 'Отримано!',
    'account.locked': 'Заблоковано',
    
    // Topic Groups & Subtopics
    'topic.chooseToStart': 'Оберіть тему для початку навчання!',
    'topic.backToTopics': 'Назад до тем',
    'topic.videos': 'відео',
    'topic.exercises': 'вправи',
    'topic.watchNow': 'Дивитись зараз',
    'topic.videoPlayer': 'Відео програвач',
    'topic.noVideosYet': 'Відео ще немає. Зверніться пізніше!',
    'topic.readingMaterial': 'Матеріали для читання',
    'topic.keyPoints': 'Ключові моменти для запам\'ятовування:',
    'topic.examples': 'Приклади:',
    'topic.noLecturesYet': 'Лекцій ще немає. Зверніться пізніше!',
    'topic.workedExamples': 'Розібрані приклади',
    'topic.problem': 'Задача:',
    'topic.stepByStep': 'Покрокове розв\'язання:',
    'topic.finalAnswer': 'Кінцева відповідь:',
    'topic.helpfulTips': 'Корисні поради:',
    'topic.noExamplesYet': 'Прикладів ще немає. Зверніться пізніше!',
    'topic.practiceExercises': 'Практичні вправи',
    'topic.readyToTest': 'Готові перевірити свої знання?',
    'topic.completeExercises': 'інтерактивні вправи з підказками та анімаціями!',
    'topic.startExercises': 'Почати вправи',
    'topic.exercise': 'Вправа',
    
    // Enhanced Exercise View
    'enhancedExercise.backToLessons': 'Назад до уроків',
    'enhancedExercise.questionOf': 'Питання',
    'enhancedExercise.of': 'з',
    'enhancedExercise.questionTime': 'Час питання!',
    'enhancedExercise.checkAnswer': 'Перевірити відповідь',
    'enhancedExercise.nextQuestion': 'Наступне питання',
    'enhancedExercise.finish': 'Завершити!',
    'enhancedExercise.hint': 'Підказка:',
    'enhancedExercise.correct': 'Правильно!',
    'enhancedExercise.notQuite': 'Не зовсім!',
    'enhancedExercise.funFact': 'Цікавий факт:',
    'enhancedExercise.amazingWork': 'Чудова робота!',
    'enhancedExercise.youCompleted': 'Ви завершили',
    'enhancedExercise.yourScore': 'Ваш результат:',
    'enhancedExercise.continueLearning': 'Продовжити навчання',
    'enhancedExercise.leftColumn': 'Ліва колонка',
    'enhancedExercise.rightColumn': 'Права колонка',
    
    // Avatar Shop
    'avatarShop.title': 'Магазин аватарів',
    'avatarShop.yourPoints': 'Ваші бали',
    'avatarShop.hair': 'Волосся',
    'avatarShop.clothes': 'Одяг',
    'avatarShop.accessories': 'Аксесуари',
    'avatarShop.skin': 'Шкіра',
    'avatarShop.owned': 'Куплено',
    'avatarShop.equipped': 'Надіто',
    'avatarShop.buy': 'Купити',
    'avatarShop.equip': 'Надіти',
    'avatarShop.unequip': 'Зняти',
    'avatarShop.notEnoughPoints': 'Недостатньо балів',
    'avatarShop.backToAccount': 'Назад до облікового запису',
  },
};

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem('elementary_language');
    return (saved === 'uk' ? 'uk' : 'en') as Language;
  });

  useEffect(() => {
    localStorage.setItem('elementary_language', language);
  }, [language]);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
  };

  const t = (key: string): string => {
    const translation = translations[language]?.[key];
    if (typeof translation === 'string') {
      return translation;
    }
    console.warn(`Translation key not found or invalid: ${key}, language: ${language}`);
    return key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}