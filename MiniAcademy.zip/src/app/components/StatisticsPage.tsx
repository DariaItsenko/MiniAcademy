import { ArrowLeft, TrendingUp, TrendingDown, Target, Clock, Award, Calendar, Activity } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface LevelData {
  completed: boolean;
  stars: number;
  accuracy?: number;
  completedAt?: string;
  attempts?: number;
  timeSpent?: number; // in seconds
}

interface UserProgress {
  math: { levels: LevelData[] };
  english: { levels: LevelData[] };
  ukrainian: { levels: LevelData[] };
}

interface ActivityLog {
  date: string;
  subject: string;
  level: number;
  stars: number;
  accuracy: number;
}

interface StatisticsPageProps {
  username: string;
  progress: UserProgress;
  grade: number;
  streak: number;
  points: number;
  activityLog?: ActivityLog[];
  onBack: () => void;
}

export function StatisticsPage({
  username,
  progress,
  grade,
  streak,
  points,
  activityLog = [],
  onBack,
}: StatisticsPageProps) {
  const { t, language } = useLanguage();

  // Calculate statistics
  const calculateSubjectStats = (subjectData: { levels: LevelData[] }) => {
    const completed = subjectData.levels.filter(l => l.completed).length;
    const total = subjectData.levels.length;
    const stars = subjectData.levels.reduce((acc, l) => acc + l.stars, 0);
    const maxStars = total * 3;
    const avgAccuracy = subjectData.levels.filter(l => l.accuracy).reduce((acc, l) => acc + (l.accuracy || 0), 0) / 
                        Math.max(1, subjectData.levels.filter(l => l.accuracy).length);
    
    return {
      completed,
      total,
      percentage: Math.round((completed / total) * 100),
      stars,
      maxStars,
      starPercentage: Math.round((stars / maxStars) * 100),
      avgAccuracy: Math.round(avgAccuracy || 0),
    };
  };

  const mathStats = calculateSubjectStats(progress.math);
  const englishStats = calculateSubjectStats(progress.english);
  const ukrainianStats = calculateSubjectStats(progress.ukrainian);

  const totalCompleted = mathStats.completed + englishStats.completed + ukrainianStats.completed;
  const totalLevels = mathStats.total + englishStats.total + ukrainianStats.total;
  const totalStars = mathStats.stars + englishStats.stars + ukrainianStats.stars;
  const maxTotalStars = mathStats.maxStars + englishStats.maxStars + ukrainianStats.maxStars;
  const overallProgress = Math.round((totalCompleted / totalLevels) * 100);
  const overallAccuracy = Math.round((mathStats.avgAccuracy + englishStats.avgAccuracy + ukrainianStats.avgAccuracy) / 3);

  // Data for charts
  const subjectComparisonData = [
    { 
      id: 'math',
      name: language === 'uk' ? 'Математика' : 'Math', 
      progress: mathStats.percentage, 
      stars: mathStats.stars,
      accuracy: mathStats.avgAccuracy,
    },
    { 
      id: 'english',
      name: language === 'uk' ? 'Англійська' : 'English', 
      progress: englishStats.percentage, 
      stars: englishStats.stars,
      accuracy: englishStats.avgAccuracy,
    },
    { 
      id: 'ukrainian',
      name: language === 'uk' ? 'Українська' : 'Ukrainian', 
      progress: ukrainianStats.percentage, 
      stars: ukrainianStats.stars,
      accuracy: ukrainianStats.avgAccuracy,
    },
  ];

  const pieData = [
    { id: 'math-pie', name: language === 'uk' ? 'Математика' : 'Math', value: mathStats.stars, color: '#3b82f6' },
    { id: 'english-pie', name: language === 'uk' ? 'Англійська' : 'English', value: englishStats.stars, color: '#10b981' },
    { id: 'ukrainian-pie', name: language === 'uk' ? 'Українська' : 'Ukrainian', value: ukrainianStats.stars, color: '#f59e0b' },
  ];

  // Generate weekly progress data (mock data for now - in real app would use activityLog)
  const getWeeklyProgressData = () => {
    const days = language === 'uk' 
      ? ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Нд']
      : ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    
    return days.map((day, index) => ({
      id: `day-${index}`,
      day,
      starsEarned: Math.floor(Math.random() * 10) + (index < 5 ? 5 : 2),
      timeSpent: Math.floor(Math.random() * 60) + (index < 5 ? 30 : 10),
    }));
  };

  const weeklyData = getWeeklyProgressData();

  // Determine learning trend
  const getTrend = () => {
    if (overallProgress >= 70) return 'excellent';
    if (overallProgress >= 50) return 'good';
    if (overallProgress >= 30) return 'improving';
    return 'needsWork';
  };

  const trend = getTrend();

  const trendInfo = {
    excellent: {
      icon: TrendingUp,
      color: 'text-green-500',
      bgColor: 'from-green-400 to-emerald-500',
      text: language === 'uk' ? 'Відмінний прогрес!' : 'Excellent Progress!',
      description: language === 'uk' 
        ? 'Продовжуйте в тому ж дусі! Ви демонструєте чудові результати.'
        : 'Keep up the great work! You\'re showing outstanding results.',
    },
    good: {
      icon: TrendingUp,
      color: 'text-blue-500',
      bgColor: 'from-blue-400 to-cyan-500',
      text: language === 'uk' ? 'Хороший прогрес' : 'Good Progress',
      description: language === 'uk'
        ? 'Ви на правильному шляху. Продовжуйте вчитися регулярно!'
        : 'You\'re on the right track. Keep learning regularly!',
    },
    improving: {
      icon: Activity,
      color: 'text-yellow-500',
      bgColor: 'from-yellow-400 to-orange-500',
      text: language === 'uk' ? 'Покращується' : 'Improving',
      description: language === 'uk'
        ? 'Ви робите успіхи. Спробуйте займатися трохи більше щодня.'
        : 'You\'re making progress. Try to study a bit more each day.',
    },
    needsWork: {
      icon: TrendingDown,
      color: 'text-orange-500',
      bgColor: 'from-orange-400 to-red-500',
      text: language === 'uk' ? 'Потрібно більше зусиль' : 'Needs More Effort',
      description: language === 'uk'
        ? 'Не здавайтеся! Регулярна практика допоможе вам досягти успіху.'
        : 'Don\'t give up! Regular practice will help you succeed.',
    },
  };

  const currentTrend = trendInfo[trend];
  const TrendIcon = currentTrend.icon;

  // Identify strengths and weaknesses
  const getStrongestSubject = () => {
    const subjects = [
      { id: 'math-subject', name: language === 'uk' ? 'Математика' : 'Math', score: mathStats.percentage, emoji: '🔢' },
      { id: 'english-subject', name: language === 'uk' ? 'Англійська' : 'English', score: englishStats.percentage, emoji: '📚' },
      { id: 'ukrainian-subject', name: language === 'uk' ? 'Українська' : 'Ukrainian', score: ukrainianStats.percentage, emoji: '🇺🇦' },
    ];
    return subjects.sort((a, b) => b.score - a.score);
  };

  const subjectRanking = getStrongestSubject();

  // Recent activity (last 5 activities)
  const recentActivities = activityLog.slice(-5).reverse();

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-200 via-purple-200 to-pink-200 p-4 md:p-8 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute top-10 md:top-20 right-10 md:right-20 text-4xl md:text-7xl opacity-20 animate-pulse">📊</div>
      <div className="absolute bottom-10 md:bottom-20 left-10 md:left-20 text-4xl md:text-7xl opacity-20 animate-bounce">📈</div>
      <div className="absolute top-1/2 right-5 md:right-10 text-3xl md:text-6xl opacity-20">💹</div>

      <div className="max-w-7xl mx-auto relative z-10">
        <button
          onClick={onBack}
          className="flex items-center gap-2 bg-white px-4 md:px-6 py-2 md:py-3 rounded-full shadow-lg hover:shadow-xl transition-all transform hover:scale-105 mb-6 md:mb-8 font-bold border-4 border-indigo-300 text-sm md:text-base"
        >
          <ArrowLeft size={20} className="md:w-6 md:h-6" />
          {language === 'uk' ? 'Назад' : 'Back'}
        </button>

        {/* Header */}
        <div className="bg-white rounded-2xl md:rounded-3xl shadow-2xl p-4 md:p-8 mb-6 md:mb-8 border-4 md:border-8 border-indigo-400">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-3xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600 mb-2">
                {language === 'uk' ? `📊 Статистика ${username}` : `📊 ${username}'s Statistics`}
              </h1>
              <p className="text-base md:text-xl text-gray-600">
                {language === 'uk' ? `Клас ${grade} • Детальний аналіз прогресу` : `Grade ${grade} • Detailed Progress Analysis`}
              </p>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-center">
                <p className="text-xs md:text-sm text-gray-600">{language === 'uk' ? 'Загальний прогрес' : 'Overall Progress'}</p>
                <p className="text-3xl md:text-4xl font-bold text-indigo-600">{overallProgress}%</p>
              </div>
            </div>
          </div>
        </div>

        {/* Overall Trend Card */}
        <div className={`bg-gradient-to-r ${currentTrend.bgColor} rounded-2xl md:rounded-3xl shadow-2xl p-4 md:p-8 mb-6 md:mb-8 border-4 md:border-8 border-white`}>
          <div className="flex flex-col md:flex-row items-center gap-4 md:gap-6">
            <div className="bg-white rounded-full p-4 md:p-6 shadow-xl">
              <TrendIcon size={40} className={`${currentTrend.color} md:w-16 md:h-16`} />
            </div>
            <div className="text-white text-center md:text-left">
              <h2 className="text-2xl md:text-4xl font-bold mb-2">{currentTrend.text}</h2>
              <p className="text-base md:text-xl opacity-90">{currentTrend.description}</p>
            </div>
          </div>
        </div>

        {/* Key Metrics Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-6 mb-6 md:mb-8">
          <div className="bg-white rounded-xl md:rounded-2xl shadow-xl p-3 md:p-6 border-2 md:border-4 border-blue-300">
            <div className="flex flex-col md:flex-row items-center md:gap-4 mb-2 md:mb-3">
              <div className="bg-blue-100 rounded-full p-2 md:p-4 mb-2 md:mb-0">
                <Target size={24} className="text-blue-600 md:w-8 md:h-8" />
              </div>
              <div className="text-center md:text-left">
                <p className="text-xs md:text-sm text-gray-600 font-medium">
                  {language === 'uk' ? 'Рівнів' : 'Levels'}
                </p>
                <p className="text-xl md:text-3xl font-bold text-blue-600">{totalCompleted}/{totalLevels}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl md:rounded-2xl shadow-xl p-3 md:p-6 border-2 md:border-4 border-yellow-300">
            <div className="flex flex-col md:flex-row items-center md:gap-4 mb-2 md:mb-3">
              <div className="bg-yellow-100 rounded-full p-2 md:p-4 mb-2 md:mb-0">
                <Award size={24} className="text-yellow-600 md:w-8 md:h-8" />
              </div>
              <div className="text-center md:text-left">
                <p className="text-xs md:text-sm text-gray-600 font-medium">
                  {language === 'uk' ? 'Зірки' : 'Stars'}
                </p>
                <p className="text-xl md:text-3xl font-bold text-yellow-600">{totalStars}/{maxTotalStars}</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl md:rounded-2xl shadow-xl p-3 md:p-6 border-2 md:border-4 border-green-300">
            <div className="flex flex-col md:flex-row items-center md:gap-4 mb-2 md:mb-3">
              <div className="bg-green-100 rounded-full p-2 md:p-4 mb-2 md:mb-0">
                <TrendingUp size={24} className="text-green-600 md:w-8 md:h-8" />
              </div>
              <div className="text-center md:text-left">
                <p className="text-xs md:text-sm text-gray-600 font-medium">
                  {language === 'uk' ? 'Точність' : 'Accuracy'}
                </p>
                <p className="text-xl md:text-3xl font-bold text-green-600">{overallAccuracy}%</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl md:rounded-2xl shadow-xl p-3 md:p-6 border-2 md:border-4 border-purple-300">
            <div className="flex flex-col md:flex-row items-center md:gap-4 mb-2 md:mb-3">
              <div className="bg-purple-100 rounded-full p-2 md:p-4 mb-2 md:mb-0">
                <Calendar size={24} className="text-purple-600 md:w-8 md:h-8" />
              </div>
              <div className="text-center md:text-left">
                <p className="text-xs md:text-sm text-gray-600 font-medium">
                  {language === 'uk' ? 'Серія' : 'Streak'}
                </p>
                <p className="text-xl md:text-3xl font-bold text-purple-600">{streak} 🔥</p>
              </div>
            </div>
          </div>
        </div>

        {/* Charts Row 1 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-8 mb-6 md:mb-8">
          {/* Subject Progress Comparison */}
          <div className="bg-white rounded-2xl md:rounded-3xl shadow-2xl p-4 md:p-8 border-4 md:border-8 border-purple-300">
            <h2 className="text-lg md:text-2xl font-bold text-gray-800 mb-4 md:mb-6 flex items-center gap-2 md:gap-3">
              <Activity size={24} className="text-purple-600 md:w-7 md:h-7" />
              <span className="text-sm md:text-2xl">{language === 'uk' ? 'Порівняння предметів' : 'Subject Comparison'}</span>
            </h2>
            <div className="w-full overflow-x-auto">
              <ResponsiveContainer width="100%" height={250} minWidth={300}>
                <BarChart data={subjectComparisonData}>
                  <CartesianGrid strokeDasharray="3 3" key="grid-bar" />
                  <XAxis dataKey="name" tick={{ fontSize: 12 }} key="xaxis-bar" />
                  <YAxis tick={{ fontSize: 12 }} key="yaxis-bar" />
                  <Tooltip key="tooltip-bar" />
                  <Legend wrapperStyle={{ fontSize: '12px' }} key="legend-bar" />
                  <Bar dataKey="progress" fill="#8b5cf6" name={language === 'uk' ? 'Прогрес %' : 'Progress %'} key="bar-progress" />
                  <Bar dataKey="accuracy" fill="#10b981" name={language === 'uk' ? 'Точність %' : 'Accuracy %'} key="bar-accuracy" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Stars Distribution */}
          <div className="bg-white rounded-2xl md:rounded-3xl shadow-2xl p-4 md:p-8 border-4 md:border-8 border-yellow-300">
            <h2 className="text-lg md:text-2xl font-bold text-gray-800 mb-4 md:mb-6 flex items-center gap-2 md:gap-3">
              <Award size={24} className="text-yellow-600 md:w-7 md:h-7" />
              <span className="text-sm md:text-2xl">{language === 'uk' ? 'Розподіл зірок' : 'Stars Distribution'}</span>
            </h2>
            <div className="w-full overflow-x-auto">
              <ResponsiveContainer width="100%" height={250} minWidth={300}>
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    key="pie-main"
                  >
                    {pieData.map((entry) => (
                      <Cell key={entry.id} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip key="tooltip-pie" />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Weekly Activity Chart */}
        <div className="bg-white rounded-2xl md:rounded-3xl shadow-2xl p-4 md:p-8 mb-6 md:mb-8 border-4 md:border-8 border-blue-300">
          <h2 className="text-lg md:text-2xl font-bold text-gray-800 mb-4 md:mb-6 flex items-center gap-2 md:gap-3">
            <Calendar size={24} className="text-blue-600 md:w-7 md:h-7" />
            <span className="text-sm md:text-2xl">{language === 'uk' ? 'Активність за тиждень' : 'Weekly Activity'}</span>
          </h2>
          <div className="w-full overflow-x-auto">
            <ResponsiveContainer width="100%" height={250} minWidth={300}>
              <LineChart data={weeklyData}>
                <CartesianGrid strokeDasharray="3 3" key="grid-line" />
                <XAxis dataKey="day" tick={{ fontSize: 12 }} key="xaxis-line" />
                <YAxis yAxisId="left" tick={{ fontSize: 12 }} key="yaxis-left" />
                <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 12 }} key="yaxis-right" />
                <Tooltip key="tooltip-line" />
                <Legend wrapperStyle={{ fontSize: '12px' }} key="legend-line" />
                <Line 
                  yAxisId="left"
                  type="monotone" 
                  dataKey="starsEarned" 
                  stroke="#f59e0b" 
                  strokeWidth={3}
                  name={language === 'uk' ? 'Зірки' : 'Stars'}
                  key="line-stars"
                />
                <Line 
                  yAxisId="right"
                  type="monotone" 
                  dataKey="timeSpent" 
                  stroke="#3b82f6" 
                  strokeWidth={3}
                  name={language === 'uk' ? 'Хвилини' : 'Minutes'}
                  key="line-time"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Strengths & Weaknesses */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-8 mb-6 md:mb-8">
          {/* Strengths */}
          <div className="bg-white rounded-2xl md:rounded-3xl shadow-2xl p-4 md:p-8 border-4 md:border-8 border-green-300">
            <h2 className="text-lg md:text-2xl font-bold text-gray-800 mb-4 md:mb-6 flex items-center gap-2 md:gap-3">
              <TrendingUp size={24} className="text-green-600 md:w-7 md:h-7" />
              <span className="text-sm md:text-2xl">{language === 'uk' ? 'Сильні сторони' : 'Strengths'}</span>
            </h2>
            <div className="space-y-3 md:space-y-4">
              {subjectRanking.slice(0, 2).map((subject) => (
                <div key={subject.id} className="bg-gradient-to-r from-green-50 to-emerald-50 p-3 md:p-4 rounded-xl md:rounded-2xl border-2 border-green-200">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 md:gap-3">
                      <span className="text-3xl md:text-4xl">{subject.emoji}</span>
                      <div>
                        <p className="font-bold text-sm md:text-lg text-gray-800">{subject.name}</p>
                        <p className="text-xs md:text-sm text-gray-600">
                          {language === 'uk' ? 'Завершено' : 'Completed'}: {subject.score}%
                        </p>
                      </div>
                    </div>
                    <div className="text-2xl md:text-3xl font-bold text-green-600">{subject.score}%</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Areas to Improve */}
          <div className="bg-white rounded-2xl md:rounded-3xl shadow-2xl p-4 md:p-8 border-4 md:border-8 border-orange-300">
            <h2 className="text-lg md:text-2xl font-bold text-gray-800 mb-4 md:mb-6 flex items-center gap-2 md:gap-3">
              <Target size={24} className="text-orange-600 md:w-7 md:h-7" />
              <span className="text-sm md:text-2xl">{language === 'uk' ? 'Області для покращення' : 'Areas to Improve'}</span>
            </h2>
            <div className="space-y-3 md:space-y-4">
              {subjectRanking.slice(-1).map((subject) => (
                <div key={subject.id} className="bg-gradient-to-r from-orange-50 to-yellow-50 p-3 md:p-4 rounded-xl md:rounded-2xl border-2 border-orange-200">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 md:gap-3">
                      <span className="text-3xl md:text-4xl">{subject.emoji}</span>
                      <div>
                        <p className="font-bold text-sm md:text-lg text-gray-800">{subject.name}</p>
                        <p className="text-xs md:text-sm text-gray-600">
                          {language === 'uk' ? 'Потрібно більше практики' : 'Needs more practice'}
                        </p>
                      </div>
                    </div>
                    <div className="text-2xl md:text-3xl font-bold text-orange-600">{subject.score}%</div>
                  </div>
                </div>
              ))}
              <div className="bg-gradient-to-r from-blue-50 to-cyan-50 p-3 md:p-4 rounded-xl md:rounded-2xl border-2 border-blue-200">
                <p className="text-xs md:text-sm text-gray-700">
                  <strong>{language === 'uk' ? '💡 Порада:' : '💡 Tip:'}</strong>{' '}
                  {language === 'uk' 
                    ? 'Спробуйте приділяти 15-20 хвилин щодня цьому предмету для покращення результатів!'
                    : 'Try spending 15-20 minutes daily on this subject to improve your results!'}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Recent Activity */}
        {recentActivities.length > 0 && (
          <div className="bg-white rounded-2xl md:rounded-3xl shadow-2xl p-4 md:p-8 border-4 md:border-8 border-indigo-300">
            <h2 className="text-lg md:text-2xl font-bold text-gray-800 mb-4 md:mb-6 flex items-center gap-2 md:gap-3">
              <Clock size={24} className="text-indigo-600 md:w-7 md:h-7" />
              <span className="text-sm md:text-2xl">{language === 'uk' ? 'Недавня активність' : 'Recent Activity'}</span>
            </h2>
            <div className="space-y-3">
              {recentActivities.map((activity, index) => (
                <div key={index} className="bg-gradient-to-r from-indigo-50 to-purple-50 p-3 md:p-4 rounded-xl border-2 border-indigo-200 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                  <div className="flex items-center gap-3 md:gap-4">
                    <div className="bg-indigo-100 rounded-full w-10 h-10 md:w-12 md:h-12 flex items-center justify-center font-bold text-indigo-600 text-sm md:text-base">
                      {activity.level}
                    </div>
                    <div>
                      <p className="font-bold text-gray-800 text-sm md:text-base">{activity.subject}</p>
                      <p className="text-xs md:text-sm text-gray-600">
                        {new Date(activity.date).toLocaleDateString(language === 'uk' ? 'uk-UA' : 'en-US')}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 md:gap-4 justify-between md:justify-end">
                    <div className="text-right">
                      <p className="text-xs md:text-sm text-gray-600">{language === 'uk' ? 'Точність' : 'Accuracy'}</p>
                      <p className="font-bold text-green-600 text-sm md:text-base">{activity.accuracy}%</p>
                    </div>
                    <div className="text-yellow-500 text-xl md:text-2xl">
                      {'⭐'.repeat(activity.stars)}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}