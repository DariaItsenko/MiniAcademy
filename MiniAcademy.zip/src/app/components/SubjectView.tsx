import { ArrowLeft } from 'lucide-react';
import { useState } from 'react';
import { WebinarCard } from './WebinarCard';
import { LevelCard } from './LevelCard';
import { VideoExplanationModal } from './VideoExplanationModal';
import { useLanguage } from '../contexts/LanguageContext';

interface Webinar {
  id: number;
  title: string;
  date: string;
  time: string;
  instructor: string;
  participants: number;
  level: string;
}

interface Level {
  level: number;
  title: string;
  description: string;
  status: 'locked' | 'available' | 'completed';
  stars: number;
  totalStars: number;
  videoUrl?: string;
}

interface SubjectViewProps {
  subject: string;
  color: string;
  webinars: Webinar[];
  levels: Level[];
  onBack: () => void;
  onStartLevel: (levelNumber: number) => void;
  onWebinarClick: (webinarId: number) => void;
}

export function SubjectView({ subject, color, webinars, levels, onBack, onStartLevel, onWebinarClick }: SubjectViewProps) {
  const { t } = useLanguage();
  const [selectedVideo, setSelectedVideo] = useState<{ title: string; url: string } | null>(null);
  
  // Animal mascots for different subjects
  const subjectMascots = {
    'Math': '🦉',
    'Математика': '🦉',
    'English': '🐼',
    'Англійська': '🐼',
    'Ukrainian': '🦄',
    'Українська': '🦄'
  };
  
  const mascot = subjectMascots[subject] || '🌟';
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-100 via-pink-100 to-blue-200 p-8 relative overflow-hidden">
      {/* Playful background decorations */}
      <div className="absolute top-20 right-20 text-7xl opacity-30 animate-pulse">✨</div>
      <div className="absolute bottom-20 left-20 text-7xl opacity-30 animate-bounce">🎈</div>
      <div className="absolute top-1/2 left-10 text-6xl opacity-30">🌸</div>
      
      <div className="max-w-7xl mx-auto relative z-10">
        <button
          onClick={onBack}
          className="flex items-center gap-2 bg-white text-gray-700 hover:text-gray-900 px-6 py-3 rounded-full shadow-lg hover:shadow-xl transition-all transform hover:scale-105 mb-8 font-bold border-4 border-purple-300"
        >
          <ArrowLeft size={24} />
          {t('subjectView.backToHome')}
        </button>
        
        <div className={`${color} text-white rounded-3xl p-10 mb-10 shadow-2xl border-8 border-white`}>
          <div className="flex items-center gap-4 mb-4">
            <span className="text-7xl animate-bounce">{mascot}</span>
            <div>
              <h1 className="text-6xl font-bold">{subject}</h1>
              <p className="text-2xl opacity-90 mt-2">{t('subjectView.upcomingWebinars')} & {t('subjectView.learningPath')}</p>
            </div>
          </div>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8">
          {/* Webinars Section */}
          <div>
            <h2 className="text-2xl font-bold text-gray-800 mb-6">{t('subjectView.upcomingWebinars')}</h2>
            <div className="space-y-4">
              {webinars.map((webinar) => (
                <WebinarCard 
                  key={webinar.id} 
                  {...webinar} 
                  onClick={() => onWebinarClick(webinar.id)}
                />
              ))}
            </div>
          </div>
          
          {/* Levels Section */}
          <div>
            <h2 className="text-2xl font-bold text-gray-800 mb-6">{t('subjectView.learningPath')}</h2>
            <div className="space-y-4">
              {levels.map((level, index) => (
                <div key={level.level}>
                  <LevelCard 
                    {...level} 
                    onStart={() => level.status === 'available' && onStartLevel(index)}
                    onWatchVideo={level.videoUrl ? () => setSelectedVideo({ title: level.title, url: level.videoUrl! }) : undefined}
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
      
      {selectedVideo && (
        <VideoExplanationModal
          title={selectedVideo.title}
          videoUrl={selectedVideo.url}
          onClose={() => setSelectedVideo(null)}
        />
      )}
    </div>
  );
}