// API utility for secure backend communication
import { projectId, publicAnonKey } from '/utils/supabase/info';

const API_BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server-51051136`;

// Store session token
let sessionToken: string | null = localStorage.getItem('session_token');

export function setSessionToken(token: string) {
  sessionToken = token;
  localStorage.setItem('session_token', token);
}

export function getSessionToken(): string | null {
  return sessionToken;
}

export function clearSessionToken() {
  sessionToken = null;
  localStorage.removeItem('session_token');
}

// Register new user
export async function registerUser(data: {
  username: string;
  password: string;
  email: string;
  grade: number;
  parentEmail?: string;
}) {
  const response = await fetch(`${API_BASE_URL}/register`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${publicAnonKey}`
    },
    body: JSON.stringify(data)
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Registration failed');
  }

  const result = await response.json();
  if (result.token) {
    setSessionToken(result.token);
  }
  return result;
}

// Login user
export async function loginUser(username: string, password: string) {
  const response = await fetch(`${API_BASE_URL}/login`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${publicAnonKey}`
    },
    body: JSON.stringify({ username, password })
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Login failed');
  }

  const result = await response.json();
  if (result.token) {
    setSessionToken(result.token);
  }
  return result;
}

// Verify current session
export async function verifySession() {
  const token = getSessionToken();
  if (!token) {
    throw new Error('No session token');
  }

  const response = await fetch(`${API_BASE_URL}/verify-session`, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${token}`
    }
  });

  if (!response.ok) {
    clearSessionToken();
    throw new Error('Session expired');
  }

  return await response.json();
}

// Update user progress
export async function updateProgress(data: {
  progress?: any;
  points?: number;
  streak?: number;
  selectedAvatar?: string;
  customization?: any;
  inventory?: any;
  badges?: any;
}) {
  const token = getSessionToken();
  if (!token) {
    throw new Error('Not authenticated');
  }

  const response = await fetch(`${API_BASE_URL}/update-progress`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify(data)
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Update failed');
  }

  return await response.json();
}

// Logout
export async function logoutUser() {
  const token = getSessionToken();
  if (!token) {
    return;
  }

  try {
    await fetch(`${API_BASE_URL}/logout`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });
  } finally {
    clearSessionToken();
  }
}

// Request password reset
export async function requestPasswordReset(email: string) {
  const response = await fetch(`${API_BASE_URL}/request-password-reset`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${publicAnonKey}`
    },
    body: JSON.stringify({ email })
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Request failed');
  }

  return await response.json();
}

// Reset password
export async function resetPassword(email: string, code: string, newPassword: string) {
  const response = await fetch(`${API_BASE_URL}/reset-password`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${publicAnonKey}`
    },
    body: JSON.stringify({ email, code, newPassword })
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Password reset failed');
  }

  return await response.json();
}

// Send progress report
export async function sendProgressReport(parentEmail: string, language: string) {
  const token = getSessionToken();
  if (!token) {
    throw new Error('Not authenticated');
  }

  const response = await fetch(`${API_BASE_URL}/send-report`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`
    },
    body: JSON.stringify({ parentEmail, language })
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Failed to send report');
  }

  return await response.json();
}
