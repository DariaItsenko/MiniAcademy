import { useState } from "react";
import { ArrowLeft, Plus, Edit2, Trash2, Video, BookOpen, CheckSquare } from "lucide-react";
import { useLanguage } from "../contexts/LanguageContext";
import { AdminTaskManager } from "./AdminTaskManager";

interface Level {
  level: number;
  title: string;
  description: string;
  totalStars: number;
}

interface AdminPanelProps {
  onBack: () => void;
  onLogout?: () => void;
}

export function AdminPanel({ onBack, onLogout }: AdminPanelProps) {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState<"math" | "english" | "ukrainian">("math");
  const [editingLevel, setEditingLevel] = useState<number | null>(null);
  const [editingVideo, setEditingVideo] = useState<number | null>(null);
  const [viewSection, setViewSection] = useState<"levels" | "tasks" | "videos">("levels");

  // Load current data from localStorage
  const [levelData, setLevelData] = useState(() => {
    const stored = localStorage.getItem("admin_level_data");
    return stored ? JSON.parse(stored) : {
      math: [
        { level: 1, title: "Addition & Subtraction", description: "Master basic addition and subtraction with numbers up to 100", totalStars: 3 },
        { level: 2, title: "Multiplication Tables", description: "Learn multiplication tables from 1 to 10", totalStars: 3 },
        { level: 3, title: "Division Basics", description: "Understand division and solve simple division problems", totalStars: 3 },
        { level: 4, title: "Advanced Problem Solving", description: "Apply all operations to solve word problems", totalStars: 3 },
      ],
      english: [
        { level: 1, title: "Alphabet & Phonics", description: "Learn letter sounds and simple word formation", totalStars: 3 },
        { level: 2, title: "Reading Simple Sentences", description: "Practice reading and understanding basic sentences", totalStars: 3 },
        { level: 3, title: "Story Writing", description: "Create your own short stories with proper structure", totalStars: 3 },
        { level: 4, title: "Advanced Grammar", description: "Master punctuation, tenses, and sentence structure", totalStars: 3 },
      ],
      ukrainian: [
        { level: 1, title: "Абетка і звуки", description: "Вивчення української абетки та звуків", totalStars: 3 },
        { level: 2, title: "Прості слова", description: "Читання та написання простих українських слів", totalStars: 3 },
        { level: 3, title: "Речення", description: "Складання та читання простих речень", totalStars: 3 },
        { level: 4, title: "Твори і оповідання", description: "Написання коротких творів українською мовою", totalStars: 3 },
      ],
    };
  });

  const [videoData, setVideoData] = useState(() => {
    const stored = localStorage.getItem("admin_video_data");
    return stored ? JSON.parse(stored) : {
      math: [
        "https://www.youtube.com/embed/dQw4w9WgXcQ",
        "https://www.youtube.com/embed/dQw4w9WgXcQ",
        "https://www.youtube.com/embed/dQw4w9WgXcQ",
        "https://www.youtube.com/embed/dQw4w9WgXcQ",
      ],
      english: [
        "https://www.youtube.com/embed/dQw4w9WgXcQ",
        "https://www.youtube.com/embed/dQw4w9WgXcQ",
        "https://www.youtube.com/embed/dQw4w9WgXcQ",
        "https://www.youtube.com/embed/dQw4w9WgXcQ",
      ],
      ukrainian: [
        "https://www.youtube.com/embed/dQw4w9WgXcQ",
        "https://www.youtube.com/embed/dQw4w9WgXcQ",
        "https://www.youtube.com/embed/dQw4w9WgXcQ",
        "https://www.youtube.com/embed/dQw4w9WgXcQ",
      ],
    };
  });

  const [newLevel, setNewLevel] = useState({ title: "", description: "" });
  const [newVideoUrl, setNewVideoUrl] = useState("");

  const saveData = (levels: any, videos: any) => {
    localStorage.setItem("admin_level_data", JSON.stringify(levels));
    localStorage.setItem("admin_video_data", JSON.stringify(videos));
  };

  const handleAddLevel = () => {
    if (!newLevel.title || !newLevel.description) {
      alert("Please fill in all fields");
      return;
    }

    const updated = { ...levelData };
    updated[activeTab].push({
      level: updated[activeTab].length + 1,
      title: newLevel.title,
      description: newLevel.description,
      totalStars: 3,
    });
    setLevelData(updated);
    saveData(updated, videoData);
    setNewLevel({ title: "", description: "" });
  };

  const handleUpdateLevel = (index: number) => {
    const updated = { ...levelData };
    const level = updated[activeTab][index];
    const newTitle = prompt("Enter new title:", level.title);
    const newDesc = prompt("Enter new description:", level.description);
    
    if (newTitle && newDesc) {
      updated[activeTab][index] = {
        ...level,
        title: newTitle,
        description: newDesc,
      };
      setLevelData(updated);
      saveData(updated, videoData);
    }
  };

  const handleDeleteLevel = (index: number) => {
    if (confirm("Are you sure you want to delete this level?")) {
      const updated = { ...levelData };
      updated[activeTab].splice(index, 1);
      // Renumber levels
      updated[activeTab] = updated[activeTab].map((l: any, i: number) => ({
        ...l,
        level: i + 1,
      }));
      setLevelData(updated);
      saveData(updated, videoData);
    }
  };

  const handleUpdateVideo = (index: number) => {
    const updated = { ...videoData };
    const newUrl = prompt("Enter YouTube embed URL:", updated[activeTab][index]);
    
    if (newUrl) {
      updated[activeTab][index] = newUrl;
      setVideoData(updated);
      saveData(levelData, updated);
    }
  };

  const handleAddVideo = () => {
    if (!newVideoUrl) {
      alert("Please enter a video URL");
      return;
    }

    const updated = { ...videoData };
    updated[activeTab].push(newVideoUrl);
    setVideoData(updated);
    saveData(levelData, updated);
    setNewVideoUrl("");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-400 via-pink-400 to-red-400 p-2 sm:p-4 md:p-8">
      <div className="flex flex-col sm:flex-row gap-2 sm:gap-4 mb-4 sm:mb-6">
        <button
          onClick={onBack}
          className="flex items-center justify-center gap-2 bg-white px-4 sm:px-6 py-2 sm:py-3 rounded-full shadow-lg hover:shadow-xl transition-all text-purple-700 font-bold transform hover:scale-105 text-sm sm:text-base"
        >
          <ArrowLeft size={20} />
          <span className="hidden sm:inline">Back to Home</span>
          <span className="sm:hidden">Back</span>
        </button>

        {onLogout && (
          <button
            onClick={onLogout}
            className="flex items-center justify-center gap-2 bg-red-500 px-4 sm:px-6 py-2 sm:py-3 rounded-full shadow-lg hover:shadow-xl transition-all text-white font-bold transform hover:scale-105 text-sm sm:text-base"
          >
            🚪 Logout
          </button>
        )}
      </div>

      <div className="bg-white rounded-2xl sm:rounded-3xl shadow-2xl p-3 sm:p-6 md:p-8 max-w-6xl mx-auto">
        <div className="flex items-center gap-2 sm:gap-4 mb-4 sm:mb-8">
          <div className="text-3xl sm:text-6xl">👨‍💼</div>
          <div>
            <h1 className="text-xl sm:text-3xl md:text-4xl font-bold text-gray-800">Admin Dashboard</h1>
            <p className="text-xs sm:text-sm md:text-base text-gray-600">Manage levels and videos</p>
          </div>
        </div>

        {/* Subject Tabs */}
        <div className="flex flex-col sm:flex-row gap-2 sm:gap-4 mb-4 sm:mb-8">
          <button
            onClick={() => setActiveTab("math")}
            className={`flex-1 py-2 sm:py-4 px-3 sm:px-6 rounded-xl sm:rounded-2xl font-bold text-sm sm:text-lg transition-all transform hover:scale-105 ${
              activeTab === "math"
                ? "bg-gradient-to-r from-blue-500 to-blue-700 text-white shadow-lg"
                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            }`}
          >
            🔢 Math
          </button>
          <button
            onClick={() => setActiveTab("english")}
            className={`flex-1 py-2 sm:py-4 px-3 sm:px-6 rounded-xl sm:rounded-2xl font-bold text-sm sm:text-lg transition-all transform hover:scale-105 ${
              activeTab === "english"
                ? "bg-gradient-to-r from-green-500 to-green-700 text-white shadow-lg"
                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            }`}
          >
            📚 English
          </button>
          <button
            onClick={() => setActiveTab("ukrainian")}
            className={`flex-1 py-2 sm:py-4 px-3 sm:px-6 rounded-xl sm:rounded-2xl font-bold text-sm sm:text-lg transition-all transform hover:scale-105 ${
              activeTab === "ukrainian"
                ? "bg-gradient-to-r from-yellow-500 to-orange-600 text-white shadow-lg"
                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            }`}
          >
            🇺🇦 Ukrainian
          </button>
        </div>

        {/* Section Tabs */}
        <div className="flex flex-col sm:flex-row gap-2 sm:gap-4 mb-4 sm:mb-8">
          <button
            onClick={() => setViewSection("levels")}
            className={`flex-1 py-2 sm:py-4 px-3 sm:px-6 rounded-xl sm:rounded-2xl font-bold text-sm sm:text-lg transition-all transform hover:scale-105 ${
              viewSection === "levels"
                ? "bg-gradient-to-r from-blue-500 to-blue-700 text-white shadow-lg"
                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            }`}
          >
            Levels
          </button>
          <button
            onClick={() => setViewSection("tasks")}
            className={`flex-1 py-2 sm:py-4 px-3 sm:px-6 rounded-xl sm:rounded-2xl font-bold text-sm sm:text-lg transition-all transform hover:scale-105 ${
              viewSection === "tasks"
                ? "bg-gradient-to-r from-green-500 to-green-700 text-white shadow-lg"
                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            }`}
          >
            Tasks
          </button>
          <button
            onClick={() => setViewSection("videos")}
            className={`flex-1 py-2 sm:py-4 px-3 sm:px-6 rounded-xl sm:rounded-2xl font-bold text-sm sm:text-lg transition-all transform hover:scale-105 ${
              viewSection === "videos"
                ? "bg-gradient-to-r from-red-500 to-red-700 text-white shadow-lg"
                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            }`}
          >
            Videos
          </button>
        </div>

        {/* Levels Section */}
        <div className="mb-12">
          <div className="flex items-center gap-3 mb-6">
            <BookOpen className="text-purple-600" size={32} />
            <h2 className="text-3xl font-bold text-gray-800">Levels</h2>
          </div>

          <div className="space-y-4 mb-6">
            {levelData[activeTab].map((level: Level, index: number) => (
              <div
                key={index}
                className="bg-gradient-to-r from-purple-50 to-pink-50 p-6 rounded-2xl shadow-md hover:shadow-lg transition-all"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="bg-purple-500 text-white font-bold px-4 py-1 rounded-full text-sm">
                        Level {level.level}
                      </span>
                      <h3 className="text-xl font-bold text-gray-800">{level.title}</h3>
                    </div>
                    <p className="text-gray-600">{level.description}</p>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleUpdateLevel(index)}
                      className="p-3 bg-blue-500 text-white rounded-xl hover:bg-blue-600 transition-colors"
                    >
                      <Edit2 size={20} />
                    </button>
                    <button
                      onClick={() => handleDeleteLevel(index)}
                      className="p-3 bg-red-500 text-white rounded-xl hover:bg-red-600 transition-colors"
                    >
                      <Trash2 size={20} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Add New Level */}
          <div className="bg-gradient-to-r from-green-50 to-blue-50 p-6 rounded-2xl shadow-md">
            <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
              <Plus size={24} className="text-green-600" />
              Add New Level
            </h3>
            <div className="space-y-4">
              <input
                type="text"
                placeholder="Level title..."
                value={newLevel.title}
                onChange={(e) => setNewLevel({ ...newLevel, title: e.target.value })}
                className="w-full p-4 border-2 border-gray-300 rounded-xl focus:border-purple-500 focus:outline-none"
              />
              <textarea
                placeholder="Level description..."
                value={newLevel.description}
                onChange={(e) => setNewLevel({ ...newLevel, description: e.target.value })}
                className="w-full p-4 border-2 border-gray-300 rounded-xl focus:border-purple-500 focus:outline-none resize-none"
                rows={3}
              />
              <button
                onClick={handleAddLevel}
                className="w-full bg-gradient-to-r from-green-500 to-green-600 text-white font-bold py-4 px-6 rounded-xl hover:from-green-600 hover:to-green-700 transition-all transform hover:scale-105 shadow-lg"
              >
                Add Level
              </button>
            </div>
          </div>
        </div>

        {/* Tasks Section */}
        <div className="mb-12">
          <AdminTaskManager subject={activeTab} />
        </div>

        {/* Videos Section */}
        {viewSection === "videos" && (
          <div>
            <div className="flex items-center gap-3 mb-6">
              <Video className="text-red-600" size={32} />
              <h2 className="text-3xl font-bold text-gray-800">Video Explanations</h2>
            </div>

            <div className="space-y-4 mb-6">
              {videoData[activeTab].map((url: string, index: number) => (
                <div
                  key={index}
                  className="bg-gradient-to-r from-red-50 to-orange-50 p-6 rounded-2xl shadow-md hover:shadow-lg transition-all"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <span className="bg-red-500 text-white font-bold px-4 py-1 rounded-full text-sm">
                          Level {index + 1}
                        </span>
                        <span className="text-gray-600 text-sm truncate max-w-md">{url}</span>
                      </div>
                    </div>
                    <button
                      onClick={() => handleUpdateVideo(index)}
                      className="p-3 bg-blue-500 text-white rounded-xl hover:bg-blue-600 transition-colors flex items-center gap-2"
                    >
                      <Edit2 size={20} />
                      <span className="font-medium">Edit URL</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Add New Video */}
            <div className="bg-gradient-to-r from-yellow-50 to-orange-50 p-6 rounded-2xl shadow-md">
              <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                <Plus size={24} className="text-orange-600" />
                Add New Video
              </h3>
              <div className="space-y-4">
                <input
                  type="text"
                  placeholder="YouTube embed URL (e.g., https://www.youtube.com/embed/...)"
                  value={newVideoUrl}
                  onChange={(e) => setNewVideoUrl(e.target.value)}
                  className="w-full p-4 border-2 border-gray-300 rounded-xl focus:border-purple-500 focus:outline-none"
                />
                <button
                  onClick={handleAddVideo}
                  className="w-full bg-gradient-to-r from-orange-500 to-red-500 text-white font-bold py-4 px-6 rounded-xl hover:from-orange-600 hover:to-red-600 transition-all transform hover:scale-105 shadow-lg"
                >
                  Add Video
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}