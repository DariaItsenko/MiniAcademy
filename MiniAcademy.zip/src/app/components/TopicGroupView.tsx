import { ArrowLeft, BookOpen, Lock } from 'lucide-react';
import { TopicGroup } from '../data/topicDataBilingual';
import { useLanguage } from '../contexts/LanguageContext';

interface TopicGroupViewProps {
  subject: 'math' | 'english' | 'ukrainian';
  topicGroups: TopicGroup[];
  onBack: () => void;
  onSelectSubtopic: (groupId: string, subtopicId: string) => void;
  progress?: any;
}

export function TopicGroupView({
  subject,
  topicGroups,
  onBack,
  onSelectSubtopic,
  progress
}: TopicGroupViewProps) {
  const { t, language } = useLanguage();

  const subjectEmojis = {
    math: '🔢',
    english: '📚',
    ukrainian: '🇺🇦'
  };

  const subjectColors = {
    math: 'from-blue-400 via-purple-400 to-pink-400',
    english: 'from-green-400 via-teal-400 to-blue-400',
    ukrainian: 'from-yellow-400 via-blue-400 to-blue-600'
  };

  return (
    <div className={`min-h-screen bg-gradient-to-br ${subjectColors[subject]} p-8 relative overflow-hidden`}>
      {/* Animated background decorations */}
      <div className="absolute top-10 right-10 text-9xl opacity-10 animate-bounce">{subjectEmojis[subject]}</div>
      <div className="absolute bottom-20 left-20 text-8xl opacity-10 animate-pulse">📖</div>
      <div className="absolute top-1/2 right-1/4 text-7xl opacity-10 animate-spin-slow">⭐</div>

      <div className="max-w-7xl mx-auto relative z-10">
        {/* Header */}
        <button
          onClick={onBack}
          className="flex items-center gap-2 bg-white px-6 py-3 rounded-full shadow-lg hover:shadow-xl transition-all transform hover:scale-105 mb-8 font-bold border-4 border-purple-300"
        >
          <ArrowLeft size={24} />
          {t('subjectView.backToHome')}
        </button>

        <div className="text-center mb-12">
          <h1 className="text-6xl font-bold text-white mb-4 drop-shadow-lg flex items-center justify-center gap-4">
            <span className="text-8xl animate-bounce">{subjectEmojis[subject]}</span>
            {t(`subject.${subject}`)}
          </h1>
          <p className="text-2xl text-white font-bold drop-shadow-md">
            {t('topic.chooseToStart')} 🚀
          </p>
        </div>

        {/* Topic Groups */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {topicGroups.map((group) => (
            <div
              key={group.id}
              className="bg-white rounded-3xl shadow-2xl p-8 border-8 border-yellow-300 hover:border-yellow-400 transition-all transform hover:scale-105"
            >
              {/* Group Header */}
              <div className="flex items-center gap-4 mb-6">
                <span className="text-7xl">{group.emoji}</span>
                <div>
                  <h2 className="text-3xl font-bold text-gray-800">{group.title[language]}</h2>
                  <p className="text-lg text-gray-600 font-medium">{group.description[language]}</p>
                </div>
              </div>

              {/* Subtopics */}
              <div className="space-y-4">
                {group.subtopics.map((subtopic, index) => {
                  const isLocked = false; // For now, all unlocked. You can add logic here
                  
                  return (
                    <button
                      key={subtopic.id}
                      onClick={() => !isLocked && onSelectSubtopic(group.id, subtopic.id)}
                      disabled={isLocked}
                      className={`w-full p-6 rounded-2xl shadow-lg transition-all transform hover:scale-105 text-left ${
                        isLocked
                          ? 'bg-gray-200 cursor-not-allowed opacity-60'
                          : `bg-gradient-to-r ${group.color} hover:shadow-xl`
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <span className="text-5xl">{subtopic.emoji}</span>
                          <div>
                            <h3 className="text-2xl font-bold text-white drop-shadow-md flex items-center gap-2">
                              {subtopic.title[language]}
                              {isLocked && <Lock size={20} />}
                            </h3>
                            <p className="text-white/90 font-medium drop-shadow">{subtopic.description[language]}</p>
                          </div>
                        </div>
                        <div className="flex flex-col items-center gap-2">
                          <BookOpen size={32} className="text-white drop-shadow" />
                          <div className="bg-white/20 backdrop-blur px-3 py-1 rounded-full">
                            <p className="text-xs text-white font-bold">
                              {subtopic.videos.length} {t('topic.videos')}
                            </p>
                          </div>
                          <div className="bg-white/20 backdrop-blur px-3 py-1 rounded-full">
                            <p className="text-xs text-white font-bold">
                              {subtopic.exercises.length} {t('topic.exercises')}
                            </p>
                          </div>
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}