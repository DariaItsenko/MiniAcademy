import { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { Trophy, Star, Zap, Target } from 'lucide-react';
import { motion } from 'motion/react';

interface Choice {
  text: string;
  points: number;
  feedback: string;
  emoji: string;
}

interface Scenario {
  id: string;
  title: string;
  description: string;
  emoji: string;
  choices: Choice[];
}

interface MiniSimulationProps {
  onComplete: (score: number) => void;
  subject: 'math' | 'english' | 'ukrainian';
}

export function MiniSimulation({ onComplete, subject }: MiniSimulationProps) {
  const { language } = useLanguage();

  const exerciseData = {
    math: {
      title: language === 'uk' ? '🎮 Математичні пригоди' : '🎮 Math Adventures',
      scenarios: [
        {
          id: '1',
          title: language === 'uk' ? 'Магазин іграшок' : 'Toy Store',
          description: language === 'uk'
            ? 'У тебе є 50 гривень. Іграшка коштує 15 гривень. Скільки іграшок ти можеш купити?'
            : 'You have $50. A toy costs $15. How many toys can you buy?',
          emoji: '🎁',
          choices: [
            {
              text: language === 'uk' ? '2 іграшки' : '2 toys',
              points: 0,
              feedback: language === 'uk' ? '❌ Спробуй ще раз! 15 × 2 = 30, у тебе залишилось би ще гроші!' : '❌ Try again! 15 × 2 = 30, you would have money left!',
              emoji: '😕',
            },
            {
              text: language === 'uk' ? '3 іграшки' : '3 toys',
              points: 10,
              feedback: language === 'uk' ? '✅ Правильно! 15 × 3 = 45, і у тебе залишиться 5 гривень!' : '✅ Correct! 15 × 3 = 45, and you\'ll have $5 left!',
              emoji: '🎉',
            },
            {
              text: language === 'uk' ? '4 іграшки' : '4 toys',
              points: 0,
              feedback: language === 'uk' ? '❌ Ні, це занадто багато! 15 × 4 = 60, а у тебе тільки 50!' : '❌ No, that\'s too many! 15 × 4 = 60, but you only have $50!',
              emoji: '😅',
            },
          ],
        },
        {
          id: '2',
          title: language === 'uk' ? 'Піца-вечірка' : 'Pizza Party',
          description: language === 'uk'
            ? 'У піці 8 шматочків. Якщо ти з\'їси 2 шматки, яка частина піци залишиться?'
            : 'A pizza has 8 slices. If you eat 2 slices, what fraction is left?',
          emoji: '🍕',
          choices: [
            {
              text: '2/8',
              points: 0,
              feedback: language === 'uk' ? '❌ Це те, що ти з\'їв! Залишилось 8 - 2 = 6 шматків!' : '❌ That\'s what you ate! You have 8 - 2 = 6 slices left!',
              emoji: '😋',
            },
            {
              text: '6/8',
              points: 10,
              feedback: language === 'uk' ? '✅ Чудово! 8 - 2 = 6, тож залишилось 6/8 піци!' : '✅ Perfect! 8 - 2 = 6, so 6/8 of the pizza is left!',
              emoji: '🎊',
            },
            {
              text: '4/8',
              points: 0,
              feedback: language === 'uk' ? '❌ Це половина, але ти з\'їв тільки 2 шматки!' : '❌ That\'s half, but you only ate 2 slices!',
              emoji: '🤔',
            },
          ],
        },
        {
          id: '3',
          title: language === 'uk' ? 'Садівник' : 'Gardener',
          description: language === 'uk'
            ? 'Ти садиш квіти в 5 рядів. У кожному ряду по 4 квітки. Скільки всього квіток?'
            : 'You\'re planting flowers in 5 rows. Each row has 4 flowers. How many total?',
          emoji: '🌺',
          choices: [
            {
              text: '9',
              points: 0,
              feedback: language === 'uk' ? '❌ Це було б 5 + 4. Але потрібно помножити!' : '❌ That would be 5 + 4. But you need to multiply!',
              emoji: '😬',
            },
            {
              text: '20',
              points: 10,
              feedback: language === 'uk' ? '✅ Блискуче! 5 × 4 = 20 квіток!' : '✅ Brilliant! 5 × 4 = 20 flowers!',
              emoji: '🌻',
            },
            {
              text: '15',
              points: 0,
              feedback: language === 'uk' ? '❌ Спробуй ще: 5 рядів × 4 квітки = ?' : '❌ Try again: 5 rows × 4 flowers = ?',
              emoji: '🌸',
            },
          ],
        },
      ],
    },
    english: {
      title: language === 'uk' ? '🎮 Англійські пригоди' : '🎮 English Adventures',
      scenarios: [
        {
          id: '1',
          title: language === 'uk' ? 'У бібліотеці' : 'At the Library',
          description: language === 'uk'
            ? 'Яке слово означає "місце, де зберігаються книги"?'
            : 'Which word means "a place where books are kept"?',
          emoji: '📚',
          choices: [
            {
              text: 'Restaurant',
              points: 0,
              feedback: language === 'uk' ? '❌ Ні, ресторан - це місце, де їдять!' : '❌ No, a restaurant is where you eat!',
              emoji: '🍽️',
            },
            {
              text: 'Library',
              points: 10,
              feedback: language === 'uk' ? '✅ Правильно! Library - це бібліотека!' : '✅ Correct! A library is for books!',
              emoji: '📖',
            },
            {
              text: 'Park',
              points: 0,
              feedback: language === 'uk' ? '❌ Парк - це місце для гри!' : '❌ A park is a place to play!',
              emoji: '🌳',
            },
          ],
        },
        {
          id: '2',
          title: language === 'uk' ? 'Погода' : 'Weather',
          description: language === 'uk'
            ? 'Завершіть речення: "When it rains, I use an ___"'
            : 'Complete the sentence: "When it rains, I use an ___"',
          emoji: '☔',
          choices: [
            {
              text: 'apple',
              points: 0,
              feedback: language === 'uk' ? '❌ Яблуко не допоможе під дощем!' : '❌ An apple won\'t help in the rain!',
              emoji: '🍎',
            },
            {
              text: 'umbrella',
              points: 10,
              feedback: language === 'uk' ? '✅ Відмінно! Парасолька (umbrella) захищає від дощу!' : '✅ Perfect! An umbrella protects from rain!',
              emoji: '🌂',
            },
            {
              text: 'airplane',
              points: 0,
              feedback: language === 'uk' ? '❌ Літак (airplane) - це транспорт!' : '❌ An airplane is transportation!',
              emoji: '✈️',
            },
          ],
        },
        {
          id: '3',
          title: language === 'uk' ? 'Тваринний світ' : 'Animal World',
          description: language === 'uk'
            ? 'Яка тварина може літати?'
            : 'Which animal can fly?',
          emoji: '🦅',
          choices: [
            {
              text: 'Fish',
              points: 0,
              feedback: language === 'uk' ? '❌ Риба плаває, а не літає!' : '❌ Fish swim, they don\'t fly!',
              emoji: '🐟',
            },
            {
              text: 'Bird',
              points: 10,
              feedback: language === 'uk' ? '✅ Так! Птах (Bird) може літати!' : '✅ Yes! A bird can fly!',
              emoji: '🐦',
            },
            {
              text: 'Dog',
              points: 0,
              feedback: language === 'uk' ? '❌ Собаки бігають, але не літають!' : '❌ Dogs run, but they can\'t fly!',
              emoji: '🐕',
            },
          ],
        },
      ],
    },
    ukrainian: {
      title: language === 'uk' ? '🎮 Українські пригоди' : '🎮 Ukrainian Adventures',
      scenarios: [
        {
          id: '1',
          title: language === 'uk' ? 'Українські символи' : 'Ukrainian Symbols',
          description: language === 'uk'
            ? 'Які кольори на прапорі України?'
            : 'What colors are on the Ukrainian flag?',
          emoji: '🇺🇦',
          choices: [
            {
              text: language === 'uk' ? 'Червоний і білий' : 'Red and white',
              points: 0,
              feedback: language === 'uk' ? '❌ Ні, це інший прапор!' : '❌ No, that\'s a different flag!',
              emoji: '🔴',
            },
            {
              text: language === 'uk' ? 'Синій і жовтий' : 'Blue and yellow',
              points: 10,
              feedback: language === 'uk' ? '✅ Правильно! Синій як небо, жовтий як пшениця!' : '✅ Correct! Blue like sky, yellow like wheat!',
              emoji: '💙💛',
            },
            {
              text: language === 'uk' ? 'Зелений і білий' : 'Green and white',
              points: 0,
              feedback: language === 'uk' ? '❌ Спробуй ще раз!' : '❌ Try again!',
              emoji: '🟢',
            },
          ],
        },
        {
          id: '2',
          title: language === 'uk' ? 'Українська абетка' : 'Ukrainian Alphabet',
          description: language === 'uk'
            ? 'Скільки літер в українській абетці?'
            : 'How many letters in the Ukrainian alphabet?',
          emoji: '🔤',
          choices: [
            {
              text: '26',
              points: 0,
              feedback: language === 'uk' ? '❌ Це в англійській абетці!' : '❌ That\'s the English alphabet!',
              emoji: '🅰️',
            },
            {
              text: '33',
              points: 10,
              feedback: language === 'uk' ? '✅ Чудово! В українській абетці 33 літери!' : '✅ Excellent! Ukrainian alphabet has 33 letters!',
              emoji: '📝',
            },
            {
              text: '30',
              points: 0,
              feedback: language === 'uk' ? '❌ Трохи більше!' : '❌ A bit more!',
              emoji: '🤔',
            },
          ],
        },
        {
          id: '3',
          title: language === 'uk' ? 'Українська кухня' : 'Ukrainian Cuisine',
          description: language === 'uk'
            ? 'Яка страва є символом України?'
            : 'Which dish is a symbol of Ukraine?',
          emoji: '🍲',
          choices: [
            {
              text: language === 'uk' ? 'Піца' : 'Pizza',
              points: 0,
              feedback: language === 'uk' ? '❌ Це італійська страва!' : '❌ That\'s an Italian dish!',
              emoji: '🍕',
            },
            {
              text: language === 'uk' ? 'Борщ' : 'Borscht',
              points: 10,
              feedback: language === 'uk' ? '✅ Так! Борщ - це українська національна страва!' : '✅ Yes! Borscht is a Ukrainian national dish!',
              emoji: '🥘',
            },
            {
              text: language === 'uk' ? 'Суші' : 'Sushi',
              points: 0,
              feedback: language === 'uk' ? '❌ Це японська страва!' : '❌ That\'s a Japanese dish!',
              emoji: '🍣',
            },
          ],
        },
      ],
    },
  };

  const data = exerciseData[subject];
  const [currentScenario, setCurrentScenario] = useState(0);
  const [totalPoints, setTotalPoints] = useState(0);
  const [combo, setCombo] = useState(0);
  const [selectedChoice, setSelectedChoice] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [showPointsAnimation, setShowPointsAnimation] = useState(false);
  const [earnedPoints, setEarnedPoints] = useState(0);
  const [isComplete, setIsComplete] = useState(false);

  const handleChoice = (choice: Choice, index: number) => {
    setSelectedChoice(index);
    setFeedback(choice.feedback);

    if (choice.points > 0) {
      const comboBonus = combo * 5;
      const points = choice.points + comboBonus;
      setEarnedPoints(points);
      setTotalPoints(totalPoints + points);
      setCombo(combo + 1);
      setShowPointsAnimation(true);

      setTimeout(() => setShowPointsAnimation(false), 1500);
    } else {
      setCombo(0);
    }

    setTimeout(() => {
      if (currentScenario < data.scenarios.length - 1) {
        setCurrentScenario(currentScenario + 1);
        setSelectedChoice(null);
        setFeedback(null);
      } else {
        setIsComplete(true);
        setTimeout(() => {
          onComplete(totalPoints);
        }, 2500);
      }
    }, 2500);
  };

  if (isComplete) {
    const maxPoints = data.scenarios.length * 10 + (data.scenarios.length * (data.scenarios.length - 1) / 2) * 5;
    const percentage = Math.round((totalPoints / maxPoints) * 100);

    return (
      <div className="text-center py-12 px-4">
        <div className="mb-8">
          <Trophy size={80} className="text-yellow-500 mx-auto mb-4 animate-bounce" />
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">
            {percentage >= 80
              ? language === 'uk' ? '🎉 Легендарно!' : '🎉 Legendary!'
              : percentage >= 60
              ? language === 'uk' ? '⭐ Чудово!' : '⭐ Awesome!'
              : language === 'uk' ? '💪 Добра спроба!' : '💪 Good Try!'}
          </h2>
          <div className="flex items-center justify-center gap-4 mb-4">
            <div className="bg-yellow-100 px-6 py-3 rounded-2xl border-4 border-yellow-400">
              <p className="text-sm text-gray-600 font-bold">{language === 'uk' ? 'Всього балів' : 'Total Points'}</p>
              <p className="text-4xl font-bold text-yellow-600">{totalPoints}</p>
            </div>
            <div className="bg-purple-100 px-6 py-3 rounded-2xl border-4 border-purple-400">
              <p className="text-sm text-gray-600 font-bold">{language === 'uk' ? 'Макс. комбо' : 'Max Combo'}</p>
              <p className="text-4xl font-bold text-purple-600">{combo}</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const scenario = data.scenarios[currentScenario];

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-8">
      {/* Header Stats */}
      <div className="flex justify-between items-center mb-6">
        <div className="flex gap-4">
          <div className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-4 md:px-6 py-2 md:py-3 rounded-2xl shadow-lg flex items-center gap-2 border-4 border-white">
            <Star size={24} className="animate-pulse" />
            <span className="font-bold text-lg md:text-xl">{totalPoints}</span>
          </div>
          {combo > 0 && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-4 md:px-6 py-2 md:py-3 rounded-2xl shadow-lg flex items-center gap-2 border-4 border-white"
            >
              <Zap size={24} className="animate-bounce" />
              <span className="font-bold text-lg md:text-xl">x{combo}</span>
            </motion.div>
          )}
        </div>
        <div className="text-lg font-bold text-gray-600">
          {currentScenario + 1}/{data.scenarios.length}
        </div>
      </div>

      <h2 className="text-2xl md:text-4xl font-bold text-gray-800 mb-8 text-center">
        {data.title}
      </h2>

      {/* Points Animation */}
      {showPointsAnimation && (
        <motion.div
          initial={{ y: 0, opacity: 1, scale: 1 }}
          animate={{ y: -100, opacity: 0, scale: 1.5 }}
          className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-6xl font-bold text-yellow-500 z-50 pointer-events-none"
        >
          +{earnedPoints} 🎯
        </motion.div>
      )}

      {/* Scenario Card */}
      <div className="bg-gradient-to-br from-blue-100 via-purple-100 to-pink-100 rounded-3xl p-6 md:p-8 mb-8 shadow-2xl border-4 border-white">
        <div className="text-center mb-6">
          <div className="text-6xl md:text-8xl mb-4 animate-bounce">{scenario.emoji}</div>
          <h3 className="text-2xl md:text-3xl font-bold text-gray-800 mb-4">{scenario.title}</h3>
          <p className="text-lg md:text-xl text-gray-700 leading-relaxed">{scenario.description}</p>
        </div>

        {/* Choices */}
        <div className="grid grid-cols-1 gap-4 mt-8">
          {scenario.choices.map((choice, index) => {
            const isSelected = selectedChoice === index;
            const isCorrect = choice.points > 0;

            return (
              <motion.button
                key={index}
                onClick={() => !selectedChoice && handleChoice(choice, index)}
                disabled={selectedChoice !== null}
                whileHover={{ scale: selectedChoice === null ? 1.02 : 1 }}
                whileTap={{ scale: selectedChoice === null ? 0.98 : 1 }}
                className={`p-6 rounded-2xl font-bold text-lg md:text-xl transition-all shadow-lg border-4 ${
                  isSelected
                    ? isCorrect
                      ? 'bg-gradient-to-r from-green-400 to-emerald-500 text-white border-green-300 scale-105'
                      : 'bg-gradient-to-r from-red-400 to-pink-500 text-white border-red-300'
                    : 'bg-white text-gray-800 border-purple-300 hover:border-purple-500'
                } ${selectedChoice !== null ? 'cursor-not-allowed' : ''}`}
              >
                <div className="flex items-center justify-between">
                  <span>{choice.text}</span>
                  <span className="text-3xl md:text-4xl">{isSelected ? choice.emoji : '🎯'}</span>
                </div>
              </motion.button>
            );
          })}
        </div>

        {/* Feedback */}
        {feedback && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mt-6 bg-white rounded-2xl p-6 shadow-xl border-4 border-purple-300"
          >
            <p className="text-lg md:text-xl text-gray-800 text-center font-bold">{feedback}</p>
          </motion.div>
        )}
      </div>

      {/* Progress Bar */}
      <div className="bg-white rounded-full h-4 overflow-hidden border-4 border-purple-300 shadow-lg">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${((currentScenario + 1) / data.scenarios.length) * 100}%` }}
          className="h-full bg-gradient-to-r from-purple-500 via-pink-500 to-yellow-500"
        />
      </div>
    </div>
  );
}
