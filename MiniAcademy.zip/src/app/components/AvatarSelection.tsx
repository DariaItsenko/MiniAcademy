import { useState } from 'react';
import { Check } from 'lucide-react';
import { AvatarWrapper } from './AvatarWrapper';

interface AvatarSelectionProps {
  onSelect: (avatar: string) => void;
}

export function AvatarSelection({ onSelect }: AvatarSelectionProps) {
  const [selectedAvatar, setSelectedAvatar] = useState<string | null>(null);

  const avatars = [
    { id: 'boy', name: 'Boy', emoji: '👦' },
    { id: 'girl', name: 'Girl', emoji: '👧' },
    { id: 'cat', name: 'Cat', emoji: '🐱' },
    { id: 'dog', name: 'Dog', emoji: '🐶' },
    { id: 'bear', name: 'Bear', emoji: '🐻' },
    { id: 'fox', name: 'Fox', emoji: '🦊' },
    { id: 'rabbit', name: 'Rabbit', emoji: '🐰' },
    { id: 'panda', name: 'Panda', emoji: '🐼' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-300 via-pink-300 to-blue-300 flex flex-col items-center justify-center p-8">
      <div className="bg-white rounded-3xl shadow-2xl p-12 max-w-6xl w-full border-8 border-purple-400">
        <h1 className="text-5xl font-bold text-center mb-4 text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600">
          Choose Your Avatar! 🎭
        </h1>
        <p className="text-center text-gray-600 text-xl mb-12">
          Pick your character and watch them come alive!
        </p>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
          {avatars.map((avatar) => (
            <button
              key={avatar.id}
              onClick={() => setSelectedAvatar(avatar.id)}
              className={`relative p-6 rounded-3xl transition-all transform hover:scale-105 border-4 ${
                selectedAvatar === avatar.id
                  ? 'bg-gradient-to-br from-yellow-200 to-orange-200 border-orange-500 shadow-2xl scale-105'
                  : 'bg-gradient-to-br from-blue-100 to-purple-100 border-purple-300 hover:shadow-xl'
              }`}
            >
              <div className="flex flex-col items-center gap-4">
                <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-4 shadow-lg w-full">
                  <AvatarWrapper 
                    baseAvatar={avatar.id} 
                    size="small"
                    animated={true}
                    showRotation={false}
                  />
                </div>
                <span className="text-2xl font-bold text-gray-800">{avatar.name}</span>
                {selectedAvatar === avatar.id && (
                  <div className="absolute top-2 right-2 bg-green-500 rounded-full p-2">
                    <Check size={24} className="text-white" />
                  </div>
                )}
              </div>
            </button>
          ))}
        </div>

        {selectedAvatar && (
          <div className="flex flex-col items-center gap-6">
            <div className="bg-gradient-to-br from-purple-100 to-pink-100 rounded-3xl p-8 border-4 border-purple-300 w-full max-w-2xl">
              <h3 className="text-2xl font-bold text-center mb-4 text-purple-700">
                ✨ Your New Avatar ✨
              </h3>
              <AvatarWrapper 
                baseAvatar={selectedAvatar} 
                size="large"
                animated={true}
                showRotation={false}
                autoRotate={false}
              />
            </div>
            <button
              onClick={() => onSelect(selectedAvatar)}
              className="bg-gradient-to-r from-green-400 to-blue-500 text-white px-12 py-4 rounded-full text-2xl font-bold shadow-lg hover:shadow-2xl transition-all transform hover:scale-110"
            >
              Start Adventure! 🚀
            </button>
          </div>
        )}
      </div>
    </div>
  );
}