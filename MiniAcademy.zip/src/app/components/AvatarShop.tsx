import { useState } from 'react';
import { ArrowLeft, Star, ShoppingBag, Check } from 'lucide-react';
import { AvatarWrapper } from './AvatarWrapper';

interface AvatarShopProps {
  onBack: () => void;
  currentAvatar: string;
  ownedItems: string[];
  points: number;
  onPurchase: (itemId: string, cost: number) => void;
  onEquip: (itemId: string) => void;
  equippedItems: string[];
}

interface ShopItem {
  id: string;
  name: string;
  category: 'hair' | 'clothes' | 'accessories' | 'skin';
  cost: number;
  emoji: string;
}

export function AvatarShop({
  onBack,
  currentAvatar,
  ownedItems,
  points,
  onPurchase,
  onEquip,
  equippedItems,
}: AvatarShopProps) {
  const [selectedCategory, setSelectedCategory] = useState<'hair' | 'clothes' | 'accessories' | 'skin'>('hair');
  const [previewItem, setPreviewItem] = useState<string | null>(null);

  const shopItems: ShopItem[] = [
    // Hair
    { id: 'curly-blonde', name: 'Curly Blonde', category: 'hair', cost: 50, emoji: '👱' },
    { id: 'curly-brown', name: 'Curly Brown', category: 'hair', cost: 50, emoji: '👨' },
    { id: 'curly-black', name: 'Curly Black', category: 'hair', cost: 50, emoji: '👨‍🦱' },
    { id: 'long-blonde', name: 'Long Blonde', category: 'hair', cost: 75, emoji: '👱‍♀️' },
    { id: 'long-brown', name: 'Long Brown', category: 'hair', cost: 75, emoji: '👩' },
    { id: 'long-red', name: 'Long Red', category: 'hair', cost: 100, emoji: '👩‍🦰' },
    { id: 'short-blue', name: 'Short Blue', category: 'hair', cost: 80, emoji: '💙' },
    { id: 'short-pink', name: 'Short Pink', category: 'hair', cost: 80, emoji: '💖' },
    
    // Clothes
    { id: 'tshirt-blue', name: 'Blue T-Shirt', category: 'clothes', cost: 30, emoji: '👕' },
    { id: 'tshirt-red', name: 'Red T-Shirt', category: 'clothes', cost: 30, emoji: '👕' },
    { id: 'dress-pink', name: 'Pink Dress', category: 'clothes', cost: 60, emoji: '👗' },
    { id: 'dress-blue', name: 'Blue Dress', category: 'clothes', cost: 60, emoji: '👗' },
    { id: 'hoodie-green', name: 'Green Hoodie', category: 'clothes', cost: 80, emoji: '🧥' },
    { id: 'hoodie-pink', name: 'Pink Hoodie', category: 'clothes', cost: 80, emoji: '🧥' },
    { id: 'shirt-blue', name: 'Blue Shirt', category: 'clothes', cost: 50, emoji: '👔' },
    
    // Accessories
    { id: 'glasses-round', name: 'Round Glasses', category: 'accessories', cost: 40, emoji: '👓' },
    { id: 'glasses-cool', name: 'Cool Shades', category: 'accessories', cost: 60, emoji: '🕶️' },
    { id: 'hat-red', name: 'Red Hat', category: 'accessories', cost: 50, emoji: '🎩' },
    { id: 'cap-blue', name: 'Blue Cap', category: 'accessories', cost: 45, emoji: '🧢' },
    { id: 'crown-gold', name: 'Gold Crown', category: 'accessories', cost: 150, emoji: '👑' },
    { id: 'backpack-blue', name: 'Blue Backpack', category: 'accessories', cost: 70, emoji: '🎒' },
    
    // Skin Tones
    { id: 'skin-light', name: 'Light Skin', category: 'skin', cost: 20, emoji: '🏻' },
    { id: 'skin-medium', name: 'Medium Skin', category: 'skin', cost: 20, emoji: '🏽' },
    { id: 'skin-dark', name: 'Dark Skin', category: 'skin', cost: 20, emoji: '🏿' },
    { id: 'skin-rainbow', name: 'Rainbow Skin ✨', category: 'skin', cost: 200, emoji: '🌈' },
  ];

  const categories = [
    { id: 'hair', name: 'Hair', emoji: '💇' },
    { id: 'clothes', name: 'Clothes', emoji: '👕' },
    { id: 'accessories', name: 'Accessories', emoji: '🎩' },
    { id: 'skin', name: 'Skin Tone', emoji: '🎨' },
  ];

  const filteredItems = shopItems.filter(item => item.category === selectedCategory);

  const handlePurchase = (item: ShopItem) => {
    onPurchase(item.id, item.cost);
  };

  const handleEquip = (item: ShopItem) => {
    onEquip(item.id);
  };

  // Get currently equipped items for avatar preview
  const getEquippedSkin = () => {
    const skinItem = equippedItems.find(id => id.startsWith('skin-'));
    return skinItem ? skinItem.replace('skin-', '') : 'light';
  };

  const getEquippedHair = () => {
    const hairItem = equippedItems.find(id => shopItems.find(si => si.id === id && si.category === 'hair'));
    return hairItem || 'none';
  };

  const getEquippedClothes = () => {
    const clothesItem = equippedItems.find(id => shopItems.find(si => si.id === id && si.category === 'clothes'));
    return clothesItem || 'none';
  };

  const getEquippedAccessories = () => {
    return equippedItems.filter(id => shopItems.find(si => si.id === id && si.category === 'accessories'));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-200 via-purple-200 to-blue-200 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <button
            onClick={onBack}
            className="flex items-center gap-2 bg-white px-6 py-3 rounded-full shadow-lg hover:shadow-xl transition-all transform hover:scale-105 border-4 border-purple-400 font-bold"
          >
            <ArrowLeft size={24} className="text-purple-600" />
            <span className="text-gray-800">Back</span>
          </button>
          
          <div className="bg-white px-8 py-4 rounded-full shadow-lg border-4 border-yellow-400">
            <div className="flex items-center gap-3">
              <Star size={28} className="text-yellow-500 fill-yellow-500" />
              <span className="text-3xl font-bold text-gray-800">{points}</span>
              <span className="text-xl text-gray-600">Points</span>
            </div>
          </div>
        </div>

        <h1 className="text-6xl font-bold text-center mb-12 text-transparent bg-clip-text bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600">
          Avatar Shop 🛍️
        </h1>

        <div className="grid md:grid-cols-3 gap-8">
          {/* Left: Avatar Preview */}
          <div className="md:col-span-1">
            <div className="bg-white rounded-3xl p-8 shadow-2xl border-8 border-purple-400 sticky top-8">
              <h2 className="text-3xl font-bold text-center mb-6 text-purple-700">
                Your Avatar
              </h2>
              <div className="bg-gradient-to-br from-purple-100 to-pink-100 rounded-2xl p-6 flex justify-center relative">
                <AvatarWrapper
                  baseAvatar={currentAvatar}
                  skinTone={getEquippedSkin()}
                  hair={getEquippedHair()}
                  clothes={getEquippedClothes()}
                  accessories={getEquippedAccessories()}
                  size="medium"
                  showRotation={true}
                  animated={true}
                  previewItem={previewItem}
                />
                {previewItem && (
                  <div className="absolute top-2 right-2 bg-yellow-400 text-gray-800 px-4 py-2 rounded-full font-bold text-sm shadow-lg animate-bounce">
                    👁️ Previewing
                  </div>
                )}
              </div>
              <div className="mt-6 p-4 bg-blue-100 rounded-xl">
                <h3 className="font-bold text-lg mb-2 text-blue-800">Equipped Items:</h3>
                {equippedItems.length === 0 ? (
                  <p className="text-gray-600 text-sm">No items equipped yet!</p>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {equippedItems.map(itemId => {
                      const item = shopItems.find(si => si.id === itemId);
                      return (
                        <span key={itemId} className="bg-white px-3 py-1 rounded-full text-sm font-semibold border-2 border-blue-300">
                          {item?.emoji} {item?.name}
                        </span>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Right: Shop Items */}
          <div className="md:col-span-2">
            {/* Category Tabs */}
            <div className="flex gap-4 mb-8 flex-wrap">
              {categories.map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id as any)}
                  className={`px-8 py-4 rounded-2xl font-bold text-lg transition-all transform hover:scale-105 border-4 ${
                    selectedCategory === cat.id
                      ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white border-purple-600 shadow-xl scale-105'
                      : 'bg-white text-gray-700 border-purple-300 hover:shadow-lg'
                  }`}
                >
                  <span className="text-2xl mr-2">{cat.emoji}</span>
                  {cat.name}
                </button>
              ))}
            </div>

            {/* Shop Items Grid */}
            <div className="grid grid-cols-2 gap-6">
              {filteredItems.map(item => {
                const isOwned = ownedItems.includes(item.id);
                const isEquipped = equippedItems.includes(item.id);
                const canAfford = points >= item.cost;

                return (
                  <div
                    key={item.id}
                    onMouseEnter={() => !isOwned && setPreviewItem(item.id)}
                    onMouseLeave={() => setPreviewItem(null)}
                    className={`bg-white rounded-3xl p-6 shadow-lg border-4 transition-all transform hover:scale-105 cursor-pointer ${
                      previewItem === item.id
                        ? 'border-yellow-500 shadow-2xl scale-105'
                        : isEquipped
                        ? 'border-green-500 bg-green-50'
                        : isOwned
                        ? 'border-blue-400'
                        : 'border-purple-300'
                    }`}
                  >
                    <div className="text-center mb-4">
                      <div className="text-6xl mb-3 transition-transform transform hover:scale-125">
                        {item.emoji}
                      </div>
                      <h3 className="font-bold text-xl text-gray-800">{item.name}</h3>
                      {previewItem === item.id && !isOwned && (
                        <p className="text-sm text-yellow-600 font-semibold mt-2 animate-pulse">
                          ✨ Hover to preview! ✨
                        </p>
                      )}
                    </div>

                    {isOwned ? (
                      <button
                        onClick={() => handleEquip(item)}
                        className={`w-full py-3 rounded-xl font-bold text-lg transition-all transform hover:scale-105 ${
                          isEquipped
                            ? 'bg-gradient-to-r from-red-400 to-pink-400 text-white'
                            : 'bg-gradient-to-r from-green-400 to-blue-400 text-white'
                        }`}
                      >
                        {isEquipped ? (
                          <>
                            <Check size={20} className="inline mr-2" />
                            Unequip
                          </>
                        ) : (
                          <>
                            <ShoppingBag size={20} className="inline mr-2" />
                            Equip
                          </>
                        )}
                      </button>
                    ) : (
                      <button
                        onClick={() => handlePurchase(item)}
                        disabled={!canAfford}
                        className={`w-full py-3 rounded-xl font-bold text-lg transition-all transform ${
                          canAfford
                            ? 'bg-gradient-to-r from-yellow-400 to-orange-400 text-white hover:scale-105 hover:shadow-xl'
                            : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                        }`}
                      >
                        <Star size={20} className="inline mr-2" />
                        {item.cost} Points
                      </button>
                    )}

                    {isOwned && (
                      <div className="mt-3 text-center">
                        <span className="inline-block bg-blue-500 text-white px-4 py-1 rounded-full text-sm font-bold">
                          Owned ✓
                        </span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}