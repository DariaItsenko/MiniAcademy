import { useState } from 'react';
import { DndProvider, useDrag, useDrop } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { useLanguage } from '../../contexts/LanguageContext';
import { CheckCircle, Trophy } from 'lucide-react';

interface Item {
  id: string;
  text: string;
  category: string;
  emoji: string;
}

interface Category {
  id: string;
  name: string;
  color: string;
}

interface DraggableItemProps {
  item: Item;
  isPlaced: boolean;
}

const DraggableItem = ({ item, isPlaced }: DraggableItemProps) => {
  const [{ isDragging }, drag] = useDrag(() => ({
    type: 'item',
    item: item,
    collect: (monitor) => ({
      isDragging: !!monitor.isDragging(),
    }),
  }), [item]);

  if (isPlaced) return null;

  return (
    <div
      ref={drag}
      className={`bg-white border-4 border-purple-300 rounded-2xl p-4 cursor-move shadow-lg transform hover:scale-105 transition-all ${
        isDragging ? 'opacity-50' : ''
      }`}
    >
      <div className="flex items-center gap-3">
        <span className="text-3xl">{item.emoji}</span>
        <span className="font-bold text-gray-800 text-lg">{item.text}</span>
      </div>
    </div>
  );
};

interface DropZoneProps {
  category: Category;
  items: Item[];
  onDrop: (item: Item, categoryId: string) => void;
}

const DropZone = ({ category, items, onDrop }: DropZoneProps) => {
  const [{ isOver }, drop] = useDrop(() => ({
    accept: 'item',
    drop: (item: Item) => onDrop(item, category.id),
    collect: (monitor) => ({
      isOver: !!monitor.isOver(),
    }),
  }), [category, onDrop]);

  return (
    <div
      ref={drop}
      className={`${category.color} rounded-3xl p-6 min-h-[200px] border-4 border-white shadow-xl transition-all ${
        isOver ? 'scale-105 shadow-2xl' : ''
      }`}
    >
      <h3 className="text-2xl font-bold text-white mb-4 text-center drop-shadow-md">
        {category.name}
      </h3>
      <div className="space-y-3">
        {items.map((item) => (
          <div
            key={item.id}
            className="bg-white/90 rounded-xl p-3 flex items-center gap-2 shadow-md"
          >
            <CheckCircle className="text-green-600" size={24} />
            <span className="text-2xl">{item.emoji}</span>
            <span className="font-bold text-gray-800">{item.text}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

interface DragDropCategorizeProps {
  onComplete: (score: number) => void;
  subject: 'math' | 'english' | 'ukrainian';
}

export function DragDropCategorize({ onComplete, subject }: DragDropCategorizeProps) {
  const { language } = useLanguage();

  // Load admin-created exercises from localStorage
  const loadAdminExercises = () => {
    const stored = localStorage.getItem('admin_interactive_exercises');
    if (stored) {
      const allExercises = JSON.parse(stored);
      // Filter for drag-drop exercises matching the current subject
      const dragDropExercises = allExercises.filter(
        (ex: any) => ex.type === 'drag-drop' && ex.subject === subject
      );
      return dragDropExercises;
    }
    return [];
  };

  const adminExercises = loadAdminExercises();
  
  // If admin exercises exist, use the first one; otherwise use default
  const hasAdminExercise = adminExercises.length > 0;
  
  const defaultExerciseData = {
    math: {
      title: language === 'uk' ? 'Розподіліть числа за категоріями' : 'Categorize Numbers',
      categories: [
        {
          id: 'even',
          name: language === 'uk' ? 'Парні числа' : 'Even Numbers',
          color: 'bg-gradient-to-br from-blue-400 to-blue-600',
        },
        {
          id: 'odd',
          name: language === 'uk' ? 'Непарні числа' : 'Odd Numbers',
          color: 'bg-gradient-to-br from-purple-400 to-purple-600',
        },
      ],
      items: [
        { id: '1', text: '2', category: 'even', emoji: '2️⃣' },
        { id: '2', text: '5', category: 'odd', emoji: '5️⃣' },
        { id: '3', text: '8', category: 'even', emoji: '8️⃣' },
        { id: '4', text: '7', category: 'odd', emoji: '7️⃣' },
        { id: '5', text: '12', category: 'even', emoji: '🔢' },
        { id: '6', text: '15', category: 'odd', emoji: '🔢' },
        { id: '7', text: '20', category: 'even', emoji: '🔢' },
        { id: '8', text: '11', category: 'odd', emoji: '🔢' },
      ],
    },
    english: {
      title: language === 'uk' ? 'Розподіліть слова за категоріями' : 'Categorize Words',
      categories: [
        {
          id: 'animals',
          name: language === 'uk' ? 'Тварини' : 'Animals',
          color: 'bg-gradient-to-br from-green-400 to-green-600',
        },
        {
          id: 'food',
          name: language === 'uk' ? 'Їжа' : 'Food',
          color: 'bg-gradient-to-br from-orange-400 to-orange-600',
        },
      ],
      items: [
        { id: '1', text: 'Cat', category: 'animals', emoji: '🐱' },
        { id: '2', text: 'Apple', category: 'food', emoji: '🍎' },
        { id: '3', text: 'Dog', category: 'animals', emoji: '🐶' },
        { id: '4', text: 'Bread', category: 'food', emoji: '🍞' },
        { id: '5', text: 'Bird', category: 'animals', emoji: '🐦' },
        { id: '6', text: 'Cheese', category: 'food', emoji: '🧀' },
        { id: '7', text: 'Fish', category: 'animals', emoji: '🐟' },
        { id: '8', text: 'Pizza', category: 'food', emoji: '🍕' },
      ],
    },
    ukrainian: {
      title: language === 'uk' ? 'Розподіліть слова за категоріями' : 'Categorize Words (Ukrainian)',
      categories: [
        {
          id: 'colors',
          name: language === 'uk' ? 'Кольори' : 'Colors',
          color: 'bg-gradient-to-br from-pink-400 to-pink-600',
        },
        {
          id: 'numbers',
          name: language === 'uk' ? 'Числа' : 'Numbers',
          color: 'bg-gradient-to-br from-yellow-400 to-yellow-600',
        },
      ],
      items: [
        { id: '1', text: language === 'uk' ? 'Червоний' : 'Red', category: 'colors', emoji: '🔴' },
        { id: '2', text: language === 'uk' ? 'Один' : 'One', category: 'numbers', emoji: '1️⃣' },
        { id: '3', text: language === 'uk' ? 'Синій' : 'Blue', category: 'colors', emoji: '🔵' },
        { id: '4', text: language === 'uk' ? 'П\'ять' : 'Five', category: 'numbers', emoji: '5️⃣' },
        { id: '5', text: language === 'uk' ? 'Зелений' : 'Green', category: 'colors', emoji: '🟢' },
        { id: '6', text: language === 'uk' ? 'Десять' : 'Ten', category: 'numbers', emoji: '🔟' },
        { id: '7', text: language === 'uk' ? 'Жовтий' : 'Yellow', category: 'colors', emoji: '🟡' },
        { id: '8', text: language === 'uk' ? 'Три' : 'Three', category: 'numbers', emoji: '3️⃣' },
      ],
    },
  };

  const data = hasAdminExercise ? adminExercises[0] : defaultExerciseData[subject];
  
  // Initialize placedItems with all category IDs
  const initialPlacedItems: Record<string, Item[]> = {};
  data.categories.forEach((cat: Category) => {
    initialPlacedItems[cat.id] = [];
  });
  
  const [placedItems, setPlacedItems] = useState<Record<string, Item[]>>(initialPlacedItems);
  const [isComplete, setIsComplete] = useState(false);
  const [score, setScore] = useState(0);

  const handleDrop = (item: Item, categoryId: string) => {
    const newPlacedItems = { ...placedItems };
    
    // Remove item from other categories if already placed
    Object.keys(newPlacedItems).forEach((catId) => {
      newPlacedItems[catId] = newPlacedItems[catId].filter((i) => i.id !== item.id);
    });
    
    // Add to new category
    newPlacedItems[categoryId] = [...newPlacedItems[categoryId], item];
    setPlacedItems(newPlacedItems);

    // Check if all items are placed
    const totalPlaced = Object.values(newPlacedItems).reduce((sum, items) => sum + items.length, 0);
    if (totalPlaced === data.items.length) {
      // Calculate score
      let correct = 0;
      Object.keys(newPlacedItems).forEach((catId) => {
        newPlacedItems[catId].forEach((item) => {
          if (item.category === catId) {
            correct++;
          }
        });
      });
      setScore(correct);
      setIsComplete(true);
      
      setTimeout(() => {
        onComplete(correct);
      }, 2500);
    }
  };

  const placedItemIds = new Set(
    Object.values(placedItems).flat().map((item) => item.id)
  );

  if (isComplete) {
    const percentage = Math.round((score / data.items.length) * 100);
    return (
      <div className="text-center py-12 px-4">
        <div className="mb-8">
          <Trophy size={80} className="text-yellow-500 mx-auto mb-4" />
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">
            {percentage >= 80
              ? language === 'uk' ? '🎉 Чудово!' : '🎉 Excellent!'
              : percentage >= 60
              ? language === 'uk' ? '👍 Добре!' : '👍 Good Job!'
              : language === 'uk' ? '💪 Спробуй ще!' : '💪 Keep Trying!'}
          </h2>
          <p className="text-2xl text-gray-600">
            {language === 'uk' ? 'Правильних відповідей' : 'Correct Answers'}: {score}/{data.items.length}
          </p>
          <p className="text-xl text-gray-500 mt-2">
            {percentage}%
          </p>
        </div>
      </div>
    );
  }

  return (
    <DndProvider backend={HTML5Backend}>
      <div className="max-w-6xl mx-auto p-4 md:p-8">
        <h2 className="text-2xl md:text-4xl font-bold text-gray-800 mb-8 text-center">
          {data.title}
        </h2>

        {hasAdminExercise && (
          <div className="mb-4 text-center">
            <span className="inline-block bg-gradient-to-r from-purple-500 to-pink-500 text-white px-4 py-2 rounded-full font-bold text-sm shadow-lg">
              👨‍💼 {language === 'uk' ? 'Вправа від викладача' : 'Teacher-Created Exercise'}
            </span>
          </div>
        )}

        <div className="mb-8">
          <p className="text-center text-gray-600 text-lg mb-4">
            {language === 'uk'
              ? '🎯 Перетягніть елементи у відповідні категорії'
              : '🎯 Drag items to the correct categories'}
          </p>
        </div>

        {/* Items to drag */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
          {data.items.map((item) => (
            <DraggableItem
              key={item.id}
              item={item}
              isPlaced={placedItemIds.has(item.id)}
            />
          ))}
        </div>

        {/* Drop zones */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {data.categories.map((category) => (
            <DropZone
              key={category.id}
              category={category}
              items={placedItems[category.id] || []}
              onDrop={handleDrop}
            />
          ))}
        </div>
      </div>
    </DndProvider>
  );
}