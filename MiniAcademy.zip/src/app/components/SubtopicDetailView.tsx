import { useState } from 'react';
import { ArrowLeft, Video, BookOpen, Lightbulb, PenTool } from 'lucide-react';
import { Subtopic, WorkedExample } from '../data/topicDataBilingual';
import { EnhancedExerciseView } from './EnhancedExerciseView';
import { useLanguage } from '../contexts/LanguageContext';

interface SubtopicDetailViewProps {
  subtopic: Subtopic;
  groupColor: string;
  onBack: () => void;
  onCompleteExercises: (score: number) => void;
}

type Tab = 'videos' | 'lectures' | 'examples' | 'exercises';

export function SubtopicDetailView({
  subtopic,
  groupColor,
  onBack,
  onCompleteExercises
}: SubtopicDetailViewProps) {
  const [activeTab, setActiveTab] = useState<Tab>('videos');
  const [isExerciseMode, setIsExerciseMode] = useState(false);
  const { language } = useLanguage();

  const tabs = [
    { id: 'videos' as Tab, label: 'Videos', icon: Video, emoji: '🎬', count: subtopic.videos.length },
    { id: 'lectures' as Tab, label: 'Lectures', icon: BookOpen, emoji: '📖', count: subtopic.lectures.length },
    { id: 'examples' as Tab, label: 'Examples', icon: Lightbulb, emoji: '💡', count: subtopic.workedExamples.length },
    { id: 'exercises' as Tab, label: 'Practice', icon: PenTool, emoji: '✏️', count: subtopic.exercises.length }
  ];

  if (isExerciseMode) {
    return (
      <EnhancedExerciseView
        exercises={subtopic.exercises}
        subtopicTitle={subtopic.title[language]}
        onBack={() => setIsExerciseMode(false)}
        onComplete={onCompleteExercises}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-200 via-pink-200 to-yellow-200 p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <button
          onClick={onBack}
          className="flex items-center gap-2 bg-white px-6 py-3 rounded-full shadow-lg hover:shadow-xl transition-all transform hover:scale-105 mb-8 font-bold border-4 border-purple-300"
        >
          <ArrowLeft size={24} />
          Back to Topics
        </button>

        {/* Subtopic Header */}
        <div className="bg-white rounded-3xl shadow-2xl p-8 mb-8 border-8 border-yellow-400">
          <div className="flex items-center gap-6">
            <span className="text-9xl animate-bounce">{subtopic.emoji}</span>
            <div>
              <h1 className="text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600 mb-2">
                {subtopic.title[language]}
              </h1>
              <p className="text-2xl text-gray-600 font-medium">{subtopic.description[language]}</p>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-3xl shadow-2xl border-8 border-blue-400 overflow-hidden">
          <div className="grid grid-cols-4 bg-gradient-to-r from-blue-500 to-purple-500">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-6 px-4 font-bold text-lg transition-all relative ${
                  activeTab === tab.id
                    ? 'bg-white text-purple-600 scale-105'
                    : 'text-white hover:bg-white/20'
                }`}
              >
                <div className="flex flex-col items-center gap-2">
                  <span className="text-4xl">{tab.emoji}</span>
                  <span>{tab.label}</span>
                  <span className="text-sm bg-yellow-400 text-gray-800 px-3 py-1 rounded-full">
                    {tab.count}
                  </span>
                </div>
                {activeTab === tab.id && (
                  <div className="absolute bottom-0 left-0 right-0 h-2 bg-gradient-to-r from-yellow-400 to-orange-400" />
                )}
              </button>
            ))}
          </div>

          {/* Tab Content */}
          <div className="p-8">
            {activeTab === 'videos' && (
              <div className="space-y-6">
                <h2 className="text-3xl font-bold text-gray-800 mb-6 flex items-center gap-3">
                  <Video size={36} className="text-blue-500" />
                  Video Lessons
                </h2>
                {subtopic.videos.map((video) => (
                  <div
                    key={video.id}
                    className="bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-2xl border-4 border-blue-300 hover:border-blue-500 transition-all"
                  >
                    <div className="flex items-start gap-6">
                      <div className="text-8xl">{video.thumbnailEmoji}</div>
                      <div className="flex-1">
                        <h3 className="text-2xl font-bold text-gray-800 mb-2">{video.title[language]}</h3>
                        <p className="text-lg text-gray-600 mb-4">{video.description[language]}</p>
                        <div className="flex items-center gap-4">
                          <span className="bg-purple-500 text-white px-4 py-2 rounded-full font-bold">
                            ⏱️ {video.duration}
                          </span>
                          <button className="bg-gradient-to-r from-green-500 to-blue-500 text-white px-8 py-3 rounded-full font-bold shadow-lg hover:shadow-xl transition-all transform hover:scale-105">
                            ▶️ Watch Now
                          </button>
                        </div>
                      </div>
                    </div>
                    {/* Video placeholder - you can replace with actual iframe */}
                    <div className="mt-4 bg-gray-800 rounded-xl aspect-video flex items-center justify-center">
                      <p className="text-white text-2xl">📺 Video Player</p>
                    </div>
                  </div>
                ))}
                {subtopic.videos.length === 0 && (
                  <div className="text-center py-12">
                    <p className="text-2xl text-gray-500">No videos available yet. Check back soon! 🎬</p>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'lectures' && (
              <div className="space-y-6">
                <h2 className="text-3xl font-bold text-gray-800 mb-6 flex items-center gap-3">
                  <BookOpen size={36} className="text-green-500" />
                  Reading Material
                </h2>
                {subtopic.lectures.map((lecture) => (
                  <div
                    key={lecture.id}
                    className="bg-gradient-to-r from-green-50 to-blue-50 p-8 rounded-2xl border-4 border-green-300"
                  >
                    <h3 className="text-3xl font-bold text-gray-800 mb-6 flex items-center gap-3">
                      📚 {lecture.title[language]}
                    </h3>
                    
                    <div className="prose prose-lg max-w-none mb-8">
                      <div className="text-gray-700 whitespace-pre-line leading-relaxed text-lg">
                        {lecture.content[language]}
                      </div>
                    </div>

                    {lecture.keyPoints && lecture.keyPoints.length > 0 && (
                      <div className="bg-yellow-100 p-6 rounded-xl border-4 border-yellow-300 mb-6">
                        <h4 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                          ⭐ Key Points to Remember:
                        </h4>
                        <ul className="space-y-2">
                          {lecture.keyPoints.map((point, index) => (
                            <li key={index} className="flex items-start gap-3 text-lg">
                              <span className="text-2xl">✓</span>
                              <span className="text-gray-700 font-medium">{point[language]}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {lecture.examples && lecture.examples.length > 0 && (
                      <div className="bg-blue-100 p-6 rounded-xl border-4 border-blue-300">
                        <h4 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                          📝 Examples:
                        </h4>
                        <ul className="space-y-2">
                          {lecture.examples.map((example, index) => (
                            <li key={index} className="text-lg text-gray-700 font-mono bg-white p-3 rounded-lg">
                              {example}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                ))}
                {subtopic.lectures.length === 0 && (
                  <div className="text-center py-12">
                    <p className="text-2xl text-gray-500">No lectures available yet. Check back soon! 📖</p>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'examples' && (
              <div className="space-y-6">
                <h2 className="text-3xl font-bold text-gray-800 mb-6 flex items-center gap-3">
                  <Lightbulb size={36} className="text-yellow-500" />
                  Worked Examples
                </h2>
                {subtopic.workedExamples.map((example) => (
                  <div
                    key={example.id}
                    className="bg-gradient-to-r from-yellow-50 to-orange-50 p-8 rounded-2xl border-4 border-yellow-400"
                  >
                    <h3 className="text-3xl font-bold text-gray-800 mb-4 flex items-center gap-3">
                      💡 {example.title[language]}
                    </h3>
                    
                    <div className="bg-white p-6 rounded-xl border-4 border-purple-300 mb-6">
                      <p className="text-xl font-bold text-purple-600 mb-2">Problem:</p>
                      <p className="text-2xl text-gray-800 font-bold">{example.problem[language]}</p>
                    </div>

                    <div className="space-y-4 mb-6">
                      <p className="text-xl font-bold text-gray-800 flex items-center gap-2">
                        📋 Step-by-Step Solution:
                      </p>
                      {example.steps.map((step) => (
                        <div
                          key={step.stepNumber}
                          className="bg-white p-6 rounded-xl border-4 border-blue-300 transform hover:scale-102 transition-all"
                        >
                          <div className="flex items-start gap-4">
                            <div className="bg-blue-500 text-white w-12 h-12 rounded-full flex items-center justify-center font-bold text-xl flex-shrink-0">
                              {step.stepNumber}
                            </div>
                            <div className="flex-1">
                              <p className="text-lg text-gray-700 mb-3 font-medium">{step.explanation[language]}</p>
                              {step.calculation && (
                                <div className="bg-gray-100 p-4 rounded-lg font-mono text-lg mb-2 whitespace-pre">
                                  {step.calculation}
                                </div>
                              )}
                              {step.result && (
                                <p className="text-green-600 font-bold text-lg flex items-center gap-2">
                                  ✓ {step.result[language]}
                                </p>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>

                    <div className="bg-green-100 p-6 rounded-xl border-4 border-green-400">
                      <p className="text-xl font-bold text-green-700 mb-2">🎯 Final Answer:</p>
                      <p className="text-3xl font-bold text-green-600">{example.finalAnswer}</p>
                    </div>

                    {example.tips && example.tips.length > 0 && (
                      <div className="bg-purple-100 p-6 rounded-xl border-4 border-purple-300 mt-6">
                        <p className="text-xl font-bold text-purple-700 mb-3">💡 Helpful Tips:</p>
                        <ul className="space-y-2">
                          {example.tips.map((tip, index) => (
                            <li key={index} className="flex items-start gap-3">
                              <span className="text-xl">💭</span>
                              <span className="text-lg text-gray-700">{tip[language]}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                ))}
                {subtopic.workedExamples.length === 0 && (
                  <div className="text-center py-12">
                    <p className="text-2xl text-gray-500">No worked examples available yet. Check back soon! 💡</p>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'exercises' && (
              <div className="space-y-6">
                <h2 className="text-3xl font-bold text-gray-800 mb-6 flex items-center gap-3">
                  <PenTool size={36} className="text-purple-500" />
                  Practice Exercises
                </h2>
                
                <div className="bg-gradient-to-r from-purple-100 to-pink-100 p-8 rounded-2xl border-4 border-purple-400 text-center">
                  <p className="text-2xl font-bold text-gray-800 mb-6">
                    Ready to test your knowledge? 🚀
                  </p>
                  <p className="text-lg text-gray-600 mb-6">
                    Complete {subtopic.exercises.length} interactive exercises with hints and animations!
                  </p>
                  <button
                    onClick={() => setIsExerciseMode(true)}
                    className="bg-gradient-to-r from-green-500 to-blue-500 text-white px-12 py-6 rounded-full font-bold text-2xl shadow-2xl hover:shadow-3xl transition-all transform hover:scale-110 animate-pulse"
                  >
                    ✏️ Start Exercises
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {subtopic.exercises.map((exercise, index) => (
                    <div
                      key={exercise.id}
                      className="bg-white p-6 rounded-xl border-4 border-blue-300 hover:border-blue-500 transition-all"
                    >
                      <div className="flex items-center gap-3 mb-3">
                        <div className="bg-blue-500 text-white w-10 h-10 rounded-full flex items-center justify-center font-bold">
                          {index + 1}
                        </div>
                        <p className="text-lg font-bold text-gray-800">Exercise {index + 1}</p>
                      </div>
                      <p className="text-gray-600">
                        {exercise.question[language].length > 60 
                          ? exercise.question[language].substring(0, 60) + '...' 
                          : exercise.question[language]}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}