import { useState } from "react";
import { ArrowLeft, Plus, Trash2, Video, BookOpen, CheckSquare, ShoppingBag, Award, Link2, Gamepad2, GraduationCap } from "lucide-react";
import { CurriculumManager } from "./admin/CurriculumManager";

interface AdminPanelProps {
  onBack: () => void;
  onNavigateToInteractive?: () => void;
  onLogout?: () => void;
}

interface Badge {
  id: string;
  name: string;
  description: string;
  emoji: string;
  category: 'achievement' | 'milestone' | 'special';
  requirement: string;
  pointsRequired?: number;
}

interface MatchingExercise {
  id: string;
  subject: 'math' | 'english' | 'ukrainian';
  level: number;
  question: string;
  leftColumn: string[];
  rightColumn: string[];
  correctMatches: number[]; // indices mapping left to right
  hint: string;
  explanation: string;
}

export function EnhancedAdminPanel({ onBack, onNavigateToInteractive, onLogout }: AdminPanelProps) {
  const [activeSection, setActiveSection] = useState<"badges" | "matching" | "curriculum">("curriculum");
  const [selectedSubject, setSelectedSubject] = useState<'math' | 'english' | 'ukrainian' | null>(null);

  // Badges State
  const [badges, setBadges] = useState<Badge[]>(() => {
    const stored = localStorage.getItem("admin_badges");
    return stored ? JSON.parse(stored) : [
      { id: 'first-star', name: 'First Star', description: 'Earn your first star!', emoji: '⭐', category: 'milestone', requirement: 'Earn 1 star' },
      { id: 'math-master', name: 'Math Master', description: 'Complete all math levels', emoji: '🧮', category: 'achievement', requirement: 'Complete Math subject' },
      { id: 'streak-7', name: '7-Day Streak', description: 'Learn for 7 days in a row!', emoji: '🔥', category: 'milestone', requirement: '7 day streak' },
    ];
  });

  const [newBadge, setNewBadge] = useState<Badge>({
    id: '',
    name: '',
    description: '',
    emoji: '',
    category: 'achievement',
    requirement: ''
  });

  // Matching Exercises State
  const [matchingExercises, setMatchingExercises] = useState<MatchingExercise[]>(() => {
    const stored = localStorage.getItem("admin_matching_exercises");
    return stored ? JSON.parse(stored) : [];
  });

  const [newMatching, setNewMatching] = useState<MatchingExercise>({
    id: '',
    subject: 'math',
    level: 1,
    question: '',
    leftColumn: ['', '', '', ''],
    rightColumn: ['', '', '', ''],
    correctMatches: [0, 1, 2, 3],
    hint: '',
    explanation: ''
  });

  // Save functions
  const saveBadges = (newBadges: Badge[]) => {
    localStorage.setItem("admin_badges", JSON.stringify(newBadges));
  };

  const saveMatchingExercises = (exercises: MatchingExercise[]) => {
    localStorage.setItem("admin_matching_exercises", JSON.stringify(exercises));
  };

  // Badge Functions
  const handleAddBadge = () => {
    if (!newBadge.id || !newBadge.name || !newBadge.description || !newBadge.emoji) {
      alert("Please fill in all badge fields!");
      return;
    }

    const updated = [...badges, { ...newBadge }];
    setBadges(updated);
    saveBadges(updated);
    setNewBadge({
      id: '',
      name: '',
      description: '',
      emoji: '',
      category: 'achievement',
      requirement: ''
    });
    alert("✅ Badge added successfully!");
  };

  const handleDeleteBadge = (id: string) => {
    if (confirm("Delete this badge?")) {
      const updated = badges.filter(b => b.id !== id);
      setBadges(updated);
      saveBadges(updated);
    }
  };

  // Matching Exercise Functions
  const handleAddMatchingExercise = () => {
    if (!newMatching.question || !newMatching.hint) {
      alert("Please fill in required fields!");
      return;
    }

    // Validate that all columns are filled
    const allLeftFilled = newMatching.leftColumn.every(item => item.trim() !== '');
    const allRightFilled = newMatching.rightColumn.every(item => item.trim() !== '');
    
    if (!allLeftFilled || !allRightFilled) {
      alert("Please fill in all column items!");
      return;
    }

    const exercise = {
      ...newMatching,
      id: `match-${Date.now()}`,
    };

    const updated = [...matchingExercises, exercise];
    setMatchingExercises(updated);
    saveMatchingExercises(updated);
    setNewMatching({
      id: '',
      subject: 'math',
      level: 1,
      question: '',
      leftColumn: ['', '', '', ''],
      rightColumn: ['', '', '', ''],
      correctMatches: [0, 1, 2, 3],
      hint: '',
      explanation: ''
    });
    alert("✅ Matching exercise added successfully!");
  };

  const handleDeleteMatchingExercise = (id: string) => {
    if (confirm("Delete this exercise?")) {
      const updated = matchingExercises.filter(ex => ex.id !== id);
      setMatchingExercises(updated);
      saveMatchingExercises(updated);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-300 via-red-300 to-pink-400 p-2 sm:p-4 md:p-8">
      <div className="flex flex-col sm:flex-row gap-2 sm:gap-4 mb-4 sm:mb-6">
        <button
          onClick={onBack}
          className="flex items-center justify-center gap-2 bg-white px-4 sm:px-6 py-2 sm:py-3 rounded-full shadow-lg hover:shadow-xl transition-all font-bold transform hover:scale-105 border-4 border-orange-400 text-sm sm:text-base"
        >
          <ArrowLeft size={20} />
          <span className="hidden sm:inline">Back to Home</span>
          <span className="sm:hidden">Back</span>
        </button>

        {onLogout && (
          <button
            onClick={onLogout}
            className="flex items-center justify-center gap-2 bg-red-500 px-4 sm:px-6 py-2 sm:py-3 rounded-full shadow-lg hover:shadow-xl transition-all text-white font-bold transform hover:scale-105 text-sm sm:text-base"
          >
            🚪 Logout
          </button>
        )}
      </div>

      <div className="bg-white rounded-2xl sm:rounded-3xl shadow-2xl p-3 sm:p-6 md:p-8 max-w-7xl mx-auto border-4 sm:border-8 border-yellow-400">
        <div className="flex items-center gap-2 sm:gap-4 mb-4 sm:mb-8">
          <div className="text-4xl sm:text-7xl">👨‍💼</div>
          <div>
            <h1 className="text-2xl sm:text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600">
              Enhanced Admin Panel
            </h1>
            <p className="text-sm sm:text-xl text-gray-600 font-medium">Manage badges and exercises</p>
          </div>
        </div>

        {/* Navigate to Interactive Exercises Admin */}
        {onNavigateToInteractive && (
          <div className="mb-8">
            <button
              onClick={onNavigateToInteractive}
              className="w-full bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 text-white p-8 rounded-3xl shadow-2xl hover:shadow-3xl transition-all transform hover:scale-105 border-6 border-white"
            >
              <div className="flex items-center justify-center gap-6">
                <Gamepad2 size={64} className="animate-bounce" />
                <div className="text-left">
                  <h3 className="text-3xl font-bold mb-2">🎨 Interactive Exercise Builder</h3>
                  <p className="text-lg opacity-90">
                    Create Drag & Drop, Puzzles, Click Objects, Matching & Simulations
                  </p>
                </div>
                <div className="text-6xl animate-pulse">→</div>
              </div>
            </button>
          </div>
        )}

        {/* Section Tabs */}
        <div className="grid grid-cols-2 gap-4 mb-8">
          <button
            onClick={() => setActiveSection("badges")}
            className={`py-6 px-6 rounded-2xl font-bold text-lg transition-all transform hover:scale-105 ${
              activeSection === "badges"
                ? "bg-gradient-to-r from-yellow-500 to-orange-500 text-white shadow-xl scale-105"
                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            }`}
          >
            <Award className="mx-auto mb-2" size={32} />
            Custom Badges
          </button>
          <button
            onClick={() => setActiveSection("matching")}
            className={`py-6 px-6 rounded-2xl font-bold text-lg transition-all transform hover:scale-105 ${
              activeSection === "matching"
                ? "bg-gradient-to-r from-blue-500 to-purple-500 text-white shadow-xl scale-105"
                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            }`}
          >
            <Link2 className="mx-auto mb-2" size={32} />
            Matching Exercises
          </button>
          <button
            onClick={() => setActiveSection("curriculum")}
            className={`py-6 px-6 rounded-2xl font-bold text-lg transition-all transform hover:scale-105 ${
              activeSection === "curriculum"
                ? "bg-gradient-to-r from-green-500 to-blue-500 text-white shadow-xl scale-105"
                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            }`}
          >
            <GraduationCap className="mx-auto mb-2" size={32} />
            Curriculum Manager
          </button>
        </div>

        {/* BADGES SECTION */}
        {activeSection === "badges" && (
          <div>
            <h2 className="text-3xl font-bold text-gray-800 mb-6">🏆 Manage Custom Badges</h2>
            
            <div className="grid grid-cols-2 gap-4 mb-6">
              {badges.map((badge) => (
                <div
                  key={badge.id}
                  className="bg-gradient-to-r from-yellow-50 to-orange-50 p-6 rounded-2xl shadow-md border-4 border-yellow-300"
                >
                  <div className="flex justify-between items-start">
                    <div className="flex items-center gap-4">
                      <span className="text-6xl">{badge.emoji}</span>
                      <div>
                        <h3 className="text-xl font-bold text-gray-800">{badge.name}</h3>
                        <p className="text-gray-600">{badge.description}</p>
                        <span className="inline-block bg-purple-500 text-white px-3 py-1 rounded-full text-sm font-bold mt-2">
                          {badge.category}
                        </span>
                        <p className="text-sm text-gray-500 mt-1">📋 {badge.requirement}</p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleDeleteBadge(badge.id)}
                      className="p-3 bg-red-500 text-white rounded-xl hover:bg-red-600"
                    >
                      <Trash2 size={20} />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Add New Badge */}
            <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-2xl border-4 border-blue-300">
              <h3 className="text-xl font-bold text-gray-800 mb-4">➕ Create New Badge</h3>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block font-bold text-gray-700 mb-2">Badge ID</label>
                    <input
                      type="text"
                      placeholder="e.g., super-learner"
                      value={newBadge.id}
                      onChange={(e) => setNewBadge({ ...newBadge, id: e.target.value })}
                      className="w-full p-4 border-4 border-purple-300 rounded-xl focus:border-purple-500 focus:outline-none text-lg"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-gray-700 mb-2">Badge Name</label>
                    <input
                      type="text"
                      placeholder="e.g., Super Learner"
                      value={newBadge.name}
                      onChange={(e) => setNewBadge({ ...newBadge, name: e.target.value })}
                      className="w-full p-4 border-4 border-purple-300 rounded-xl focus:border-purple-500 focus:outline-none text-lg"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-gray-700 mb-2">Description</label>
                  <textarea
                    placeholder="What this badge represents..."
                    value={newBadge.description}
                    onChange={(e) => setNewBadge({ ...newBadge, description: e.target.value })}
                    className="w-full p-4 border-4 border-purple-300 rounded-xl focus:border-purple-500 focus:outline-none text-lg"
                    rows={2}
                  />
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <label className="block font-bold text-gray-700 mb-2">Emoji</label>
                    <input
                      type="text"
                      placeholder="🏆"
                      value={newBadge.emoji}
                      onChange={(e) => setNewBadge({ ...newBadge, emoji: e.target.value })}
                      className="w-full p-4 border-4 border-purple-300 rounded-xl focus:border-purple-500 focus:outline-none text-4xl text-center"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-gray-700 mb-2">Category</label>
                    <select
                      value={newBadge.category}
                      onChange={(e) => setNewBadge({ ...newBadge, category: e.target.value as any })}
                      className="w-full p-4 border-4 border-purple-300 rounded-xl focus:border-purple-500 focus:outline-none text-lg"
                    >
                      <option value="achievement">Achievement</option>
                      <option value="milestone">Milestone</option>
                      <option value="special">Special</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-bold text-gray-700 mb-2">Points Required</label>
                    <input
                      type="number"
                      min="0"
                      placeholder="100 (optional)"
                      value={newBadge.pointsRequired || ''}
                      onChange={(e) => setNewBadge({ ...newBadge, pointsRequired: parseInt(e.target.value) || undefined })}
                      className="w-full p-4 border-4 border-green-300 rounded-xl focus:border-green-500 focus:outline-none text-lg"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-gray-700 mb-2">Requirement to Unlock</label>
                  <input
                    type="text"
                    placeholder="e.g., Complete 10 exercises"
                    value={newBadge.requirement}
                    onChange={(e) => setNewBadge({ ...newBadge, requirement: e.target.value })}
                    className="w-full p-4 border-4 border-yellow-300 rounded-xl focus:border-yellow-500 focus:outline-none text-lg"
                  />
                </div>

                <button
                  onClick={handleAddBadge}
                  className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 text-white px-8 py-4 rounded-xl font-bold text-lg shadow-lg hover:shadow-xl transform hover:scale-105"
                >
                  ➕ Create Badge
                </button>
              </div>
            </div>
          </div>
        )}

        {/* MATCHING EXERCISES SECTION */}
        {activeSection === "matching" && (
          <div>
            <h2 className="text-3xl font-bold text-gray-800 mb-6">🔗 Manage Matching Exercises</h2>
            <p className="text-gray-600 mb-6">Create exercises where students match items from two columns</p>
            
            <div className="space-y-4 mb-6">
              {matchingExercises.map((exercise) => (
                <div
                  key={exercise.id}
                  className="bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-2xl shadow-md border-4 border-blue-300"
                >
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <span className="bg-blue-500 text-white px-4 py-1 rounded-full font-bold text-sm mr-3">
                        {exercise.subject}
                      </span>
                      <span className="bg-green-500 text-white px-4 py-1 rounded-full font-bold text-sm">
                        Level {exercise.level}
                      </span>
                      <p className="text-xl font-bold text-gray-800 mt-3">{exercise.question}</p>
                      <div className="mt-4 grid grid-cols-2 gap-4">
                        <div className="bg-white p-4 rounded-xl">
                          <p className="font-bold text-purple-600 mb-2">Left Column:</p>
                          <ul className="list-disc list-inside space-y-1">
                            {exercise.leftColumn.map((item, i) => (
                              <li key={i} className="text-gray-700">{item}</li>
                            ))}
                          </ul>
                        </div>
                        <div className="bg-white p-4 rounded-xl">
                          <p className="font-bold text-purple-600 mb-2">Right Column:</p>
                          <ul className="list-disc list-inside space-y-1">
                            {exercise.rightColumn.map((item, i) => (
                              <li key={i} className="text-gray-700">{item}</li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={() => handleDeleteMatchingExercise(exercise.id)}
                      className="p-3 bg-red-500 text-white rounded-xl hover:bg-red-600 ml-4"
                    >
                      <Trash2 size={20} />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Add New Matching Exercise */}
            <div className="bg-gradient-to-r from-yellow-50 to-pink-50 p-6 rounded-2xl border-4 border-yellow-300">
              <h3 className="text-xl font-bold text-gray-800 mb-4">➕ Create Matching Exercise</h3>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block font-bold text-gray-700 mb-2">Subject</label>
                    <select
                      value={newMatching.subject}
                      onChange={(e) => setNewMatching({ ...newMatching, subject: e.target.value as any })}
                      className="w-full p-4 border-4 border-purple-300 rounded-xl focus:border-purple-500 focus:outline-none text-lg"
                    >
                      <option value="math">Math</option>
                      <option value="english">English</option>
                      <option value="ukrainian">Ukrainian</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-bold text-gray-700 mb-2">Level</label>
                    <input
                      type="number"
                      min="1"
                      value={newMatching.level}
                      onChange={(e) => setNewMatching({ ...newMatching, level: parseInt(e.target.value) })}
                      className="w-full p-4 border-4 border-purple-300 rounded-xl focus:border-purple-500 focus:outline-none text-lg"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-gray-700 mb-2">Question/Instructions</label>
                  <textarea
                    placeholder="e.g., Match the numbers with their words"
                    value={newMatching.question}
                    onChange={(e) => setNewMatching({ ...newMatching, question: e.target.value })}
                    className="w-full p-4 border-4 border-purple-300 rounded-xl focus:border-purple-500 focus:outline-none text-lg"
                    rows={2}
                  />
                </div>

                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <label className="block font-bold text-purple-700 mb-3 text-lg">📋 Left Column (4 items)</label>
                    {newMatching.leftColumn.map((item, i) => (
                      <input
                        key={i}
                        type="text"
                        placeholder={`Left item ${i + 1}`}
                        value={item}
                        onChange={(e) => {
                          const newLeft = [...newMatching.leftColumn];
                          newLeft[i] = e.target.value;
                          setNewMatching({ ...newMatching, leftColumn: newLeft });
                        }}
                        className="w-full p-3 border-4 border-blue-300 rounded-xl focus:border-blue-500 focus:outline-none mb-3 text-lg"
                      />
                    ))}
                  </div>
                  <div>
                    <label className="block font-bold text-purple-700 mb-3 text-lg">📋 Right Column (4 items)</label>
                    {newMatching.rightColumn.map((item, i) => (
                      <input
                        key={i}
                        type="text"
                        placeholder={`Right item ${i + 1}`}
                        value={item}
                        onChange={(e) => {
                          const newRight = [...newMatching.rightColumn];
                          newRight[i] = e.target.value;
                          setNewMatching({ ...newMatching, rightColumn: newRight });
                        }}
                        className="w-full p-3 border-4 border-green-300 rounded-xl focus:border-green-500 focus:outline-none mb-3 text-lg"
                      />
                    ))}
                  </div>
                </div>

                <div className="bg-yellow-100 p-4 rounded-xl border-4 border-yellow-400">
                  <label className="block font-bold text-gray-700 mb-2">🔗 Correct Matches</label>
                  <p className="text-sm text-gray-600 mb-3">For each left item (0-3), specify which right item (0-3) it matches</p>
                  <div className="grid grid-cols-4 gap-2">
                    {newMatching.correctMatches.map((match, i) => (
                      <div key={i}>
                        <label className="text-xs font-bold text-gray-600">Left {i} → Right</label>
                        <select
                          value={match}
                          onChange={(e) => {
                            const newMatches = [...newMatching.correctMatches];
                            newMatches[i] = parseInt(e.target.value);
                            setNewMatching({ ...newMatching, correctMatches: newMatches });
                          }}
                          className="w-full p-2 border-2 border-orange-300 rounded-lg text-center font-bold"
                        >
                          <option value={0}>0</option>
                          <option value={1}>1</option>
                          <option value={2}>2</option>
                          <option value={3}>3</option>
                        </select>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-gray-700 mb-2">Hint</label>
                  <input
                    type="text"
                    placeholder="Give students a hint..."
                    value={newMatching.hint}
                    onChange={(e) => setNewMatching({ ...newMatching, hint: e.target.value })}
                    className="w-full p-4 border-4 border-yellow-300 rounded-xl focus:border-yellow-500 focus:outline-none text-lg"
                  />
                </div>

                <div>
                  <label className="block font-bold text-gray-700 mb-2">Explanation</label>
                  <textarea
                    placeholder="Explain the correct answers..."
                    value={newMatching.explanation}
                    onChange={(e) => setNewMatching({ ...newMatching, explanation: e.target.value })}
                    className="w-full p-4 border-4 border-purple-300 rounded-xl focus:border-purple-500 focus:outline-none text-lg"
                    rows={2}
                  />
                </div>

                <button
                  onClick={handleAddMatchingExercise}
                  className="w-full bg-gradient-to-r from-blue-500 to-purple-500 text-white px-8 py-4 rounded-xl font-bold text-lg shadow-lg hover:shadow-xl transform hover:scale-105"
                >
                  ➕ Create Matching Exercise
                </button>
              </div>
            </div>
          </div>
        )}

        {/* CURRICULUM SECTION */}
        {activeSection === "curriculum" && !selectedSubject && (
          <div>
            <h2 className="text-3xl font-bold text-gray-800 mb-6">📚 Curriculum Manager</h2>
            <p className="text-gray-600 mb-6">Choose a subject to manage its curriculum</p>
            
            <div className="grid grid-cols-3 gap-6">
              <button
                onClick={() => setSelectedSubject('math')}
                className="bg-gradient-to-br from-blue-500 to-cyan-600 text-white p-8 rounded-3xl shadow-xl hover:shadow-2xl transition-all transform hover:scale-105 border-4 border-white"
              >
                <div className="text-6xl mb-3">🧮</div>
                <h3 className="text-2xl font-bold">Math</h3>
                <p className="text-sm opacity-90 mt-2">Manage math curriculum</p>
              </button>

              <button
                onClick={() => setSelectedSubject('english')}
                className="bg-gradient-to-br from-green-500 to-emerald-600 text-white p-8 rounded-3xl shadow-xl hover:shadow-2xl transition-all transform hover:scale-105 border-4 border-white"
              >
                <div className="text-6xl mb-3">📗</div>
                <h3 className="text-2xl font-bold">English</h3>
                <p className="text-sm opacity-90 mt-2">Manage English curriculum</p>
              </button>

              <button
                onClick={() => setSelectedSubject('ukrainian')}
                className="bg-gradient-to-br from-yellow-500 to-orange-600 text-white p-8 rounded-3xl shadow-xl hover:shadow-2xl transition-all transform hover:scale-105 border-4 border-white"
              >
                <div className="text-6xl mb-3">📙</div>
                <h3 className="text-2xl font-bold">Ukrainian</h3>
                <p className="text-sm opacity-90 mt-2">Manage Ukrainian curriculum</p>
              </button>
            </div>
          </div>
        )}

        {/* Show CurriculumManager when subject selected */}
        {activeSection === "curriculum" && selectedSubject && (
          <CurriculumManager
            subject={selectedSubject}
            onBack={() => setSelectedSubject(null)}
          />
        )}
      </div>
    </div>
  );
}