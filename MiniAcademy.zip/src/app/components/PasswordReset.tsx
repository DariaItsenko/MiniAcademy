import { useState } from 'react';
import { Mail, ArrowLeft, Lock, Key, Eye, EyeOff } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { LanguageSwitcher } from './LanguageSwitcher';
import { requestPasswordReset, resetPassword } from '/src/utils/api';

interface PasswordResetProps {
  onBack: () => void;
}

export function PasswordReset({ onBack }: PasswordResetProps) {
  const { t, language } = useLanguage();
  const [step, setStep] = useState<'email' | 'code' | 'reset'>('email');
  const [email, setEmail] = useState('');
  const [resetCode, setResetCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSendResetEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!email) {
      setError(language === 'uk' ? 'Будь ласка, введіть вашу електронну адресу' : 'Please enter your email address');
      return;
    }

    setIsLoading(true);

    try {
      const result = await requestPasswordReset(email);
      
      // Show code in message for demo purposes
      setSuccess(
        language === 'uk' 
          ? `✅ Код скидання відправлено! (Для демо: ${result.code})` 
          : `✅ Reset code sent! (Demo code: ${result.code})`
      );
      setStep('code');
    } catch (error: any) {
      console.error('Error requesting password reset:', error);
      setError(language === 'uk' ? 'Помилка при відправці коду. Спробуйте ще раз.' : 'Error sending code. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyCode = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!resetCode) {
      setError(language === 'uk' ? 'Будь ласка, введіть код скидання' : 'Please enter the reset code');
      return;
    }

    setSuccess(language === 'uk' ? 'Код підтверджено! Створіть новий пароль.' : 'Code verified! Please set your new password.');
    setStep('reset');
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!newPassword || !confirmPassword) {
      setError(language === 'uk' ? 'Будь ласка, заповніть всі поля' : 'Please fill in all fields');
      return;
    }

    if (newPassword !== confirmPassword) {
      setError(language === 'uk' ? 'Паролі не співпадають' : 'Passwords do not match');
      return;
    }

    if (newPassword.length < 6) {
      setError(language === 'uk' ? 'Пароль повинен містити щонайменше 6 символів' : 'Password must be at least 6 characters long');
      return;
    }

    setIsLoading(true);

    try {
      await resetPassword(email, resetCode, newPassword);
      
      setSuccess(
        language === 'uk' 
          ? 'Пароль успішно скинуто! Тепер ви можете увійти з новим паролем.' 
          : 'Password reset successfully! You can now login with your new password.'
      );
      
      // Redirect to login after 2 seconds
      setTimeout(() => {
        onBack();
      }, 2000);
    } catch (error: any) {
      console.error('Error resetting password:', error);
      setError(error.message || (language === 'uk' ? 'Помилка при скиданні пароля' : 'Error resetting password'));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-300 via-purple-300 to-pink-400 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute top-10 left-10 text-8xl animate-bounce">🔑</div>
      <div className="absolute top-20 right-20 text-7xl animate-pulse">🔐</div>
      <div className="absolute bottom-20 left-20 text-9xl">📧</div>
      <div className="absolute bottom-10 right-10 text-8xl animate-bounce" style={{ animationDelay: '0.5s' }}>🛡️</div>
      
      <div className="absolute top-4 right-4 z-20">
        <LanguageSwitcher />
      </div>
      
      <div className="bg-white rounded-3xl shadow-2xl p-8 w-full max-w-md relative z-10 border-8 border-blue-400">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-800 mb-6 font-semibold"
        >
          <ArrowLeft size={20} />
          {language === 'uk' ? 'Назад до входу' : 'Back to Login'}
        </button>

        <div className="text-center mb-8">
          <div className="bg-gradient-to-br from-blue-500 to-purple-500 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-4 shadow-xl">
            {step === 'email' && <Mail size={50} className="text-white" />}
            {step === 'code' && <Key size={50} className="text-white" />}
            {step === 'reset' && <Lock size={50} className="text-white" />}
          </div>
          <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600 mb-2">
            {language === 'uk' ? 'Скидання пароля' : 'Reset Password'}
          </h1>
          <p className="text-gray-600 text-lg">
            {step === 'email' && (language === 'uk' ? 'Введіть вашу електронну адресу для отримання коду' : 'Enter your email to receive a reset code')}
            {step === 'code' && (language === 'uk' ? 'Введіть 6-значний код, надісланий на вашу пошту' : 'Enter the 6-digit code sent to your email')}
            {step === 'reset' && (language === 'uk' ? 'Створіть новий пароль для вашого акаунту' : 'Create a new password for your account')}
          </p>
        </div>

        {/* Email Step */}
        {step === 'email' && (
          <form onSubmit={handleSendResetEmail} className="space-y-5">
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">
                {language === 'uk' ? 'Електронна адреса' : 'Email Address'}
              </label>
              <div className="relative">
                <Mail size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border-4 border-blue-300 rounded-2xl focus:border-blue-500 focus:outline-none text-lg"
                  placeholder={language === 'uk' ? 'ваша@пошта.com' : 'your@email.com'}
                />
              </div>
            </div>

            {error && (
              <div className="bg-red-100 border-4 border-red-400 text-red-700 px-4 py-3 rounded-2xl text-sm font-bold">
                ⚠️ {error}
              </div>
            )}

            {success && (
              <div className="bg-green-100 border-4 border-green-400 text-green-700 px-4 py-3 rounded-2xl text-sm font-bold">
                {success}
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white py-4 rounded-2xl font-bold text-lg transition-all flex items-center justify-center gap-2 shadow-lg transform hover:scale-105"
            >
              <Mail size={24} />
              {language === 'uk' ? 'Надіслати код скидання' : 'Send Reset Code'}
            </button>
          </form>
        )}

        {/* Code Verification Step */}
        {step === 'code' && (
          <form onSubmit={handleVerifyCode} className="space-y-5">
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">
                {language === 'uk' ? 'Код скидання' : 'Reset Code'}
              </label>
              <div className="relative">
                <Key size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="text"
                  value={resetCode}
                  onChange={(e) => setResetCode(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border-4 border-blue-300 rounded-2xl focus:border-blue-500 focus:outline-none text-lg text-center tracking-widest font-bold"
                  placeholder="000000"
                  maxLength={6}
                />
              </div>
              <p className="text-sm text-gray-500 mt-2">
                {language === 'uk' ? 'Перевірте вашу пошту для отримання 6-значного коду' : 'Check your email for the 6-digit code'}
              </p>
            </div>

            {error && (
              <div className="bg-red-100 border-4 border-red-400 text-red-700 px-4 py-3 rounded-2xl text-sm font-bold">
                ⚠️ {error}
              </div>
            )}

            {success && (
              <div className="bg-green-100 border-4 border-green-400 text-green-700 px-4 py-3 rounded-2xl text-sm font-bold">
                ✅ {success}
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white py-4 rounded-2xl font-bold text-lg transition-all flex items-center justify-center gap-2 shadow-lg transform hover:scale-105"
            >
              <Key size={24} />
              {language === 'uk' ? 'Підтвердити код' : 'Verify Code'}
            </button>

            <button
              type="button"
              onClick={() => {
                setStep('email');
                setError('');
                setSuccess('');
              }}
              className="w-full text-blue-600 hover:text-blue-700 font-semibold"
            >
              {language === 'uk' ? 'Не отримали код? Надіслати знову' : "Didn't receive the code? Send again"}
            </button>
          </form>
        )}

        {/* Reset Password Step */}
        {step === 'reset' && (
          <form onSubmit={handleResetPassword} className="space-y-5">
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">
                {language === 'uk' ? 'Новий пароль' : 'New Password'}
              </label>
              <div className="relative">
                <Lock size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type={showNewPassword ? 'text' : 'password'}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full pl-10 pr-12 py-3 border-4 border-blue-300 rounded-2xl focus:border-blue-500 focus:outline-none text-lg"
                  placeholder={language === 'uk' ? 'Введіть новий пароль' : 'Enter new password'}
                />
                <button
                  type="button"
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                  onClick={() => setShowNewPassword(!showNewPassword)}
                >
                  {showNewPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                </button>
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">
                {language === 'uk' ? 'Підтвердіть пароль' : 'Confirm Password'}
              </label>
              <div className="relative">
                <Lock size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type={showConfirmPassword ? 'text' : 'password'}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full pl-10 pr-12 py-3 border-4 border-blue-300 rounded-2xl focus:border-blue-500 focus:outline-none text-lg"
                  placeholder={language === 'uk' ? 'Підтвердіть новий пароль' : 'Confirm new password'}
                />
                <button
                  type="button"
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                >
                  {showConfirmPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                </button>
              </div>
            </div>

            {error && (
              <div className="bg-red-100 border-4 border-red-400 text-red-700 px-4 py-3 rounded-2xl text-sm font-bold">
                ⚠️ {error}
              </div>
            )}

            {success && (
              <div className="bg-green-100 border-4 border-green-400 text-green-700 px-4 py-3 rounded-2xl text-sm font-bold">
                ✅ {success}
              </div>
            )}

            <button
              type="submit"
              className="w-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white py-4 rounded-2xl font-bold text-lg transition-all flex items-center justify-center gap-2 shadow-lg transform hover:scale-105"
            >
              <Lock size={24} />
              {language === 'uk' ? 'Скинути пароль' : 'Reset Password'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}