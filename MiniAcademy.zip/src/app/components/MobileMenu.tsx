import { useState } from 'react';
import { Menu, X, User, BarChart3, LogOut } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { LanguageSwitcher } from './LanguageSwitcher';

interface MobileMenuProps {
  username: string;
  onAccountClick: () => void;
  onStatisticsClick: () => void;
  onLogout: () => void;
}

export function MobileMenu({ username, onAccountClick, onStatisticsClick, onLogout }: MobileMenuProps) {
  const [isOpen, setIsOpen] = useState(false);
  const { language } = useLanguage();

  const handleMenuClick = (action: () => void) => {
    action();
    setIsOpen(false);
  };

  return (
    <>
      {/* Hamburger Menu Button - Mobile Only */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="md:hidden flex items-center justify-center bg-white p-3 rounded-full shadow-lg border-2 border-purple-400 z-50"
        aria-label="Menu"
      >
        {isOpen ? <X size={24} className="text-purple-600" /> : <Menu size={24} className="text-purple-600" />}
      </button>

      {/* Mobile Menu Overlay */}
      {isOpen && (
        <div 
          className="md:hidden fixed inset-0 bg-black/50 z-40"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Mobile Menu Panel */}
      <div
        className={`md:hidden fixed top-0 right-0 h-full w-72 bg-gradient-to-br from-purple-100 to-pink-100 shadow-2xl transform transition-transform duration-300 ease-in-out z-40 ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="flex flex-col h-full p-6">
          {/* Header */}
          <div className="mb-8 mt-16">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-purple-200 rounded-full p-3">
                <User size={32} className="text-purple-600" />
              </div>
              <div>
                <p className="text-sm text-gray-600 font-medium">
                  {language === 'uk' ? 'Вітаємо' : 'Welcome'}
                </p>
                <p className="text-xl font-bold text-gray-800">{username}</p>
              </div>
            </div>
          </div>

          {/* Menu Items */}
          <nav className="flex-1 space-y-3">
            <button
              onClick={() => handleMenuClick(onAccountClick)}
              className="w-full flex items-center gap-3 bg-white px-5 py-4 rounded-2xl shadow-md hover:shadow-lg transition-all border-2 border-purple-300"
            >
              <User size={24} className="text-purple-600" />
              <span className="font-bold text-gray-800 text-lg">
                {language === 'uk' ? 'Обліковий запис' : 'Account'}
              </span>
            </button>

            <button
              onClick={() => handleMenuClick(onStatisticsClick)}
              className="w-full flex items-center gap-3 bg-white px-5 py-4 rounded-2xl shadow-md hover:shadow-lg transition-all border-2 border-indigo-300"
            >
              <BarChart3 size={24} className="text-indigo-600" />
              <span className="font-bold text-gray-800 text-lg">
                {language === 'uk' ? 'Статистика' : 'Statistics'}
              </span>
            </button>

            <div className="pt-2">
              <p className="text-xs text-gray-600 mb-2 px-2 font-medium">
                {language === 'uk' ? 'Мова / Language' : 'Language / Мова'}
              </p>
              <div className="bg-white px-5 py-4 rounded-2xl shadow-md border-2 border-blue-300">
                <LanguageSwitcher />
              </div>
            </div>
          </nav>

          {/* Logout Button at Bottom */}
          <div className="mt-auto pt-6 border-t-2 border-purple-300">
            <button
              onClick={() => handleMenuClick(onLogout)}
              className="w-full flex items-center justify-center gap-3 bg-gradient-to-r from-red-400 to-pink-500 text-white px-5 py-4 rounded-2xl shadow-md hover:shadow-lg transition-all font-bold"
            >
              <LogOut size={24} />
              <span className="text-lg">{language === 'uk' ? 'Вийти' : 'Logout'}</span>
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
