export { DragDropCategorize } from './DragDropCategorize';
export { SentenceOrdering } from './SentenceOrdering';
export { ClickCorrectObject } from './ClickCorrectObject';
export { ColumnMatching } from './ColumnMatching';
export { MiniSimulation } from './MiniSimulation';
