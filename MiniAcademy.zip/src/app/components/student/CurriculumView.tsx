import { useState } from 'react';
import { ArrowLeft, BookOpen, Play, CheckCircle, XCircle, HelpCircle, Eye, EyeOff } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';

interface Question {
  id: string;
  question: string;
  options?: string[];
  correctAnswer: string;
  type: 'multiple-choice' | 'text-input';
}

interface Lesson {
  id: string;
  title: string;
  videoUrl: string;
  lectureText: string;
  examples: string[];
  hint: string;
  test: {
    questions: Question[];
  };
}

interface Subtopic {
  id: string;
  name: string;
  emoji: string;
  lessons: Lesson[];
}

interface Topic {
  id: string;
  name: string;
  emoji: string;
  description: string;
  subtopics: Subtopic[];
}

interface Curriculum {
  topics: Topic[];
}

interface CurriculumViewProps {
  subject: 'math' | 'english' | 'ukrainian';
  onBack: () => void;
  onComplete?: (lessonId: string, score: number, totalQuestions: number) => void;
}

export function CurriculumView({ subject, onBack, onComplete }: CurriculumViewProps) {
  const { t, language } = useLanguage();
  
  // Load curriculum from localStorage
  const [curriculum] = useState<Curriculum>(() => {
    const stored = localStorage.getItem(`curriculum_${subject}`);
    return stored ? JSON.parse(stored) : { topics: [] };
  });

  const [selectedTopic, setSelectedTopic] = useState<Topic | null>(null);
  const [selectedSubtopic, setSelectedSubtopic] = useState<Subtopic | null>(null);
  const [selectedLesson, setSelectedLesson] = useState<Lesson | null>(null);
  const [isTestMode, setIsTestMode] = useState(false);

  // Test state
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<{ [key: number]: string }>({});
  const [showResults, setShowResults] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [textInputValue, setTextInputValue] = useState('');

  const subjectColors = {
    math: 'from-blue-500 to-cyan-600',
    english: 'from-green-500 to-emerald-600',
    ukrainian: 'from-yellow-500 to-orange-600'
  };

  const subjectNames = {
    math: language === 'uk' ? 'Математика' : 'Math',
    english: language === 'uk' ? 'Англійська' : 'English',
    ukrainian: language === 'uk' ? 'Українська' : 'Ukrainian'
  };

  const handleAnswerSelect = (answer: string) => {
    if (!selectedLesson || showResults) return;

    const newAnswers = { ...userAnswers, [currentQuestionIndex]: answer };
    setUserAnswers(newAnswers);
    setTextInputValue('');

    // Move to next question after short delay
    setTimeout(() => {
      if (currentQuestionIndex < selectedLesson.test.questions.length - 1) {
        setCurrentQuestionIndex(currentQuestionIndex + 1);
        setShowHint(false);
      } else {
        // Show results
        setShowResults(true);
      }
    }, 500);
  };

  const calculateScore = () => {
    if (!selectedLesson) return 0;
    
    let correct = 0;
    selectedLesson.test.questions.forEach((question, index) => {
      const userAnswer = userAnswers[index];
      if (userAnswer && userAnswer.toLowerCase().trim() === question.correctAnswer.toLowerCase().trim()) {
        correct++;
      }
    });
    
    return correct;
  };

  const restartTest = () => {
    setCurrentQuestionIndex(0);
    setUserAnswers({});
    setShowResults(false);
    setShowHint(false);
    setTextInputValue('');
  };

  const exitTest = () => {
    if (showResults && selectedLesson) {
      const score = calculateScore();
      onComplete?.(selectedLesson.id, score, selectedLesson.test.questions.length);
    }
    
    setIsTestMode(false);
    setCurrentQuestionIndex(0);
    setUserAnswers({});
    setShowResults(false);
    setShowHint(false);
    setTextInputValue('');
  };

  // Extract YouTube video ID
  const getYouTubeEmbedUrl = (url: string) => {
    if (!url) return '';
    
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    
    if (match && match[2].length === 11) {
      return `https://www.youtube.com/embed/${match[2]}`;
    }
    
    return url;
  };

  // Topic List View
  if (!selectedTopic) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-yellow-100 via-pink-100 to-blue-200 p-4 md:p-8">
        <div className="max-w-6xl mx-auto">
          <button
            onClick={onBack}
            className="flex items-center gap-2 bg-white text-gray-700 hover:text-gray-900 px-6 py-3 rounded-full shadow-lg hover:shadow-xl transition-all mb-8 font-bold border-4 border-purple-300"
          >
            <ArrowLeft size={24} />
            {language === 'uk' ? 'Назад' : 'Back'}
          </button>

          <div className={`bg-gradient-to-r ${subjectColors[subject]} text-white rounded-3xl p-8 mb-8 shadow-2xl border-8 border-white`}>
            <h1 className="text-4xl md:text-5xl font-bold mb-2">
              📚 {subjectNames[subject]}
            </h1>
            <p className="text-xl md:text-2xl opacity-90">
              {language === 'uk' ? 'Обери тему для вивчення!' : 'Choose a topic to learn!'}
            </p>
          </div>

          {curriculum.topics.length === 0 ? (
            <div className="bg-white rounded-3xl p-12 text-center shadow-xl border-4 border-yellow-300">
              <BookOpen size={64} className="mx-auto text-gray-400 mb-4" />
              <p className="text-gray-500 text-xl font-semibold">
                {language === 'uk' ? 'Теми ще не додані. Зверніться до вчителя!' : 'No topics yet. Contact your teacher!'}
              </p>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {curriculum.topics.map(topic => {
                const totalLessons = topic.subtopics.reduce((acc, st) => acc + st.lessons.length, 0);
                
                return (
                  <div
                    key={topic.id}
                    onClick={() => setSelectedTopic(topic)}
                    className="bg-white rounded-3xl p-6 shadow-lg hover:shadow-2xl transition-all transform hover:scale-105 cursor-pointer border-4 border-purple-300 hover:border-purple-500"
                  >
                    <div className="text-center mb-4">
                      <span className="text-7xl mb-4 block animate-bounce">{topic.emoji}</span>
                      <h3 className="text-2xl font-bold text-gray-800 mb-2">{topic.name}</h3>
                      <p className="text-gray-600 text-sm mb-4">{topic.description}</p>
                    </div>
                    
                    <div className="flex justify-center gap-3 text-sm">
                      <span className="bg-blue-100 text-blue-700 px-3 py-2 rounded-full font-bold">
                        {topic.subtopics.length} {language === 'uk' ? 'підтем' : 'subtopics'}
                      </span>
                      <span className="bg-green-100 text-green-700 px-3 py-2 rounded-full font-bold">
                        {totalLessons} {language === 'uk' ? 'уроків' : 'lessons'}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    );
  }

  // Subtopic List View
  if (selectedTopic && !selectedSubtopic) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-yellow-100 via-pink-100 to-blue-200 p-4 md:p-8">
        <div className="max-w-6xl mx-auto">
          <button
            onClick={() => setSelectedTopic(null)}
            className="flex items-center gap-2 bg-white text-gray-700 hover:text-gray-900 px-6 py-3 rounded-full shadow-lg hover:shadow-xl transition-all mb-8 font-bold border-4 border-purple-300"
          >
            <ArrowLeft size={24} />
            {language === 'uk' ? 'До тем' : 'Back to Topics'}
          </button>

          <div className={`bg-gradient-to-r ${subjectColors[subject]} text-white rounded-3xl p-8 mb-8 shadow-2xl border-8 border-white`}>
            <div className="flex items-center gap-4">
              <span className="text-7xl">{selectedTopic.emoji}</span>
              <div>
                <h1 className="text-4xl md:text-5xl font-bold mb-2">{selectedTopic.name}</h1>
                <p className="text-xl opacity-90">{selectedTopic.description}</p>
              </div>
            </div>
          </div>

          {selectedTopic.subtopics.length === 0 ? (
            <div className="bg-white rounded-3xl p-12 text-center shadow-xl border-4 border-yellow-300">
              <BookOpen size={64} className="mx-auto text-gray-400 mb-4" />
              <p className="text-gray-500 text-xl font-semibold">
                {language === 'uk' ? 'Підтеми ще не додані!' : 'No subtopics yet!'}
              </p>
            </div>
          ) : (
            <div className="grid md:grid-cols-2 gap-6">
              {selectedTopic.subtopics.map(subtopic => (
                <div
                  key={subtopic.id}
                  onClick={() => setSelectedSubtopic(subtopic)}
                  className="bg-white rounded-3xl p-6 shadow-lg hover:shadow-2xl transition-all transform hover:scale-105 cursor-pointer border-4 border-blue-300 hover:border-blue-500"
                >
                  <div className="flex items-center gap-4 mb-4">
                    <span className="text-6xl">{subtopic.emoji}</span>
                    <h3 className="text-2xl font-bold text-gray-800">{subtopic.name}</h3>
                  </div>
                  
                  <div className="flex justify-start gap-3">
                    <span className="bg-purple-100 text-purple-700 px-4 py-2 rounded-full font-bold">
                      {subtopic.lessons.length} {language === 'uk' ? 'уроків' : 'lessons'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }

  // Lesson List View
  if (selectedSubtopic && !selectedLesson) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-yellow-100 via-pink-100 to-blue-200 p-4 md:p-8">
        <div className="max-w-6xl mx-auto">
          <button
            onClick={() => setSelectedSubtopic(null)}
            className="flex items-center gap-2 bg-white text-gray-700 hover:text-gray-900 px-6 py-3 rounded-full shadow-lg hover:shadow-xl transition-all mb-8 font-bold border-4 border-purple-300"
          >
            <ArrowLeft size={24} />
            {language === 'uk' ? 'До підтем' : 'Back to Subtopics'}
          </button>

          <div className={`bg-gradient-to-r ${subjectColors[subject]} text-white rounded-3xl p-8 mb-8 shadow-2xl border-8 border-white`}>
            <div className="flex items-center gap-4">
              <span className="text-6xl">{selectedSubtopic.emoji}</span>
              <div>
                <p className="text-lg opacity-80">{selectedTopic.name}</p>
                <h1 className="text-4xl md:text-5xl font-bold">{selectedSubtopic.name}</h1>
              </div>
            </div>
          </div>

          {selectedSubtopic.lessons.length === 0 ? (
            <div className="bg-white rounded-3xl p-12 text-center shadow-xl border-4 border-yellow-300">
              <BookOpen size={64} className="mx-auto text-gray-400 mb-4" />
              <p className="text-gray-500 text-xl font-semibold">
                {language === 'uk' ? 'Уроки ще не додані!' : 'No lessons yet!'}
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              {selectedSubtopic.lessons.map((lesson, index) => (
                <div
                  key={lesson.id}
                  className="bg-white rounded-3xl p-6 shadow-lg hover:shadow-2xl transition-all border-4 border-green-300 hover:border-green-500"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-3">
                        <span className="bg-purple-500 text-white font-bold px-5 py-2 rounded-full text-lg">
                          {language === 'uk' ? 'Урок' : 'Lesson'} {index + 1}
                        </span>
                        <h3 className="text-2xl font-bold text-gray-800">{lesson.title}</h3>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-4">
                        {lesson.videoUrl && (
                          <div className="flex items-center gap-2 bg-red-100 text-red-700 px-3 py-2 rounded-lg">
                            <Play size={18} />
                            <span className="font-semibold text-sm">{language === 'uk' ? 'Відео' : 'Video'}</span>
                          </div>
                        )}
                        {lesson.lectureText && (
                          <div className="flex items-center gap-2 bg-blue-100 text-blue-700 px-3 py-2 rounded-lg">
                            <BookOpen size={18} />
                            <span className="font-semibold text-sm">{language === 'uk' ? 'Лекція' : 'Lecture'}</span>
                          </div>
                        )}
                        {lesson.test.questions.length > 0 && (
                          <div className="flex items-center gap-2 bg-green-100 text-green-700 px-3 py-2 rounded-lg">
                            <CheckCircle size={18} />
                            <span className="font-semibold text-sm">
                              {lesson.test.questions.length} {language === 'uk' ? 'питань' : 'questions'}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => setSelectedLesson(lesson)}
                    className="w-full bg-gradient-to-r from-green-500 to-blue-500 text-white font-bold py-4 px-6 rounded-2xl hover:from-green-600 hover:to-blue-600 transition-all shadow-lg hover:shadow-xl transform hover:scale-105 flex items-center justify-center gap-2 text-lg"
                  >
                    <Play size={24} />
                    {language === 'uk' ? 'Почати урок' : 'Start Lesson'}
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }

  // Lesson Content View
  if (selectedLesson && !isTestMode) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-yellow-100 via-pink-100 to-blue-200 p-4 md:p-8">
        <div className="max-w-5xl mx-auto">
          <button
            onClick={() => setSelectedLesson(null)}
            className="flex items-center gap-2 bg-white text-gray-700 hover:text-gray-900 px-6 py-3 rounded-full shadow-lg hover:shadow-xl transition-all mb-8 font-bold border-4 border-purple-300"
          >
            <ArrowLeft size={24} />
            {language === 'uk' ? 'До уроків' : 'Back to Lessons'}
          </button>

          <div className={`bg-gradient-to-r ${subjectColors[subject]} text-white rounded-3xl p-8 mb-8 shadow-2xl border-8 border-white`}>
            <h1 className="text-3xl md:text-4xl font-bold">{selectedLesson.title}</h1>
          </div>

          {/* Video Section */}
          {selectedLesson.videoUrl && (
            <div className="bg-white rounded-3xl p-6 shadow-xl mb-6 border-4 border-red-300">
              <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                <Play size={28} className="text-red-500" />
                {language === 'uk' ? 'Відео-лекція' : 'Video Lecture'}
              </h2>
              <div className="aspect-video rounded-2xl overflow-hidden shadow-lg">
                <iframe
                  src={getYouTubeEmbedUrl(selectedLesson.videoUrl)}
                  className="w-full h-full"
                  allowFullScreen
                  title="Video Lecture"
                />
              </div>
            </div>
          )}

          {/* Lecture Text Section */}
          {selectedLesson.lectureText && (
            <div className="bg-white rounded-3xl p-6 shadow-xl mb-6 border-4 border-blue-300">
              <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                <BookOpen size={28} className="text-blue-500" />
                {language === 'uk' ? 'Лекція' : 'Lecture'}
              </h2>
              <div className="text-gray-700 text-lg leading-relaxed whitespace-pre-wrap">
                {selectedLesson.lectureText}
              </div>
            </div>
          )}

          {/* Examples Section */}
          {selectedLesson.examples.filter(e => e.trim()).length > 0 && (
            <div className="bg-white rounded-3xl p-6 shadow-xl mb-6 border-4 border-green-300">
              <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                💡 {language === 'uk' ? 'Приклади' : 'Examples'}
              </h2>
              <div className="space-y-4">
                {selectedLesson.examples.filter(e => e.trim()).map((example, index) => (
                  <div key={index} className="bg-green-50 rounded-2xl p-4 border-2 border-green-200">
                    <div className="flex items-start gap-3">
                      <span className="bg-green-500 text-white font-bold px-3 py-1 rounded-full text-sm">
                        {index + 1}
                      </span>
                      <p className="text-gray-700 text-lg flex-1">{example}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Start Test Button */}
          {selectedLesson.test.questions.length > 0 && (
            <div className="bg-white rounded-3xl p-6 shadow-xl border-4 border-purple-300">
              <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                ✅ {language === 'uk' ? 'Тест' : 'Test'}
              </h2>
              <p className="text-gray-600 mb-6 text-lg">
                {language === 'uk' 
                  ? `Перевір свої знання! Тест містить ${selectedLesson.test.questions.length} питань.`
                  : `Test your knowledge! The test contains ${selectedLesson.test.questions.length} questions.`
                }
              </p>
              <button
                onClick={() => setIsTestMode(true)}
                className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white font-bold py-5 px-6 rounded-2xl hover:from-purple-600 hover:to-pink-600 transition-all shadow-lg hover:shadow-xl transform hover:scale-105 flex items-center justify-center gap-2 text-xl"
              >
                <CheckCircle size={28} />
                {language === 'uk' ? 'Почати тест' : 'Start Test'}
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  // Test Mode
  if (selectedLesson && isTestMode && !showResults) {
    const currentQuestion = selectedLesson.test.questions[currentQuestionIndex];
    const progress = ((currentQuestionIndex + 1) / selectedLesson.test.questions.length) * 100;

    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-100 via-pink-100 to-blue-100 p-2 md:p-8 relative">
        {/* Hint Button - Top Right Corner */}
        {selectedLesson.hint && (
          <div className="fixed top-2 right-2 md:top-4 md:right-4 z-50">
            <button
              onClick={() => setShowHint(!showHint)}
              className={`${
                showHint ? 'bg-yellow-500' : 'bg-yellow-400'
              } text-white p-2 md:p-4 rounded-full shadow-2xl hover:shadow-3xl transition-all transform hover:scale-110 border-2 md:border-4 border-white`}
            >
              {showHint ? <EyeOff size={20} className="md:w-7 md:h-7" /> : <HelpCircle size={20} className="md:w-7 md:h-7" />}
            </button>
            
            {showHint && (
              <div className="absolute top-14 md:top-16 right-0 bg-yellow-100 border-2 md:border-4 border-yellow-400 rounded-xl md:rounded-2xl p-3 md:p-6 shadow-2xl max-w-[200px] md:max-w-sm animate-bounce">
                <div className="flex items-start gap-2 md:gap-3">
                  <HelpCircle size={18} className="md:w-6 md:h-6 text-yellow-600 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="font-bold text-yellow-800 mb-1 md:mb-2 text-xs md:text-lg">
                      {language === 'uk' ? '💡 Підказка' : '💡 Hint'}
                    </h3>
                    <p className="text-yellow-900 text-xs md:text-base">{selectedLesson.hint}</p>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        <div className="max-w-4xl mx-auto">
          <button
            onClick={exitTest}
            className="flex items-center gap-1 md:gap-2 bg-white text-gray-700 hover:text-gray-900 px-3 md:px-6 py-2 md:py-3 rounded-full shadow-lg hover:shadow-xl transition-all mb-4 md:mb-8 font-bold border-2 md:border-4 border-red-300 text-sm md:text-base"
          >
            <ArrowLeft size={16} className="md:w-6 md:h-6" />
            {language === 'uk' ? 'Вийти' : 'Exit'}
          </button>

          {/* Progress Bar */}
          <div className="mb-4 md:mb-8">
            <div className="flex items-center justify-between mb-1 md:mb-2">
              <span className="text-xs md:text-lg font-bold text-gray-700">
                {language === 'uk' ? 'Прогрес' : 'Progress'}: {currentQuestionIndex + 1} / {selectedLesson.test.questions.length}
              </span>
              <span className="text-xs md:text-lg font-bold text-purple-600">{Math.round(progress)}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-4 md:h-6 shadow-inner border-2 md:border-4 border-white">
              <div
                className="bg-gradient-to-r from-purple-500 to-pink-500 h-full rounded-full transition-all duration-500 flex items-center justify-end pr-1 md:pr-2"
                style={{ width: `${progress}%` }}
              >
                {progress > 10 && <span className="text-white font-bold text-xs md:text-sm">🚀</span>}
              </div>
            </div>
          </div>

          {/* Question Card */}
          <div className="bg-white rounded-2xl md:rounded-3xl p-4 md:p-8 shadow-2xl border-2 md:border-4 border-purple-400">
            <div className="mb-3 md:mb-6">
              <span className="bg-purple-500 text-white font-bold px-3 md:px-5 py-1 md:py-2 rounded-full text-sm md:text-lg">
                {language === 'uk' ? 'Питання' : 'Question'} {currentQuestionIndex + 1}
              </span>
            </div>

            <h2 className="text-lg md:text-3xl font-bold text-gray-800 mb-4 md:mb-8 break-words">
              {currentQuestion.question}
            </h2>

            {/* Multiple Choice */}
            {currentQuestion.type === 'multiple-choice' && currentQuestion.options && (
              <div className="space-y-2 md:space-y-4">
                {currentQuestion.options.map((option, index) => {
                  const isSelected = userAnswers[currentQuestionIndex] === option;
                  
                  return (
                    <button
                      key={index}
                      onClick={() => handleAnswerSelect(option)}
                      className={`w-full text-left p-3 md:p-6 rounded-xl md:rounded-2xl font-semibold text-sm md:text-lg transition-all transform hover:scale-105 border-2 md:border-4 ${
                        isSelected
                          ? 'bg-purple-500 text-white border-purple-600 shadow-xl'
                          : 'bg-gray-100 text-gray-800 border-gray-300 hover:bg-gray-200 shadow-md hover:shadow-lg'
                      }`}
                    >
                      <div className="flex items-center gap-2 md:gap-4">
                        <span className={`w-7 h-7 md:w-10 md:h-10 rounded-full flex items-center justify-center font-bold text-sm md:text-lg flex-shrink-0 ${
                          isSelected ? 'bg-white text-purple-500' : 'bg-purple-200 text-purple-700'
                        }`}>
                          {String.fromCharCode(65 + index)}
                        </span>
                        <span className="flex-1 break-words">{option}</span>
                        {isSelected && <CheckCircle size={18} className="md:w-6 md:h-6 flex-shrink-0" />}
                      </div>
                    </button>
                  );
                })}
              </div>
            )}

            {/* Text Input */}
            {currentQuestion.type === 'text-input' && (
              <div>
                <input
                  type="text"
                  value={textInputValue}
                  onChange={(e) => setTextInputValue(e.target.value)}
                  onKeyPress={(e) => {
                    if (e.key === 'Enter' && textInputValue.trim()) {
                      handleAnswerSelect(textInputValue.trim());
                    }
                  }}
                  className="w-full px-3 md:px-6 py-2 md:py-4 border-2 md:border-4 border-purple-300 rounded-xl md:rounded-2xl focus:border-purple-500 focus:outline-none text-base md:text-xl mb-2 md:mb-4"
                  placeholder={language === 'uk' ? 'Введіть відповідь...' : 'Enter your answer...'}
                />
                <button
                  onClick={() => textInputValue.trim() && handleAnswerSelect(textInputValue.trim())}
                  disabled={!textInputValue.trim()}
                  className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white font-bold py-3 md:py-4 px-4 md:px-6 rounded-xl md:rounded-2xl hover:from-purple-600 hover:to-pink-600 transition-all shadow-lg hover:shadow-xl transform hover:scale-105 flex items-center justify-center gap-2 text-base md:text-xl disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <CheckCircle size={20} className="md:w-6 md:h-6" />
                  {language === 'uk' ? 'Відповісти' : 'Submit'}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Test Results
  if (selectedLesson && isTestMode && showResults) {
    const score = calculateScore();
    const totalQuestions = selectedLesson.test.questions.length;
    const percentage = Math.round((score / totalQuestions) * 100);

    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-100 via-pink-100 to-blue-100 p-2 md:p-8">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-2xl md:rounded-3xl p-4 md:p-12 shadow-2xl border-2 md:border-4 border-purple-400 text-center">
            <div className="text-5xl md:text-8xl mb-4 md:mb-6">
              {percentage >= 80 ? '🎉' : percentage >= 60 ? '👍' : '💪'}
            </div>
            
            <h2 className="text-2xl md:text-5xl font-bold text-gray-800 mb-3 md:mb-4">
              {language === 'uk' ? 'Тест завершено!' : 'Test Completed!'}
            </h2>
            
            <div className="mb-4 md:mb-8">
              <div className="text-4xl md:text-6xl font-bold text-purple-600 mb-1 md:mb-2">
                {score} / {totalQuestions}
              </div>
              <div className="text-lg md:text-2xl text-gray-600">
                {percentage}% {language === 'uk' ? 'правильних відповідей' : 'correct'}
              </div>
            </div>

            <div className="bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl md:rounded-2xl p-3 md:p-6 mb-4 md:mb-8">
              <h3 className="font-bold text-gray-800 mb-3 md:mb-4 text-base md:text-xl">
                {language === 'uk' ? 'Детальні результати' : 'Detailed Results'}
              </h3>
              <div className="space-y-2 md:space-y-3 max-h-[400px] overflow-y-auto">
                {selectedLesson.test.questions.map((question, index) => {
                  const userAnswer = userAnswers[index];
                  const isCorrect = userAnswer?.toLowerCase().trim() === question.correctAnswer.toLowerCase().trim();
                  
                  return (
                    <div
                      key={question.id}
                      className={`p-2 md:p-4 rounded-lg md:rounded-xl border-2 ${
                        isCorrect ? 'bg-green-50 border-green-300' : 'bg-red-50 border-red-300'
                      }`}
                    >
                      <div className="flex items-start gap-2 md:gap-3">
                        {isCorrect ? (
                          <CheckCircle size={18} className="md:w-6 md:h-6 text-green-600 flex-shrink-0 mt-1" />
                        ) : (
                          <XCircle size={18} className="md:w-6 md:h-6 text-red-600 flex-shrink-0 mt-1" />
                        )}
                        <div className="flex-1 text-left">
                          <p className="font-semibold text-gray-800 mb-1 text-xs md:text-base break-words">
                            Q{index + 1}: {question.question}
                          </p>
                          {!isCorrect && (
                            <div className="text-xs md:text-sm">
                              <p className="text-red-700 break-words">
                                {language === 'uk' ? 'Ваша відповідь' : 'Your answer'}: {userAnswer || (language === 'uk' ? 'Немає' : 'None')}
                              </p>
                              <p className="text-green-700 font-semibold break-words">
                                {language === 'uk' ? 'Правильна' : 'Correct'}: {question.correctAnswer}
                              </p>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="flex flex-col md:flex-row gap-2 md:gap-4">
              <button
                onClick={restartTest}
                className="flex-1 bg-gradient-to-r from-blue-500 to-cyan-500 text-white font-bold py-3 md:py-4 px-4 md:px-6 rounded-xl md:rounded-2xl hover:from-blue-600 hover:to-cyan-600 transition-all shadow-lg hover:shadow-xl transform hover:scale-105 flex items-center justify-center gap-2 text-base md:text-lg"
              >
                🔄 {language === 'uk' ? 'Пройти знову' : 'Retry Test'}
              </button>
              <button
                onClick={exitTest}
                className="flex-1 bg-gradient-to-r from-green-500 to-emerald-500 text-white font-bold py-3 md:py-4 px-4 md:px-6 rounded-xl md:rounded-2xl hover:from-green-600 hover:to-emerald-600 transition-all shadow-lg hover:shadow-xl transform hover:scale-105 flex items-center justify-center gap-2 text-base md:text-lg"
              >
                ✅ {language === 'uk' ? 'Завершити' : 'Finish'}
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return null;
}