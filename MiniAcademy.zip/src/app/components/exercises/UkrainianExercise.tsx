import { useState, useEffect } from 'react';
import { CheckCircle, XCircle } from 'lucide-react';

interface Question {
  question: string;
  answer: string;
  options: string[];
}

interface UkrainianExerciseProps {
  level: number;
  onComplete: (stars: number) => void;
}

const generateQuestions = (level: number): Question[] => {
  const questions: Question[] = [];
  
  const level1Questions = [
    { question: 'Яка перша буква в слові "Мама"?', answer: 'М', options: ['М', 'А', 'Б', 'В'] },
    { question: 'Скільки букв в українській абетці?', answer: '33', options: ['33', '32', '30', '26'] },
    { question: 'Яка буква йде після "А"?', answer: 'Б', options: ['Б', 'В', 'Г', 'Д'] },
    { question: 'Виберіть голосну букву:', answer: 'О', options: ['О', 'Б', 'В', 'Г'] },
    { question: 'Що це? 🐱', answer: 'кіт', options: ['кіт', 'собака', 'птах', 'риба'] },
    { question: 'Яка буква "І" або "Ї"? Слово: кр___м', answer: 'і', options: ['і', 'ї', 'и', 'й'] },
    { question: 'Виберіть правильне слово для 🌸:', answer: 'квітка', options: ['квітка', 'дерево', 'трава', 'листок'] },
    { question: 'Яка буква в слові "хл___б"?', answer: 'і', options: ['і', 'и', 'е', 'є'] },
    { question: 'Що означає слово "дім"?', answer: 'будинок', options: ['будинок', 'школа', 'парк', 'вулиця'] },
    { question: 'Яке слово правильне?', answer: 'сонце', options: ['сонце', 'сонця', 'сонци', 'сонець'] }
  ];

  const level2Questions = [
    { question: 'Виберіть правильне слово: Я ___ до школи', answer: 'йду', options: ['йду', 'іду', 'ходжу', 'хожу'] },
    { question: 'Що правильно: Мама ___ обід', answer: 'готує', options: ['готує', 'готуе', 'готуї', 'готуи'] },
    { question: 'Яке слово означає "book" англійською?', answer: 'книга', options: ['книга', 'зошит', 'олівець', 'ручка'] },
    { question: 'Виберіть іменник:', answer: 'стіл', options: ['стіл', 'бігти', 'гарний', 'швидко'] },
    { question: 'Скільки складів у слові "ма-ли-на"?', answer: '3', options: ['3', '2', '4', '5'] },
    { question: 'Яке слово правильне?', answer: 'дівчинка', options: ['дівчинка', 'дівчінка', 'девчинка', 'дівчинька'] },
    { question: 'Що є протилежним до слова "великий"?', answer: 'малий', options: ['малий', 'добрий', 'гарний', 'високий'] },
    { question: '___ сонце світить яскраво.', answer: 'Сьогодні', options: ['Сьогодні', 'Вчора', 'Завтра', 'Позавчора'] },
    { question: 'Виберіть дієслово:', answer: 'читати', options: ['читати', 'книжка', 'великий', 'школа'] },
    { question: 'Яке слово пишеться через "Ї"?', answer: 'їжак', options: ['їжак', 'ижак', 'іжак', 'йижак'] }
  ];

  const level3Questions = [
    { question: 'Складіть речення: я / школу / до / йду', answer: 'Я йду до школи.', options: ['Я йду до школи.', 'До школи я йду.', 'Йду я до школи.', 'Школи до я йду.'] },
    { question: 'Виберіть правильний наголос: мо-ло-ко', answer: 'молоко́', options: ['молоко́', 'мо́локо', 'моло́ко', 'молоко'] },
    { question: 'Яке речення правильне?', answer: 'Діти граються в парку.', options: ['Діти граються в парку.', 'Діти грається в парку.', 'Дітей граються в парку.', 'Діти граетесь в парку.'] },
    { question: 'Вставте пропущене слово: Кіт ___ на дереві.', answer: 'сидить', options: ['сидить', 'сидять', 'сиджу', 'сидиш'] },
    { question: 'Який розділовий знак потрібен? Як справи___', answer: '?', options: ['?', '.', '!', ','] },
    { question: 'Виберіть прикметник:', answer: 'гарний', options: ['гарний', 'бігти', 'школа', 'вчитель'] },
    { question: 'Множина слова "дерево":', answer: 'дерева', options: ['дерева', 'дереви', 'деревів', 'деревей'] },
    { question: 'Яке речення має правильну структуру?', answer: 'Мама готує вечерю.', options: ['Мама готує вечерю.', 'Готує мама вечерю.', 'Вечерю готує мама.', 'Готує вечерю мама.'] },
    { question: 'Вставте правильне слово: Ми ___ в парк.', answer: 'йдемо', options: ['йдемо', 'йду', 'йдеш', 'йде'] },
    { question: 'Який час дієслова в реченні: "Я читав книгу"?', answer: 'минулий', options: ['минулий', 'теперішній', 'майбутній', 'наказовий'] }
  ];

  const level4Questions = [
    { question: 'Виберіть правильне написання:', answer: 'Київ - столиця України.', options: ['Київ - столиця України.', 'київ - столиця україни.', 'Київ - Столиця України.', 'Киів - столиця України.'] },
    { question: 'Яке речення складне?', answer: 'Я люблю читати, а сестра любить малювати.', options: ['Я люблю читати, а сестра любить малювати.', 'Я люблю читати.', 'Сестра любить малювати.', 'Читати і малювати.'] },
    { question: 'Виберіть синонім до слова "швидкий":', answer: 'прудкий', options: ['прудкий', 'повільний', 'великий', 'малий'] },
    { question: 'Яке слово написане правильно?', answer: 'Україна', options: ['Україна', 'Украіна', 'Укранна', 'Вкраїна'] },
    { question: 'Визначте відмінок: "Я бачу (кого?) брата"', answer: 'знахідний', options: ['знахідний', 'називний', 'родовий', 'давальний'] },
    { question: 'Яке дієслово в майбутньому часі?', answer: 'буду читати', options: ['буду читати', 'читаю', 'читав', 'читав би'] },
    { question: 'Вставте правильний прийменник: Я йду ___ школи', answer: 'зі', options: ['зі', 'з', 'із', 'зо'] },
    { question: 'Яке речення має пряму мову?', answer: 'Мама сказала: "Прибери кімнату."', options: ['Мама сказала: "Прибери кімнату."', 'Мама сказала прибрати кімнату.', 'Мама прибирає кімнату.', 'Кімната прибрана.'] },
    { question: 'Антонім до слова "радість":', answer: 'смуток', options: ['смуток', 'щастя', 'любов', 'надія'] },
    { question: 'Яке слово є іменником середнього роду?', answer: 'сонце', options: ['сонце', 'мама', 'тато', 'дівчинка'] }
  ];

  switch (level) {
    case 1:
      questions.push(...level1Questions);
      break;
    case 2:
      questions.push(...level2Questions);
      break;
    case 3:
      questions.push(...level3Questions);
      break;
    default:
      questions.push(...level4Questions);
  }
  
  return questions;
};

export function UkrainianExercise({ level, onComplete }: UkrainianExerciseProps) {
  const [questions] = useState<Question[]>(generateQuestions(level));
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);

  const handleAnswer = (answer: string) => {
    setSelectedAnswer(answer);
    const correct = answer === questions[currentQuestion].answer;
    setIsCorrect(correct);
    
    if (correct) {
      setScore(score + 1);
    }

    setTimeout(() => {
      if (currentQuestion < questions.length - 1) {
        setCurrentQuestion(currentQuestion + 1);
        setSelectedAnswer(null);
        setIsCorrect(null);
      } else {
        setShowResult(true);
      }
    }, 1000);
  };

  useEffect(() => {
    if (showResult) {
      const stars = score >= 9 ? 3 : score >= 7 ? 2 : score >= 5 ? 1 : 0;
      setTimeout(() => onComplete(stars), 2000);
    }
  }, [showResult, score, onComplete]);

  if (showResult) {
    const stars = score >= 9 ? 3 : score >= 7 ? 2 : score >= 5 ? 1 : 0;
    
    return (
      <div className="text-center py-12">
        <div className="mb-8">
          <div className="text-6xl mb-4">
            {stars === 3 ? '🌟🌟🌟' : stars === 2 ? '🌟🌟' : stars === 1 ? '🌟' : '📚'}
          </div>
          <h2 className="text-3xl font-bold text-gray-800 mb-2">
            {stars === 3 ? 'Відмінно!' : stars === 2 ? 'Чудова робота!' : stars === 1 ? 'Добре!' : 'Продовжуй практикувати!'}
          </h2>
          <p className="text-xl text-gray-600">
            Ваш результат: {score} з {questions.length}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto">
      <div className="mb-6">
        <div className="flex justify-between text-sm text-gray-600 mb-2">
          <span>Питання {currentQuestion + 1} з {questions.length}</span>
          <span>Рахунок: {score}/{questions.length}</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div
            className="bg-gradient-to-r from-yellow-500 to-orange-500 h-2 rounded-full transition-all"
            style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
          />
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-lg p-8 mb-6">
        <h3 className="text-2xl font-bold text-gray-800 mb-8 text-center">
          {questions[currentQuestion].question}
        </h3>

        <div className="grid grid-cols-1 gap-4">
          {questions[currentQuestion].options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleAnswer(option)}
              disabled={selectedAnswer !== null}
              className={`p-4 rounded-lg font-semibold text-lg transition-all ${
                selectedAnswer === option
                  ? isCorrect
                    ? 'bg-green-500 text-white'
                    : 'bg-red-500 text-white'
                  : 'bg-gray-100 hover:bg-gray-200 text-gray-800'
              } ${selectedAnswer !== null ? 'cursor-not-allowed' : 'hover:shadow-md'}`}
            >
              <div className="flex items-center justify-between">
                <span>{option}</span>
                {selectedAnswer === option && (
                  isCorrect ? <CheckCircle size={24} /> : <XCircle size={24} />
                )}
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
