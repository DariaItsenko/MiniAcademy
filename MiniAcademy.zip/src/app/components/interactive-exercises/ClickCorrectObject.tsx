import { useState } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { Trophy, CheckCircle, XCircle } from 'lucide-react';

interface ObjectItem {
  id: string;
  emoji: string;
  label: string;
  isCorrect: boolean;
  position: { x: string; y: string };
}

interface Question {
  prompt: string;
  objects: ObjectItem[];
}

interface ClickCorrectObjectProps {
  onComplete: (score: number) => void;
  subject: 'math' | 'english' | 'ukrainian';
}

export function ClickCorrectObject({ onComplete, subject }: ClickCorrectObjectProps) {
  const { language } = useLanguage();

  const exerciseData = {
    math: [
      {
        prompt: language === 'uk' ? 'Який об\'єкт показує трикутник?' : 'Which object shows a triangle?',
        objects: [
          { id: '1', emoji: '🔺', label: language === 'uk' ? 'Трикутник' : 'Triangle', isCorrect: true, position: { x: '20%', y: '30%' } },
          { id: '2', emoji: '🟦', label: language === 'uk' ? 'Квадрат' : 'Square', isCorrect: false, position: { x: '50%', y: '50%' } },
          { id: '3', emoji: '🔵', label: language === 'uk' ? 'Коло' : 'Circle', isCorrect: false, position: { x: '70%', y: '20%' } },
          { id: '4', emoji: '⭐', label: language === 'uk' ? 'Зірка' : 'Star', isCorrect: false, position: { x: '35%', y: '65%' } },
        ],
      },
      {
        prompt: language === 'uk' ? 'Знайдіть найбільше число!' : 'Find the biggest number!',
        objects: [
          { id: '1', emoji: '5️⃣', label: '5', isCorrect: false, position: { x: '25%', y: '40%' } },
          { id: '2', emoji: '🔟', label: '10', isCorrect: true, position: { x: '60%', y: '30%' } },
          { id: '3', emoji: '3️⃣', label: '3', isCorrect: false, position: { x: '45%', y: '60%' } },
          { id: '4', emoji: '7️⃣', label: '7', isCorrect: false, position: { x: '70%', y: '55%' } },
        ],
      },
      {
        prompt: language === 'uk' ? 'Де знаходиться парне число?' : 'Where is the even number?',
        objects: [
          { id: '1', emoji: '3️⃣', label: '3', isCorrect: false, position: { x: '30%', y: '25%' } },
          { id: '2', emoji: '5️⃣', label: '5', isCorrect: false, position: { x: '55%', y: '45%' } },
          { id: '3', emoji: '8️⃣', label: '8', isCorrect: true, position: { x: '70%', y: '30%' } },
          { id: '4', emoji: '9️⃣', label: '9', isCorrect: false, position: { x: '40%', y: '65%' } },
        ],
      },
    ],
    english: [
      {
        prompt: language === 'uk' ? 'Знайдіть фрукт!' : 'Find the fruit!',
        objects: [
          { id: '1', emoji: '🍎', label: 'Apple', isCorrect: true, position: { x: '25%', y: '35%' } },
          { id: '2', emoji: '🚗', label: 'Car', isCorrect: false, position: { x: '60%', y: '25%' } },
          { id: '3', emoji: '📚', label: 'Book', isCorrect: false, position: { x: '45%', y: '60%' } },
          { id: '4', emoji: '⚽', label: 'Ball', isCorrect: false, position: { x: '70%', y: '50%' } },
        ],
      },
      {
        prompt: language === 'uk' ? 'Де тварина?' : 'Where is the animal?',
        objects: [
          { id: '1', emoji: '🌺', label: 'Flower', isCorrect: false, position: { x: '30%', y: '30%' } },
          { id: '2', emoji: '🐶', label: 'Dog', isCorrect: true, position: { x: '55%', y: '45%' } },
          { id: '3', emoji: '🏠', label: 'House', isCorrect: false, position: { x: '65%', y: '25%' } },
          { id: '4', emoji: '🎨', label: 'Art', isCorrect: false, position: { x: '35%', y: '65%' } },
        ],
      },
      {
        prompt: language === 'uk' ? 'Клацніть на транспортний засіб!' : 'Click on the vehicle!',
        objects: [
          { id: '1', emoji: '🌳', label: 'Tree', isCorrect: false, position: { x: '20%', y: '40%' } },
          { id: '2', emoji: '🍕', label: 'Pizza', isCorrect: false, position: { x: '50%', y: '30%' } },
          { id: '3', emoji: '🚲', label: 'Bicycle', isCorrect: true, position: { x: '65%', y: '55%' } },
          { id: '4', emoji: '🎈', label: 'Balloon', isCorrect: false, position: { x: '40%', y: '60%' } },
        ],
      },
    ],
    ukrainian: [
      {
        prompt: language === 'uk' ? 'Знайдіть українську символіку!' : 'Find Ukrainian symbols!',
        objects: [
          { id: '1', emoji: '🇺🇦', label: language === 'uk' ? 'Прапор України' : 'Ukraine Flag', isCorrect: true, position: { x: '30%', y: '35%' } },
          { id: '2', emoji: '🍎', label: language === 'uk' ? 'Яблуко' : 'Apple', isCorrect: false, position: { x: '60%', y: '30%' } },
          { id: '3', emoji: '🏠', label: language === 'uk' ? 'Будинок' : 'House', isCorrect: false, position: { x: '45%', y: '60%' } },
          { id: '4', emoji: '⚽', label: language === 'uk' ? 'М\'яч' : 'Ball', isCorrect: false, position: { x: '70%', y: '50%' } },
        ],
      },
      {
        prompt: language === 'uk' ? 'Де квітка?' : 'Where is the flower?',
        objects: [
          { id: '1', emoji: '🌺', label: language === 'uk' ? 'Квітка' : 'Flower', isCorrect: true, position: { x: '25%', y: '40%' } },
          { id: '2', emoji: '🚗', label: language === 'uk' ? 'Машина' : 'Car', isCorrect: false, position: { x: '55%', y: '35%' } },
          { id: '3', emoji: '📚', label: language === 'uk' ? 'Книжка' : 'Book', isCorrect: false, position: { x: '65%', y: '55%' } },
          { id: '4', emoji: '🎨', label: language === 'uk' ? 'Мистецтво' : 'Art', isCorrect: false, position: { x: '40%', y: '65%' } },
        ],
      },
      {
        prompt: language === 'uk' ? 'Знайдіть їжу!' : 'Find the food!',
        objects: [
          { id: '1', emoji: '🌳', label: language === 'uk' ? 'Дерево' : 'Tree', isCorrect: false, position: { x: '30%', y: '30%' } },
          { id: '2', emoji: '🍞', label: language === 'uk' ? 'Хліб' : 'Bread', isCorrect: true, position: { x: '60%', y: '45%' } },
          { id: '3', emoji: '🎈', label: language === 'uk' ? 'Кулька' : 'Balloon', isCorrect: false, position: { x: '50%', y: '25%' } },
          { id: '4', emoji: '⭐', label: language === 'uk' ? 'Зірка' : 'Star', isCorrect: false, position: { x: '35%', y: '60%' } },
        ],
      },
    ],
  };

  const questions = exerciseData[subject];
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<'correct' | 'incorrect' | null>(null);
  const [isComplete, setIsComplete] = useState(false);
  const [clickedObjects, setClickedObjects] = useState<Set<string>>(new Set());

  const handleObjectClick = (obj: ObjectItem) => {
    if (selectedId) return; // Prevent multiple clicks

    setSelectedId(obj.id);
    setClickedObjects(new Set([...clickedObjects, obj.id]));

    if (obj.isCorrect) {
      setFeedback('correct');
      setScore(score + 1);
      
      setTimeout(() => {
        if (currentQuestion < questions.length - 1) {
          setCurrentQuestion(currentQuestion + 1);
          setSelectedId(null);
          setFeedback(null);
          setClickedObjects(new Set());
        } else {
          setIsComplete(true);
          setTimeout(() => {
            onComplete(score + 1);
          }, 2500);
        }
      }, 1500);
    } else {
      setFeedback('incorrect');
      setTimeout(() => {
        setSelectedId(null);
        setFeedback(null);
      }, 1000);
    }
  };

  if (isComplete) {
    const percentage = Math.round((score / questions.length) * 100);
    return (
      <div className="text-center py-12 px-4">
        <div className="mb-8">
          <Trophy size={80} className="text-yellow-500 mx-auto mb-4" />
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">
            {percentage === 100
              ? language === 'uk' ? '🎉 Ідеально!' : '🎉 Perfect!'
              : percentage >= 66
              ? language === 'uk' ? '👍 Відмінно!' : '👍 Excellent!'
              : language === 'uk' ? '💪 Гарна спроба!' : '💪 Good Try!'}
          </h2>
          <p className="text-2xl text-gray-600">
            {language === 'uk' ? 'Правильних відповідей' : 'Correct Answers'}: {score}/{questions.length}
          </p>
          <p className="text-xl text-gray-500 mt-2">
            {percentage}%
          </p>
        </div>
      </div>
    );
  }

  const currentQ = questions[currentQuestion];

  return (
    <div className="max-w-5xl mx-auto p-4 md:p-8">
      <div className="mb-8">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl md:text-4xl font-bold text-gray-800">
            {language === 'uk' ? '🎯 Знайди правильний об\'єкт' : '🎯 Find the Correct Object'}
          </h2>
          <div className="text-lg font-bold text-gray-600">
            {currentQuestion + 1}/{questions.length}
          </div>
        </div>

        <div className="bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-2xl p-6 mb-6 shadow-xl">
          <p className="text-xl md:text-3xl font-bold text-center">
            {currentQ.prompt}
          </p>
        </div>

        <div className="flex justify-center gap-2 mb-4">
          <div className="inline-flex items-center gap-2 bg-green-100 px-4 py-2 rounded-full border-2 border-green-400">
            <CheckCircle className="text-green-600" size={20} />
            <span className="font-bold text-gray-800">{score}</span>
          </div>
        </div>
      </div>

      <div className="relative bg-gradient-to-br from-blue-100 via-purple-100 to-pink-100 rounded-3xl p-8 md:p-16 border-4 border-white shadow-2xl" style={{ minHeight: '500px' }}>
        {currentQ.objects.map((obj) => (
          <button
            key={obj.id}
            onClick={() => handleObjectClick(obj)}
            disabled={selectedId !== null}
            className={`absolute transform -translate-x-1/2 -translate-y-1/2 transition-all duration-300 ${
              selectedId === obj.id
                ? feedback === 'correct'
                  ? 'scale-125 animate-bounce'
                  : 'animate-shake'
                : clickedObjects.has(obj.id)
                ? 'opacity-50'
                : 'hover:scale-110'
            }`}
            style={{ left: obj.position.x, top: obj.position.y }}
          >
            <div
              className={`bg-white rounded-3xl p-6 md:p-8 shadow-xl border-4 ${
                selectedId === obj.id
                  ? feedback === 'correct'
                    ? 'border-green-500 bg-green-50'
                    : 'border-red-500 bg-red-50'
                  : 'border-purple-300 hover:border-purple-500'
              }`}
            >
              <div className="text-5xl md:text-7xl mb-2">{obj.emoji}</div>
              <div className="text-sm md:text-base font-bold text-gray-800">{obj.label}</div>
              {selectedId === obj.id && feedback === 'correct' && (
                <CheckCircle className="text-green-600 mx-auto mt-2" size={32} />
              )}
              {selectedId === obj.id && feedback === 'incorrect' && (
                <XCircle className="text-red-600 mx-auto mt-2" size={32} />
              )}
            </div>
          </button>
        ))}
      </div>

      {feedback && (
        <div className={`mt-6 text-center text-2xl font-bold ${
          feedback === 'correct' ? 'text-green-600' : 'text-red-600'
        }`}>
          {feedback === 'correct'
            ? language === 'uk' ? '✅ Правильно!' : '✅ Correct!'
            : language === 'uk' ? '❌ Спробуй ще раз!' : '❌ Try again!'}
        </div>
      )}
    </div>
  );
}
