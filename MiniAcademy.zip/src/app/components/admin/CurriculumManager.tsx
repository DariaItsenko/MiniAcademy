import { useState } from 'react';
import { ArrowLeft, Plus, Edit2, Trash2, BookOpen, Video, FileText, HelpCircle, Save, X } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';

interface Question {
  id: string;
  question: string;
  options?: string[];
  correctAnswer: string;
  type: 'multiple-choice' | 'text-input';
}

interface Lesson {
  id: string;
  title: string;
  videoUrl: string;
  lectureText: string;
  examples: string[];
  hint: string;
  test: {
    questions: Question[];
  };
}

interface Subtopic {
  id: string;
  name: string;
  emoji: string;
  lessons: Lesson[];
}

interface Topic {
  id: string;
  name: string;
  emoji: string;
  description: string;
  subtopics: Subtopic[];
}

interface Curriculum {
  topics: Topic[];
}

interface CurriculumManagerProps {
  subject: 'math' | 'english' | 'ukrainian';
  onBack: () => void;
}

export function CurriculumManager({ subject, onBack }: CurriculumManagerProps) {
  const { t, language } = useLanguage();
  
  // Load curriculum from localStorage
  const [curriculum, setCurriculum] = useState<Curriculum>(() => {
    const stored = localStorage.getItem(`curriculum_${subject}`);
    return stored ? JSON.parse(stored) : { topics: [] };
  });

  const [editingLevel, setEditingLevel] = useState<'topic' | 'subtopic' | 'lesson' | null>(null);
  const [selectedTopic, setSelectedTopic] = useState<Topic | null>(null);
  const [selectedSubtopic, setSelectedSubtopic] = useState<Subtopic | null>(null);
  const [selectedLesson, setSelectedLesson] = useState<Lesson | null>(null);

  // Save to localStorage
  const saveCurriculum = (newCurriculum: Curriculum) => {
    localStorage.setItem(`curriculum_${subject}`, JSON.stringify(newCurriculum));
    setCurriculum(newCurriculum);
  };

  // Topic Management
  const [newTopicName, setNewTopicName] = useState('');
  const [newTopicEmoji, setNewTopicEmoji] = useState('📚');
  const [newTopicDescription, setNewTopicDescription] = useState('');

  const addTopic = () => {
    if (!newTopicName.trim()) {
      alert(language === 'uk' ? 'Введіть назву теми!' : 'Enter topic name!');
      return;
    }

    const newTopic: Topic = {
      id: Date.now().toString(),
      name: newTopicName,
      emoji: newTopicEmoji,
      description: newTopicDescription,
      subtopics: []
    };

    saveCurriculum({
      topics: [...curriculum.topics, newTopic]
    });

    setNewTopicName('');
    setNewTopicEmoji('📚');
    setNewTopicDescription('');
    alert(language === 'uk' ? '✅ Тема додана!' : '✅ Topic added!');
  };

  const deleteTopic = (topicId: string) => {
    if (confirm(language === 'uk' ? 'Видалити тему?' : 'Delete topic?')) {
      saveCurriculum({
        topics: curriculum.topics.filter(t => t.id !== topicId)
      });
    }
  };

  // Subtopic Management
  const [newSubtopicName, setNewSubtopicName] = useState('');
  const [newSubtopicEmoji, setNewSubtopicEmoji] = useState('📖');

  const addSubtopic = (topicId: string) => {
    if (!newSubtopicName.trim()) {
      alert(language === 'uk' ? 'Введіть назву підтеми!' : 'Enter subtopic name!');
      return;
    }

    const newSubtopic: Subtopic = {
      id: Date.now().toString(),
      name: newSubtopicName,
      emoji: newSubtopicEmoji,
      lessons: []
    };

    const updatedTopics = curriculum.topics.map(topic => {
      if (topic.id === topicId) {
        return {
          ...topic,
          subtopics: [...topic.subtopics, newSubtopic]
        };
      }
      return topic;
    });

    saveCurriculum({ topics: updatedTopics });
    setNewSubtopicName('');
    setNewSubtopicEmoji('📖');
    alert(language === 'uk' ? '✅ Підтема додана!' : '✅ Subtopic added!');
  };

  const deleteSubtopic = (topicId: string, subtopicId: string) => {
    if (confirm(language === 'uk' ? 'Видалити підтему?' : 'Delete subtopic?')) {
      const updatedTopics = curriculum.topics.map(topic => {
        if (topic.id === topicId) {
          return {
            ...topic,
            subtopics: topic.subtopics.filter(s => s.id !== subtopicId)
          };
        }
        return topic;
      });

      saveCurriculum({ topics: updatedTopics });
    }
  };

  // Lesson Management
  const [lessonForm, setLessonForm] = useState<Lesson>({
    id: '',
    title: '',
    videoUrl: '',
    lectureText: '',
    examples: [''],
    hint: '',
    test: { questions: [] }
  });

  const [questionForm, setQuestionForm] = useState<Question>({
    id: '',
    question: '',
    options: ['', '', '', ''],
    correctAnswer: '',
    type: 'multiple-choice'
  });

  const addLesson = (topicId: string, subtopicId: string) => {
    if (!lessonForm.title.trim()) {
      alert(language === 'uk' ? 'Введіть назву уроку!' : 'Enter lesson title!');
      return;
    }

    const newLesson: Lesson = {
      ...lessonForm,
      id: Date.now().toString()
    };

    const updatedTopics = curriculum.topics.map(topic => {
      if (topic.id === topicId) {
        return {
          ...topic,
          subtopics: topic.subtopics.map(subtopic => {
            if (subtopic.id === subtopicId) {
              return {
                ...subtopic,
                lessons: [...subtopic.lessons, newLesson]
              };
            }
            return subtopic;
          })
        };
      }
      return topic;
    });

    saveCurriculum({ topics: updatedTopics });
    
    // Reset form
    setLessonForm({
      id: '',
      title: '',
      videoUrl: '',
      lectureText: '',
      examples: [''],
      hint: '',
      test: { questions: [] }
    });
    
    setEditingLevel(null);
    alert(language === 'uk' ? '✅ Урок додано!' : '✅ Lesson added!');
  };

  const updateLesson = (topicId: string, subtopicId: string, lessonId: string) => {
    const updatedTopics = curriculum.topics.map(topic => {
      if (topic.id === topicId) {
        return {
          ...topic,
          subtopics: topic.subtopics.map(subtopic => {
            if (subtopic.id === subtopicId) {
              return {
                ...subtopic,
                lessons: subtopic.lessons.map(lesson => {
                  if (lesson.id === lessonId) {
                    return { ...lessonForm, id: lessonId };
                  }
                  return lesson;
                })
              };
            }
            return subtopic;
          })
        };
      }
      return topic;
    });

    saveCurriculum({ topics: updatedTopics });
    setEditingLevel(null);
    alert(language === 'uk' ? '✅ Урок оновлено!' : '✅ Lesson updated!');
  };

  const deleteLesson = (topicId: string, subtopicId: string, lessonId: string) => {
    if (confirm(language === 'uk' ? 'Видалити урок?' : 'Delete lesson?')) {
      const updatedTopics = curriculum.topics.map(topic => {
        if (topic.id === topicId) {
          return {
            ...topic,
            subtopics: topic.subtopics.map(subtopic => {
              if (subtopic.id === subtopicId) {
                return {
                  ...subtopic,
                  lessons: subtopic.lessons.filter(l => l.id !== lessonId)
                };
              }
              return subtopic;
            })
          };
        }
        return topic;
      });

      saveCurriculum({ topics: updatedTopics });
    }
  };

  // Question Management
  const addQuestion = () => {
    if (!questionForm.question.trim() || !questionForm.correctAnswer.trim()) {
      alert(language === 'uk' ? 'Заповніть питання та правильну відповідь!' : 'Fill in question and correct answer!');
      return;
    }

    if (questionForm.type === 'multiple-choice') {
      if (questionForm.options?.some(opt => !opt.trim())) {
        alert(language === 'uk' ? 'Заповніть всі варіанти відповіді!' : 'Fill in all answer options!');
        return;
      }
    }

    const newQuestion: Question = {
      ...questionForm,
      id: Date.now().toString()
    };

    setLessonForm({
      ...lessonForm,
      test: {
        questions: [...lessonForm.test.questions, newQuestion]
      }
    });

    // Reset question form
    setQuestionForm({
      id: '',
      question: '',
      options: ['', '', '', ''],
      correctAnswer: '',
      type: 'multiple-choice'
    });

    alert(language === 'uk' ? '✅ Питання додано!' : '✅ Question added!');
  };

  const deleteQuestion = (questionId: string) => {
    setLessonForm({
      ...lessonForm,
      test: {
        questions: lessonForm.test.questions.filter(q => q.id !== questionId)
      }
    });
  };

  const addExample = () => {
    setLessonForm({
      ...lessonForm,
      examples: [...lessonForm.examples, '']
    });
  };

  const updateExample = (index: number, value: string) => {
    const newExamples = [...lessonForm.examples];
    newExamples[index] = value;
    setLessonForm({
      ...lessonForm,
      examples: newExamples
    });
  };

  const deleteExample = (index: number) => {
    setLessonForm({
      ...lessonForm,
      examples: lessonForm.examples.filter((_, i) => i !== index)
    });
  };

  const subjectColors = {
    math: 'from-blue-500 to-cyan-600',
    english: 'from-green-500 to-emerald-600',
    ukrainian: 'from-yellow-500 to-orange-600'
  };

  const subjectNames = {
    math: language === 'uk' ? 'Математика' : 'Math',
    english: language === 'uk' ? 'Англійська' : 'English',
    ukrainian: language === 'uk' ? 'Українська' : 'Ukrainian'
  };

  // Main View - Topic List
  if (!selectedTopic) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-4 md:p-8">
        <div className="max-w-6xl mx-auto">
          <button
            onClick={onBack}
            className="flex items-center gap-2 bg-white text-gray-700 hover:text-gray-900 px-4 py-2 rounded-xl shadow-md hover:shadow-lg transition-all mb-6 font-semibold"
          >
            <ArrowLeft size={20} />
            {language === 'uk' ? 'Назад' : 'Back'}
          </button>

          <div className={`bg-gradient-to-r ${subjectColors[subject]} text-white rounded-2xl p-6 mb-6 shadow-lg`}>
            <h1 className="text-3xl font-bold mb-2">
              📚 {language === 'uk' ? 'Управління навчальною програмою' : 'Curriculum Management'}
            </h1>
            <p className="text-lg opacity-90">
              {subjectNames[subject]} - {language === 'uk' ? 'Теми та уроки' : 'Topics and Lessons'}
            </p>
          </div>

          {/* Add New Topic */}
          <div className="bg-white rounded-2xl p-6 shadow-md mb-6">
            <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
              <Plus size={24} className="text-green-500" />
              {language === 'uk' ? 'Додати нову тему' : 'Add New Topic'}
            </h2>
            
            <div className="grid md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  {language === 'uk' ? 'Назва теми' : 'Topic Name'}
                </label>
                <input
                  type="text"
                  value={newTopicName}
                  onChange={(e) => setNewTopicName(e.target.value)}
                  className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none"
                  placeholder={language === 'uk' ? 'Наприклад: Додавання та віднімання' : 'e.g., Addition and Subtraction'}
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  {language === 'uk' ? 'Емоджі' : 'Emoji'}
                </label>
                <input
                  type="text"
                  value={newTopicEmoji}
                  onChange={(e) => setNewTopicEmoji(e.target.value)}
                  className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none text-2xl"
                  placeholder="📚"
                />
              </div>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-semibold text-gray-700 mb-2">
                {language === 'uk' ? 'Опис теми' : 'Topic Description'}
              </label>
              <textarea
                value={newTopicDescription}
                onChange={(e) => setNewTopicDescription(e.target.value)}
                className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none"
                rows={3}
                placeholder={language === 'uk' ? 'Опишіть тему...' : 'Describe the topic...'}
              />
            </div>

            <button
              onClick={addTopic}
              className="bg-gradient-to-r from-green-500 to-green-600 text-white px-6 py-3 rounded-xl font-bold hover:from-green-600 hover:to-green-700 transition-all shadow-md hover:shadow-lg flex items-center gap-2"
            >
              <Plus size={20} />
              {language === 'uk' ? 'Додати тему' : 'Add Topic'}
            </button>
          </div>

          {/* Topics List */}
          <div className="space-y-4">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">
              {language === 'uk' ? 'Теми' : 'Topics'} ({curriculum.topics.length})
            </h2>
            
            {curriculum.topics.length === 0 ? (
              <div className="bg-white rounded-2xl p-8 text-center shadow-md">
                <BookOpen size={48} className="mx-auto text-gray-400 mb-4" />
                <p className="text-gray-500 text-lg">
                  {language === 'uk' ? 'Немає тем. Додайте першу тему!' : 'No topics yet. Add your first topic!'}
                </p>
              </div>
            ) : (
              curriculum.topics.map(topic => (
                <div key={topic.id} className="bg-white rounded-2xl p-6 shadow-md hover:shadow-lg transition-all border-2 border-gray-200">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <span className="text-4xl">{topic.emoji}</span>
                        <h3 className="text-2xl font-bold text-gray-800">{topic.name}</h3>
                      </div>
                      <p className="text-gray-600 mb-3">{topic.description}</p>
                      <div className="flex items-center gap-4 text-sm text-gray-500">
                        <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full font-semibold">
                          {topic.subtopics.length} {language === 'uk' ? 'підтем' : 'subtopics'}
                        </span>
                        <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full font-semibold">
                          {topic.subtopics.reduce((acc, st) => acc + st.lessons.length, 0)} {language === 'uk' ? 'уроків' : 'lessons'}
                        </span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => setSelectedTopic(topic)}
                        className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-all font-semibold"
                      >
                        {language === 'uk' ? 'Відкрити' : 'Open'}
                      </button>
                      <button
                        onClick={() => deleteTopic(topic.id)}
                        className="bg-red-500 text-white p-2 rounded-lg hover:bg-red-600 transition-all"
                      >
                        <Trash2 size={20} />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    );
  }

  // Subtopic View
  if (selectedTopic && !selectedSubtopic) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-4 md:p-8">
        <div className="max-w-6xl mx-auto">
          <button
            onClick={() => setSelectedTopic(null)}
            className="flex items-center gap-2 bg-white text-gray-700 hover:text-gray-900 px-4 py-2 rounded-xl shadow-md hover:shadow-lg transition-all mb-6 font-semibold"
          >
            <ArrowLeft size={20} />
            {language === 'uk' ? 'До тем' : 'Back to Topics'}
          </button>

          <div className={`bg-gradient-to-r ${subjectColors[subject]} text-white rounded-2xl p-6 mb-6 shadow-lg`}>
            <div className="flex items-center gap-3 mb-2">
              <span className="text-5xl">{selectedTopic.emoji}</span>
              <h1 className="text-3xl font-bold">{selectedTopic.name}</h1>
            </div>
            <p className="text-lg opacity-90">{selectedTopic.description}</p>
          </div>

          {/* Add New Subtopic */}
          <div className="bg-white rounded-2xl p-6 shadow-md mb-6">
            <h2 className="text-xl font-bold text-gray-800 mb-4 flex items-center gap-2">
              <Plus size={24} className="text-green-500" />
              {language === 'uk' ? 'Додати нову підтему' : 'Add New Subtopic'}
            </h2>
            
            <div className="grid md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  {language === 'uk' ? 'Назва підтеми' : 'Subtopic Name'}
                </label>
                <input
                  type="text"
                  value={newSubtopicName}
                  onChange={(e) => setNewSubtopicName(e.target.value)}
                  className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none"
                  placeholder={language === 'uk' ? 'Наприклад: Додавання до 10' : 'e.g., Addition up to 10'}
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  {language === 'uk' ? 'Емоджі' : 'Emoji'}
                </label>
                <input
                  type="text"
                  value={newSubtopicEmoji}
                  onChange={(e) => setNewSubtopicEmoji(e.target.value)}
                  className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none text-2xl"
                  placeholder="📖"
                />
              </div>
            </div>

            <button
              onClick={() => addSubtopic(selectedTopic.id)}
              className="bg-gradient-to-r from-green-500 to-green-600 text-white px-6 py-3 rounded-xl font-bold hover:from-green-600 hover:to-green-700 transition-all shadow-md hover:shadow-lg flex items-center gap-2"
            >
              <Plus size={20} />
              {language === 'uk' ? 'Додати підтему' : 'Add Subtopic'}
            </button>
          </div>

          {/* Subtopics List */}
          <div className="space-y-4">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">
              {language === 'uk' ? 'Підтеми' : 'Subtopics'} ({selectedTopic.subtopics.length})
            </h2>
            
            {selectedTopic.subtopics.length === 0 ? (
              <div className="bg-white rounded-2xl p-8 text-center shadow-md">
                <BookOpen size={48} className="mx-auto text-gray-400 mb-4" />
                <p className="text-gray-500 text-lg">
                  {language === 'uk' ? 'Немає підтем. Додайте першу підтему!' : 'No subtopics yet. Add your first subtopic!'}
                </p>
              </div>
            ) : (
              selectedTopic.subtopics.map(subtopic => (
                <div key={subtopic.id} className="bg-white rounded-2xl p-6 shadow-md hover:shadow-lg transition-all border-2 border-gray-200">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <span className="text-3xl">{subtopic.emoji}</span>
                        <h3 className="text-xl font-bold text-gray-800">{subtopic.name}</h3>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-gray-500">
                        <span className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full font-semibold">
                          {subtopic.lessons.length} {language === 'uk' ? 'уроків' : 'lessons'}
                        </span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => setSelectedSubtopic(subtopic)}
                        className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-all font-semibold"
                      >
                        {language === 'uk' ? 'Відкрити' : 'Open'}
                      </button>
                      <button
                        onClick={() => deleteSubtopic(selectedTopic.id, subtopic.id)}
                        className="bg-red-500 text-white p-2 rounded-lg hover:bg-red-600 transition-all"
                      >
                        <Trash2 size={20} />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    );
  }

  // Lesson View
  if (selectedTopic && selectedSubtopic) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-4 md:p-8">
        <div className="max-w-6xl mx-auto">
          <button
            onClick={() => {
              setSelectedSubtopic(null);
              setEditingLevel(null);
            }}
            className="flex items-center gap-2 bg-white text-gray-700 hover:text-gray-900 px-4 py-2 rounded-xl shadow-md hover:shadow-lg transition-all mb-6 font-semibold"
          >
            <ArrowLeft size={20} />
            {language === 'uk' ? 'До підтем' : 'Back to Subtopics'}
          </button>

          <div className={`bg-gradient-to-r ${subjectColors[subject]} text-white rounded-2xl p-6 mb-6 shadow-lg`}>
            <div className="flex items-center gap-3 mb-2">
              <span className="text-4xl">{selectedSubtopic.emoji}</span>
              <div>
                <p className="text-sm opacity-80">{selectedTopic.name}</p>
                <h1 className="text-3xl font-bold">{selectedSubtopic.name}</h1>
              </div>
            </div>
          </div>

          {/* Add/Edit Lesson Form */}
          {editingLevel === 'lesson' && (
            <div className="bg-white rounded-2xl p-6 shadow-md mb-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
                  {lessonForm.id ? <Edit2 size={24} className="text-blue-500" /> : <Plus size={24} className="text-green-500" />}
                  {lessonForm.id
                    ? (language === 'uk' ? 'Редагувати урок' : 'Edit Lesson')
                    : (language === 'uk' ? 'Додати новий урок' : 'Add New Lesson')}
                </h2>
                <button
                  onClick={() => {
                    setEditingLevel(null);
                    setLessonForm({
                      id: '',
                      title: '',
                      videoUrl: '',
                      lectureText: '',
                      examples: [''],
                      hint: '',
                      test: { questions: [] }
                    });
                  }}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X size={24} />
                </button>
              </div>

              {/* Lesson Title */}
              <div className="mb-4">
                <label className="block text-sm font-semibold text-gray-700 mb-2">
                  {language === 'uk' ? 'Назва уроку' : 'Lesson Title'}
                </label>
                <input
                  type="text"
                  value={lessonForm.title}
                  onChange={(e) => setLessonForm({ ...lessonForm, title: e.target.value })}
                  className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none"
                  placeholder={language === 'uk' ? 'Наприклад: Додавання чисел 1-5' : 'e.g., Adding Numbers 1-5'}
                />
              </div>

              {/* Video URL */}
              <div className="mb-4">
                <label className="block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
                  <Video size={18} />
                  {language === 'uk' ? 'Відео-лекція (URL YouTube)' : 'Video Lecture (YouTube URL)'}
                </label>
                <input
                  type="text"
                  value={lessonForm.videoUrl}
                  onChange={(e) => setLessonForm({ ...lessonForm, videoUrl: e.target.value })}
                  className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none"
                  placeholder="https://www.youtube.com/watch?v=..."
                />
              </div>

              {/* Lecture Text */}
              <div className="mb-4">
                <label className="block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
                  <FileText size={18} />
                  {language === 'uk' ? 'Текст лекції' : 'Lecture Text'}
                </label>
                <textarea
                  value={lessonForm.lectureText}
                  onChange={(e) => setLessonForm({ ...lessonForm, lectureText: e.target.value })}
                  className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none"
                  rows={6}
                  placeholder={language === 'uk' ? 'Введіть текст лекції...' : 'Enter lecture text...'}
                />
              </div>

              {/* Examples */}
              <div className="mb-4">
                <label className="block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
                  <BookOpen size={18} />
                  {language === 'uk' ? 'Приклади' : 'Examples'}
                </label>
                {lessonForm.examples.map((example, index) => (
                  <div key={index} className="flex gap-2 mb-2">
                    <input
                      type="text"
                      value={example}
                      onChange={(e) => updateExample(index, e.target.value)}
                      className="flex-1 px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none"
                      placeholder={`${language === 'uk' ? 'Приклад' : 'Example'} ${index + 1}`}
                    />
                    <button
                      onClick={() => deleteExample(index)}
                      className="bg-red-500 text-white px-3 rounded-lg hover:bg-red-600 transition-all"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                ))}
                <button
                  onClick={addExample}
                  className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-all font-semibold flex items-center gap-2 mt-2"
                >
                  <Plus size={18} />
                  {language === 'uk' ? 'Додати приклад' : 'Add Example'}
                </button>
              </div>

              {/* Hint */}
              <div className="mb-6">
                <label className="block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
                  <HelpCircle size={18} />
                  {language === 'uk' ? 'Підказка (з\'явиться в куті екрана під час тесту)' : 'Hint (will appear in corner during test)'}
                </label>
                <textarea
                  value={lessonForm.hint}
                  onChange={(e) => setLessonForm({ ...lessonForm, hint: e.target.value })}
                  className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none"
                  rows={3}
                  placeholder={language === 'uk' ? 'Корисна підказка для учнів...' : 'Helpful hint for students...'}
                />
              </div>

              {/* Test Questions Section */}
              <div className="border-t-4 border-gray-200 pt-6 mb-6">
                <h3 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
                  ✅ {language === 'uk' ? 'Тест' : 'Test'} ({lessonForm.test.questions.length} {language === 'uk' ? 'питань' : 'questions'})
                </h3>

                {/* Question Form */}
                <div className="bg-gray-50 rounded-xl p-4 mb-4">
                  <h4 className="font-semibold text-gray-700 mb-3">
                    {language === 'uk' ? 'Додати питання' : 'Add Question'}
                  </h4>

                  <div className="mb-3">
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      {language === 'uk' ? 'Тип питання' : 'Question Type'}
                    </label>
                    <select
                      value={questionForm.type}
                      onChange={(e) => setQuestionForm({ ...questionForm, type: e.target.value as 'multiple-choice' | 'text-input' })}
                      className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none"
                    >
                      <option value="multiple-choice">{language === 'uk' ? 'Вибір варіанту' : 'Multiple Choice'}</option>
                      <option value="text-input">{language === 'uk' ? 'Текстова відповідь' : 'Text Input'}</option>
                    </select>
                  </div>

                  <div className="mb-3">
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      {language === 'uk' ? 'Питання' : 'Question'}
                    </label>
                    <input
                      type="text"
                      value={questionForm.question}
                      onChange={(e) => setQuestionForm({ ...questionForm, question: e.target.value })}
                      className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none"
                      placeholder={language === 'uk' ? 'Введіть питання...' : 'Enter question...'}
                    />
                  </div>

                  {questionForm.type === 'multiple-choice' && (
                    <div className="mb-3">
                      <label className="block text-sm font-semibold text-gray-700 mb-2">
                        {language === 'uk' ? 'Варіанти відповідей' : 'Answer Options'}
                      </label>
                      {questionForm.options?.map((option, index) => (
                        <input
                          key={index}
                          type="text"
                          value={option}
                          onChange={(e) => {
                            const newOptions = [...(questionForm.options || [])];
                            newOptions[index] = e.target.value;
                            setQuestionForm({ ...questionForm, options: newOptions });
                          }}
                          className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none mb-2"
                          placeholder={`${language === 'uk' ? 'Варіант' : 'Option'} ${index + 1}`}
                        />
                      ))}
                    </div>
                  )}

                  <div className="mb-3">
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      {language === 'uk' ? 'Правильна відповідь' : 'Correct Answer'}
                    </label>
                    <input
                      type="text"
                      value={questionForm.correctAnswer}
                      onChange={(e) => setQuestionForm({ ...questionForm, correctAnswer: e.target.value })}
                      className="w-full px-4 py-2 border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none"
                      placeholder={language === 'uk' ? 'Введіть правильну відповідь...' : 'Enter correct answer...'}
                    />
                  </div>

                  <button
                    onClick={addQuestion}
                    className="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition-all font-semibold flex items-center gap-2"
                  >
                    <Plus size={18} />
                    {language === 'uk' ? 'Додати питання' : 'Add Question'}
                  </button>
                </div>

                {/* Questions List */}
                {lessonForm.test.questions.length > 0 && (
                  <div className="space-y-2">
                    {lessonForm.test.questions.map((question, index) => (
                      <div key={question.id} className="bg-white border-2 border-gray-200 rounded-lg p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <span className="bg-blue-500 text-white font-bold px-3 py-1 rounded-full text-xs">
                                Q{index + 1}
                              </span>
                              <span className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-xs font-semibold">
                                {question.type === 'multiple-choice' ? (language === 'uk' ? 'Вибір' : 'Multiple Choice') : (language === 'uk' ? 'Текст' : 'Text')}
                              </span>
                            </div>
                            <p className="font-semibold text-gray-800 mb-2">{question.question}</p>
                            {question.options && (
                              <div className="text-sm text-gray-600 ml-4 space-y-1">
                                {question.options.map((opt, i) => (
                                  <div key={i} className={opt === question.correctAnswer ? 'text-green-600 font-bold' : ''}>
                                    • {opt} {opt === question.correctAnswer && '✓'}
                                  </div>
                                ))}
                              </div>
                            )}
                            {!question.options && (
                              <p className="text-sm text-green-600 font-semibold ml-4">
                                {language === 'uk' ? 'Відповідь' : 'Answer'}: {question.correctAnswer}
                              </p>
                            )}
                          </div>
                          <button
                            onClick={() => deleteQuestion(question.id)}
                            className="bg-red-500 text-white p-2 rounded-lg hover:bg-red-600 transition-all"
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Save Lesson Button */}
              <div className="flex gap-3">
                <button
                  onClick={() => {
                    if (lessonForm.id) {
                      updateLesson(selectedTopic.id, selectedSubtopic.id, lessonForm.id);
                    } else {
                      addLesson(selectedTopic.id, selectedSubtopic.id);
                    }
                  }}
                  className="flex-1 bg-gradient-to-r from-green-500 to-green-600 text-white px-6 py-3 rounded-xl font-bold hover:from-green-600 hover:to-green-700 transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-2"
                >
                  <Save size={20} />
                  {lessonForm.id
                    ? (language === 'uk' ? 'Зберегти зміни' : 'Save Changes')
                    : (language === 'uk' ? 'Створити урок' : 'Create Lesson')}
                </button>
                <button
                  onClick={() => {
                    setEditingLevel(null);
                    setLessonForm({
                      id: '',
                      title: '',
                      videoUrl: '',
                      lectureText: '',
                      examples: [''],
                      hint: '',
                      test: { questions: [] }
                    });
                  }}
                  className="bg-gray-500 text-white px-6 py-3 rounded-xl font-bold hover:bg-gray-600 transition-all shadow-md hover:shadow-lg"
                >
                  {language === 'uk' ? 'Скасувати' : 'Cancel'}
                </button>
              </div>
            </div>
          )}

          {/* Add Lesson Button */}
          {!editingLevel && (
            <div className="mb-6">
              <button
                onClick={() => setEditingLevel('lesson')}
                className="bg-gradient-to-r from-green-500 to-green-600 text-white px-6 py-3 rounded-xl font-bold hover:from-green-600 hover:to-green-700 transition-all shadow-md hover:shadow-lg flex items-center gap-2"
              >
                <Plus size={20} />
                {language === 'uk' ? 'Додати новий урок' : 'Add New Lesson'}
              </button>
            </div>
          )}

          {/* Lessons List */}
          <div className="space-y-4">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">
              {language === 'uk' ? 'Уроки' : 'Lessons'} ({selectedSubtopic.lessons.length})
            </h2>
            
            {selectedSubtopic.lessons.length === 0 ? (
              <div className="bg-white rounded-2xl p-8 text-center shadow-md">
                <BookOpen size={48} className="mx-auto text-gray-400 mb-4" />
                <p className="text-gray-500 text-lg">
                  {language === 'uk' ? 'Немає уроків. Додайте перший урок!' : 'No lessons yet. Add your first lesson!'}
                </p>
              </div>
            ) : (
              selectedSubtopic.lessons.map((lesson, index) => (
                <div key={lesson.id} className="bg-white rounded-2xl p-6 shadow-md hover:shadow-lg transition-all border-2 border-gray-200">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-3">
                        <span className="bg-purple-500 text-white font-bold px-4 py-2 rounded-full text-sm">
                          {language === 'uk' ? 'Урок' : 'Lesson'} {index + 1}
                        </span>
                        <h3 className="text-xl font-bold text-gray-800">{lesson.title}</h3>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                        <div className={`flex items-center gap-2 px-3 py-2 rounded-lg ${lesson.videoUrl ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-500'}`}>
                          <Video size={16} />
                          <span className="font-semibold">{lesson.videoUrl ? (language === 'uk' ? 'Є відео' : 'Has Video') : (language === 'uk' ? 'Немає' : 'No Video')}</span>
                        </div>
                        <div className={`flex items-center gap-2 px-3 py-2 rounded-lg ${lesson.lectureText ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-500'}`}>
                          <FileText size={16} />
                          <span className="font-semibold">{lesson.lectureText ? (language === 'uk' ? 'Є лекція' : 'Has Lecture') : (language === 'uk' ? 'Немає' : 'No Lecture')}</span>
                        </div>
                        <div className="bg-green-100 text-green-700 flex items-center gap-2 px-3 py-2 rounded-lg">
                          <BookOpen size={16} />
                          <span className="font-semibold">{lesson.examples.filter(e => e.trim()).length} {language === 'uk' ? 'прикладів' : 'examples'}</span>
                        </div>
                        <div className="bg-purple-100 text-purple-700 flex items-center gap-2 px-3 py-2 rounded-lg">
                          <HelpCircle size={16} />
                          <span className="font-semibold">{lesson.test.questions.length} {language === 'uk' ? 'питань' : 'questions'}</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex gap-2 ml-4">
                      <button
                        onClick={() => {
                          setLessonForm(lesson);
                          setEditingLevel('lesson');
                        }}
                        className="bg-blue-500 text-white p-2 rounded-lg hover:bg-blue-600 transition-all"
                      >
                        <Edit2 size={20} />
                      </button>
                      <button
                        onClick={() => deleteLesson(selectedTopic.id, selectedSubtopic.id, lesson.id)}
                        className="bg-red-500 text-white p-2 rounded-lg hover:bg-red-600 transition-all"
                      >
                        <Trash2 size={20} />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    );
  }

  return null;
}
