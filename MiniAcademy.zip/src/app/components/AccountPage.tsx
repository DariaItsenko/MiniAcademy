import { ArrowLeft, Trophy, Award, Star, GraduationCap } from 'lucide-react';
import { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';

interface UserProgress {
  math: { levels: Array<{ completed: boolean; stars: number }> };
  english: { levels: Array<{ completed: boolean; stars: number }> };
  ukrainian: { levels: Array<{ completed: boolean; stars: number }> };
}

interface AccountPageProps {
  username: string;
  progress: UserProgress;
  grade: number;
  onBack: () => void;
  onGradeChange: (newGrade: number) => void;
}

const levelNames = {
  math: ['Addition & Subtraction', 'Multiplication Tables', 'Division Basics', 'Advanced Problem Solving'],
  english: ['Alphabet & Phonics', 'Reading Simple Sentences', 'Story Writing', 'Advanced Grammar'],
  ukrainian: ['Абетка і звуки', 'Прості слова', 'Речення', 'Твори і оповідання']
};

const calculateGrade = (stars: number, totalStars: number): number => {
  // Convert stars to percentage then to 12-point scale
  const percentage = (stars / totalStars) * 100;
  if (percentage >= 95) return 12;
  if (percentage >= 90) return 11;
  if (percentage >= 85) return 10;
  if (percentage >= 80) return 9;
  if (percentage >= 75) return 8;
  if (percentage >= 70) return 7;
  if (percentage >= 65) return 6;
  if (percentage >= 60) return 5;
  if (percentage >= 55) return 4;
  if (percentage >= 50) return 3;
  if (percentage >= 45) return 2;
  if (percentage >= 40) return 1;
  return 0;
};

const getGradeDescription = (grade: number, t: (key: string) => string): string => {
  if (grade === 12) return t('account.excellent');
  if (grade >= 10) return t('account.veryGood');
  if (grade >= 7) return t('account.good');
  if (grade >= 5) return t('account.satisfactory');
  if (grade >= 3) return t('account.sufficient');
  return t('account.needsImprovement');
};

const getGradeColor = (grade: number): string => {
  if (grade >= 10) return 'bg-green-500';
  if (grade >= 7) return 'bg-blue-500';
  if (grade >= 5) return 'bg-yellow-500';
  return 'bg-orange-500';
};

export function AccountPage({ username, progress, grade, onBack, onGradeChange }: AccountPageProps) {
  const { t } = useLanguage();
  const [showGradeSelector, setShowGradeSelector] = useState(false);
  
  const calculateSubjectGrade = (subject: 'math' | 'english' | 'ukrainian'): number => {
    const levels = progress[subject].levels;
    const totalStars = levels.reduce((sum, level) => sum + level.stars, 0);
    const maxStars = levels.length * 3; // 3 stars per level
    return calculateGrade(totalStars, maxStars);
  };

  const mathGrade = calculateSubjectGrade('math');
  const englishGrade = calculateSubjectGrade('english');
  const ukrainianGrade = calculateSubjectGrade('ukrainian');
  
  const overallGrade = Math.round((mathGrade + englishGrade + ukrainianGrade) / 3);

  const getTotalStars = (subject: 'math' | 'english' | 'ukrainian'): number => {
    return progress[subject].levels.reduce((sum, level) => sum + level.stars, 0);
  };

  const handleGradeChange = (newGrade: number) => {
    onGradeChange(newGrade);
    setShowGradeSelector(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-8">
      <div className="max-w-6xl mx-auto">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-700 hover:text-gray-900 mb-8 font-semibold"
        >
          <ArrowLeft size={20} />
          {t('account.backToHome')}
        </button>

        {/* Header */}
        <div className="bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-2xl p-8 mb-8 shadow-lg">
          <div className="flex items-center gap-4 mb-4">
            <div className="bg-white bg-opacity-20 p-4 rounded-full">
              <Trophy size={48} />
            </div>
            <div>
              <h1 className="text-4xl font-bold">{username}{t('account.title')}</h1>
              <p className="text-lg opacity-90">{t('account.subtitle')}</p>
            </div>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mt-6">
            <div className="bg-white bg-opacity-20 rounded-lg p-4">
              <div className="text-sm opacity-90">{t('account.currentGrade')}</div>
              <div className="text-3xl font-bold flex items-center gap-2">
                <GraduationCap size={28} />
                {t(`grade.${grade}`)}
              </div>
            </div>
            <div className="bg-white bg-opacity-20 rounded-lg p-4">
              <div className="text-sm opacity-90">{t('account.overallGrade')}</div>
              <div className="text-3xl font-bold">{overallGrade}/12</div>
            </div>
            <div className="bg-white bg-opacity-20 rounded-lg p-4">
              <div className="text-sm opacity-90">{t('subject.math')}</div>
              <div className="text-3xl font-bold">{mathGrade}/12</div>
            </div>
            <div className="bg-white bg-opacity-20 rounded-lg p-4">
              <div className="text-sm opacity-90">{t('subject.english')}</div>
              <div className="text-3xl font-bold">{englishGrade}/12</div>
            </div>
            <div className="bg-white bg-opacity-20 rounded-lg p-4">
              <div className="text-sm opacity-90">{t('subject.ukrainian')}</div>
              <div className="text-3xl font-bold">{ukrainianGrade}/12</div>
            </div>
          </div>
          
          <button
            onClick={() => setShowGradeSelector(!showGradeSelector)}
            className="mt-4 bg-white bg-opacity-20 hover:bg-opacity-30 px-6 py-2 rounded-full text-white font-semibold transition-all"
          >
            {t('account.changeGrade')}
          </button>
          
          {showGradeSelector && (
            <div className="mt-4 bg-white bg-opacity-20 rounded-lg p-4">
              <div className="grid grid-cols-5 gap-2">
                {[1, 2, 3, 4, 5].map((g) => (
                  <button
                    key={g}
                    onClick={() => handleGradeChange(g)}
                    className={`py-3 rounded-lg font-semibold transition-all ${
                      grade === g
                        ? 'bg-white text-purple-600'
                        : 'bg-white bg-opacity-30 text-white hover:bg-opacity-40'
                    }`}
                  >
                    {t(`grade.${g}`)}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* 12-Point Grading Scale Reference */}
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
          <div className="flex items-center gap-3 mb-6">
            <Award size={32} className="text-purple-600" />
            <h2 className="text-3xl font-bold text-gray-800">{t('account.gradingScale')}</h2>
          </div>
          
          <div className="grid md:grid-cols-2 gap-4">
            {[
              { grade: 12, desc: t('account.excellent'), range: '95-100%' },
              { grade: 11, desc: t('account.excellent'), range: '90-94%' },
              { grade: 10, desc: t('account.veryGood'), range: '85-89%' },
              { grade: 9, desc: t('account.veryGood'), range: '80-84%' },
              { grade: 8, desc: t('account.good'), range: '75-79%' },
              { grade: 7, desc: t('account.good'), range: '70-74%' },
              { grade: 6, desc: t('account.satisfactory'), range: '65-69%' },
              { grade: 5, desc: t('account.satisfactory'), range: '60-64%' },
              { grade: 4, desc: t('account.sufficient'), range: '55-59%' },
              { grade: 3, desc: t('account.sufficient'), range: '50-54%' },
              { grade: 2, desc: t('account.needsImprovement'), range: '45-49%' },
              { grade: 1, desc: t('account.needsImprovement'), range: '40-44%' }
            ].map((item) => (
              <div key={item.grade} className="flex items-center gap-4 p-3 bg-gray-50 rounded-lg">
                <div className={`${getGradeColor(item.grade)} text-white font-bold text-xl w-12 h-12 flex items-center justify-center rounded-lg`}>
                  {item.grade}
                </div>
                <div className="flex-1">
                  <div className="font-semibold text-gray-800">{item.desc}</div>
                  <div className="text-sm text-gray-600">{item.range}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Detailed Subject Progress */}
        <div className="grid md:grid-cols-3 gap-6">
          {/* Math */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-2xl font-bold text-blue-600">{t('subject.math')}</h3>
              <div className={`${getGradeColor(mathGrade)} text-white font-bold text-2xl w-14 h-14 flex items-center justify-center rounded-lg`}>
                {mathGrade}
              </div>
            </div>
            <div className="mb-4">
              <div className="text-sm text-gray-600 mb-1">{t('account.totalStars')}: {getTotalStars('math')}/12</div>
              <div className="text-sm font-medium text-gray-700">{getGradeDescription(mathGrade, t)}</div>
            </div>
            <div className="space-y-3">
              {progress.math.levels.map((level, index) => (
                <div key={index} className="border-l-4 border-blue-500 pl-3">
                  <div className="text-sm font-semibold text-gray-800">{t(`level.math.${index + 1}.title`)}</div>
                  <div className="flex items-center gap-1 mt-1">
                    {[...Array(3)].map((_, i) => (
                      <Star
                        key={i}
                        size={16}
                        className={i < level.stars ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}
                      />
                    ))}
                    <span className="text-xs text-gray-600 ml-2">{level.stars}/3</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* English */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-2xl font-bold text-green-600">{t('subject.english')}</h3>
              <div className={`${getGradeColor(englishGrade)} text-white font-bold text-2xl w-14 h-14 flex items-center justify-center rounded-lg`}>
                {englishGrade}
              </div>
            </div>
            <div className="mb-4">
              <div className="text-sm text-gray-600 mb-1">{t('account.totalStars')}: {getTotalStars('english')}/12</div>
              <div className="text-sm font-medium text-gray-700">{getGradeDescription(englishGrade, t)}</div>
            </div>
            <div className="space-y-3">
              {progress.english.levels.map((level, index) => (
                <div key={index} className="border-l-4 border-green-500 pl-3">
                  <div className="text-sm font-semibold text-gray-800">{t(`level.english.${index + 1}.title`)}</div>
                  <div className="flex items-center gap-1 mt-1">
                    {[...Array(3)].map((_, i) => (
                      <Star
                        key={i}
                        size={16}
                        className={i < level.stars ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}
                      />
                    ))}
                    <span className="text-xs text-gray-600 ml-2">{level.stars}/3</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Ukrainian */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-2xl font-bold text-orange-600">{t('subject.ukrainian')}</h3>
              <div className={`${getGradeColor(ukrainianGrade)} text-white font-bold text-2xl w-14 h-14 flex items-center justify-center rounded-lg`}>
                {ukrainianGrade}
              </div>
            </div>
            <div className="mb-4">
              <div className="text-sm text-gray-600 mb-1">{t('account.totalStars')}: {getTotalStars('ukrainian')}/12</div>
              <div className="text-sm font-medium text-gray-700">{getGradeDescription(ukrainianGrade, t)}</div>
            </div>
            <div className="space-y-3">
              {progress.ukrainian.levels.map((level, index) => (
                <div key={index} className="border-l-4 border-orange-500 pl-3">
                  <div className="text-sm font-semibold text-gray-800">{levelNames.ukrainian[index]}</div>
                  <div className="flex items-center gap-1 mt-1">
                    {[...Array(3)].map((_, i) => (
                      <Star
                        key={i}
                        size={16}
                        className={i < level.stars ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}
                      />
                    ))}
                    <span className="text-xs text-gray-600 ml-2">{level.stars}/3</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}