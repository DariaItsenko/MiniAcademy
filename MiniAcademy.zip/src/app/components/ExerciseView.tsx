import { ArrowLeft } from 'lucide-react';
import { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { MathExercise } from './exercises/MathExercise';
import { EnglishExercise } from './exercises/EnglishExercise';
import { UkrainianExercise } from './exercises/UkrainianExercise';
import {
  DragDropCategorize,
  SentenceOrdering,
  ClickCorrectObject,
  ColumnMatching,
  MiniSimulation,
} from './interactive-exercises';

interface ExerciseViewProps {
  subject: 'math' | 'english' | 'ukrainian';
  level: number;
  onBack: () => void;
  onComplete: (stars: number) => void;
}

type ExerciseType = 'quiz' | 'drag-drop' | 'ordering' | 'click' | 'matching' | 'simulation';

export function ExerciseView({ subject, level, onBack, onComplete }: ExerciseViewProps) {
  const { language } = useLanguage();
  const [selectedType, setSelectedType] = useState<ExerciseType | null>(null);

  const titles = {
    math: language === 'uk' ? 'Математична вправа' : 'Math Exercise',
    english: language === 'uk' ? 'Англійська вправа' : 'English Exercise',
    ukrainian: 'Українська вправа'
  };

  const colors = {
    math: 'bg-gradient-to-br from-blue-500 to-blue-700',
    english: 'bg-gradient-to-br from-green-500 to-green-700',
    ukrainian: 'bg-gradient-to-br from-yellow-500 to-orange-600'
  };

  const exerciseTypes = [
    {
      type: 'quiz' as ExerciseType,
      name: language === 'uk' ? 'Вікторина' : 'Quiz',
      emoji: '📝',
      description: language === 'uk' ? 'Вибери правильну відповідь' : 'Choose the correct answer',
      color: 'from-blue-400 to-blue-600',
    },
    {
      type: 'drag-drop' as ExerciseType,
      name: language === 'uk' ? 'Перетягування' : 'Drag & Drop',
      emoji: '🎯',
      description: language === 'uk' ? 'Розподіли за категоріями' : 'Categorize items',
      color: 'from-purple-400 to-purple-600',
    },
    {
      type: 'ordering' as ExerciseType,
      name: language === 'uk' ? 'Складання' : 'Puzzle',
      emoji: '🧩',
      description: language === 'uk' ? 'Склади речення' : 'Build sentences',
      color: 'from-pink-400 to-pink-600',
    },
    {
      type: 'click' as ExerciseType,
      name: language === 'uk' ? 'Знайди об\'єкт' : 'Find Object',
      emoji: '🔍',
      description: language === 'uk' ? 'Клацни правильний об\'єкт' : 'Click the correct object',
      color: 'from-green-400 to-green-600',
    },
    {
      type: 'matching' as ExerciseType,
      name: language === 'uk' ? 'З\'єднування' : 'Matching',
      emoji: '🔗',
      description: language === 'uk' ? 'З\'єднай пари' : 'Connect pairs',
      color: 'from-orange-400 to-orange-600',
    },
    {
      type: 'simulation' as ExerciseType,
      name: language === 'uk' ? 'Пригода' : 'Adventure',
      emoji: '🎮',
      description: language === 'uk' ? 'Інтерактивні сценарії' : 'Interactive scenarios',
      color: 'from-yellow-400 to-yellow-600',
    },
  ];

  if (!selectedType) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-4 md:p-8">
        <div className="max-w-6xl mx-auto">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-gray-700 hover:text-gray-900 mb-6 md:mb-8 font-semibold text-sm md:text-base"
          >
            <ArrowLeft size={20} />
            {language === 'uk' ? 'Назад до рівнів' : 'Back to Levels'}
          </button>

          <div className={`${colors[subject]} text-white rounded-2xl md:rounded-3xl p-6 md:p-8 mb-8 shadow-lg border-4 border-white`}>
            <h1 className="text-3xl md:text-4xl font-bold mb-2">{titles[subject]}</h1>
            <p className="text-lg md:text-xl opacity-90">
              {language === 'uk' ? `Рівень ${level}` : `Level ${level}`}
            </p>
          </div>

          <div className="mb-8 text-center">
            <h2 className="text-2xl md:text-4xl font-bold text-gray-800 mb-4">
              {language === 'uk' ? '🎨 Обери тип вправи' : '🎨 Choose Exercise Type'}
            </h2>
            <p className="text-base md:text-lg text-gray-600">
              {language === 'uk' 
                ? 'Різні типи вправ допомагають краще засвоїти матеріал!'
                : 'Different exercise types help you learn better!'}
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
            {exerciseTypes.map((exercise) => (
              <button
                key={exercise.type}
                onClick={() => setSelectedType(exercise.type)}
                className={`bg-gradient-to-br ${exercise.color} text-white p-6 md:p-8 rounded-2xl md:rounded-3xl shadow-xl hover:shadow-2xl transition-all transform hover:scale-105 border-4 border-white`}
              >
                <div className="text-center">
                  <div className="text-5xl md:text-6xl mb-4 animate-bounce">{exercise.emoji}</div>
                  <h3 className="text-xl md:text-2xl font-bold mb-2">{exercise.name}</h3>
                  <p className="text-sm md:text-base opacity-90">{exercise.description}</p>
                </div>
              </button>
            ))}
          </div>

          <div className="mt-8 bg-blue-100 rounded-2xl p-6 border-4 border-blue-300">
            <p className="text-center text-gray-700 text-sm md:text-base">
              <strong className="text-lg md:text-xl">💡 {language === 'uk' ? 'Порада:' : 'Tip:'}</strong>{' '}
              {language === 'uk'
                ? 'Спробуй різні типи вправ, щоб знайти свій улюблений спосіб навчання!'
                : 'Try different exercise types to find your favorite way to learn!'}
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <button
          onClick={() => setSelectedType(null)}
          className="flex items-center gap-2 text-gray-700 hover:text-gray-900 mb-6 md:mb-8 font-semibold text-sm md:text-base"
        >
          <ArrowLeft size={20} />
          {language === 'uk' ? 'Змінити тип вправи' : 'Change Exercise Type'}
        </button>

        <div className={`${colors[subject]} text-white rounded-2xl md:rounded-3xl p-6 md:p-8 mb-8 shadow-lg border-4 border-white`}>
          <h1 className="text-3xl md:text-4xl font-bold mb-2">{titles[subject]}</h1>
          <p className="text-lg md:text-xl opacity-90">
            {language === 'uk' ? `Рівень ${level}` : `Level ${level}`}
          </p>
        </div>

        <div className="bg-white rounded-2xl md:rounded-3xl shadow-lg p-4 md:p-8">
          {selectedType === 'quiz' && subject === 'math' && <MathExercise level={level} onComplete={onComplete} />}
          {selectedType === 'quiz' && subject === 'english' && <EnglishExercise level={level} onComplete={onComplete} />}
          {selectedType === 'quiz' && subject === 'ukrainian' && <UkrainianExercise level={level} onComplete={onComplete} />}
          
          {selectedType === 'drag-drop' && <DragDropCategorize onComplete={onComplete} subject={subject} />}
          {selectedType === 'ordering' && <SentenceOrdering onComplete={onComplete} subject={subject} />}
          {selectedType === 'click' && <ClickCorrectObject onComplete={onComplete} subject={subject} />}
          {selectedType === 'matching' && <ColumnMatching onComplete={onComplete} subject={subject} />}
          {selectedType === 'simulation' && <MiniSimulation onComplete={onComplete} subject={subject} />}
        </div>
      </div>
    </div>
  );
}