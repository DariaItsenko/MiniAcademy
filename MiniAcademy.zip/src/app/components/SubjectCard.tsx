import { LucideIcon } from 'lucide-react';

interface SubjectCardProps {
  title: string;
  icon: LucideIcon;
  color: string;
  onClick: () => void;
}

export function SubjectCard({ title, icon: Icon, color, onClick }: SubjectCardProps) {
  return (
    <button
      onClick={onClick}
      className={`${color} rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all transform hover:scale-105 flex flex-col items-center gap-4 text-white min-w-64`}
    >
      <Icon size={64} strokeWidth={2} />
      <h2 className="text-3xl font-bold">{title}</h2>
    </button>
  );
}
