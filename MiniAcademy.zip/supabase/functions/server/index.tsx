import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";
import { createHash } from "node:crypto";

const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Helper function to hash passwords
function hashPassword(password: string): string {
  return createHash('sha256').update(password).digest('hex');
}

// Helper function to generate session token
function generateToken(): string {
  const array = new Uint8Array(32);
  crypto.getRandomValues(array);
  return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
}

// Health check endpoint
app.get("/make-server-51051136/health", (c) => {
  return c.json({ status: "ok" });
});

// Register endpoint
app.post("/make-server-51051136/register", async (c) => {
  try {
    const body = await c.req.json();
    const { username, password, email, grade, parentEmail } = body;

    // Validate required fields
    if (!username || !password || !email || !grade) {
      return c.json({ error: "Missing required fields" }, 400);
    }

    // Check if user already exists
    const existingUser = await kv.get(`user:${username}`);
    if (existingUser) {
      return c.json({ error: "Username already exists" }, 409);
    }

    // Check if email already exists
    const existingEmail = await kv.get(`email:${email}`);
    if (existingEmail) {
      return c.json({ error: "Email already registered" }, 409);
    }

    // Hash password
    const hashedPassword = hashPassword(password);

    // Create user data
    const userData = {
      username,
      password: hashedPassword,
      email,
      grade: parseInt(grade),
      parentEmail: parentEmail || "",
      createdAt: new Date().toISOString(),
      progress: {
        math: { levels: Array(20).fill(null).map((_, i) => ({ 
          id: i + 1, 
          completed: false, 
          stars: 0, 
          unlocked: i === 0 
        })) },
        english: { levels: Array(20).fill(null).map((_, i) => ({ 
          id: i + 1, 
          completed: false, 
          stars: 0, 
          unlocked: i === 0 
        })) },
        ukrainian: { levels: Array(20).fill(null).map((_, i) => ({ 
          id: i + 1, 
          completed: false, 
          stars: 0, 
          unlocked: i === 0 
        })) }
      },
      points: 0,
      streak: 0,
      lastLoginDate: null,
      selectedAvatar: "🐻",
      customization: {
        hat: null,
        accessory: null,
        background: null
      },
      inventory: {
        hats: [],
        accessories: [],
        backgrounds: []
      },
      badges: []
    };

    // Save user data
    await kv.set(`user:${username}`, userData);
    await kv.set(`email:${email}`, username); // Map email to username

    // Generate session token
    const token = generateToken();
    const sessionData = {
      username,
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString() // 7 days
    };
    await kv.set(`session:${token}`, sessionData);

    console.log(`New user registered: ${username}`);

    return c.json({ 
      success: true, 
      message: "User registered successfully",
      token,
      user: {
        username: userData.username,
        email: userData.email,
        grade: userData.grade,
        selectedAvatar: userData.selectedAvatar
      }
    });

  } catch (error) {
    console.error("Error in register endpoint:", error);
    return c.json({ error: "Internal server error", details: error.message }, 500);
  }
});

// Login endpoint
app.post("/make-server-51051136/login", async (c) => {
  try {
    const body = await c.req.json();
    const { username, password } = body;

    // Validate required fields
    if (!username || !password) {
      return c.json({ error: "Missing username or password" }, 400);
    }

    // Get user data
    const userData = await kv.get(`user:${username}`);
    if (!userData) {
      return c.json({ error: "Invalid username or password" }, 401);
    }

    // Verify password
    const hashedPassword = hashPassword(password);
    if (userData.password !== hashedPassword) {
      return c.json({ error: "Invalid username or password" }, 401);
    }

    // Update last login date
    userData.lastLoginDate = new Date().toISOString();
    await kv.set(`user:${username}`, userData);

    // Generate session token
    const token = generateToken();
    const sessionData = {
      username,
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString() // 7 days
    };
    await kv.set(`session:${token}`, sessionData);

    console.log(`User logged in: ${username}`);

    // Return user data without sensitive info
    const { password: _, ...safeUserData } = userData;

    return c.json({ 
      success: true,
      token,
      user: safeUserData
    });

  } catch (error) {
    console.error("Error in login endpoint:", error);
    return c.json({ error: "Internal server error", details: error.message }, 500);
  }
});

// Verify session endpoint
app.get("/make-server-51051136/verify-session", async (c) => {
  try {
    const authHeader = c.req.header("Authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return c.json({ error: "Missing or invalid authorization header" }, 401);
    }

    const token = authHeader.substring(7);
    const sessionData = await kv.get(`session:${token}`);

    if (!sessionData) {
      return c.json({ error: "Invalid session" }, 401);
    }

    // Check if session expired
    if (new Date(sessionData.expiresAt) < new Date()) {
      await kv.del(`session:${token}`);
      return c.json({ error: "Session expired" }, 401);
    }

    // Get user data
    const userData = await kv.get(`user:${sessionData.username}`);
    if (!userData) {
      return c.json({ error: "User not found" }, 404);
    }

    // Return user data without sensitive info
    const { password: _, ...safeUserData } = userData;

    return c.json({ 
      success: true,
      user: safeUserData
    });

  } catch (error) {
    console.error("Error in verify-session endpoint:", error);
    return c.json({ error: "Internal server error", details: error.message }, 500);
  }
});

// Update user progress endpoint
app.post("/make-server-51051136/update-progress", async (c) => {
  try {
    const authHeader = c.req.header("Authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return c.json({ error: "Missing or invalid authorization header" }, 401);
    }

    const token = authHeader.substring(7);
    const sessionData = await kv.get(`session:${token}`);

    if (!sessionData || new Date(sessionData.expiresAt) < new Date()) {
      return c.json({ error: "Invalid or expired session" }, 401);
    }

    const body = await c.req.json();
    const { progress, points, streak, selectedAvatar, customization, inventory, badges } = body;

    // Get user data
    const userData = await kv.get(`user:${sessionData.username}`);
    if (!userData) {
      return c.json({ error: "User not found" }, 404);
    }

    // Update user data
    if (progress) userData.progress = progress;
    if (points !== undefined) userData.points = points;
    if (streak !== undefined) userData.streak = streak;
    if (selectedAvatar) userData.selectedAvatar = selectedAvatar;
    if (customization) userData.customization = customization;
    if (inventory) userData.inventory = inventory;
    if (badges) userData.badges = badges;

    await kv.set(`user:${sessionData.username}`, userData);

    console.log(`Progress updated for user: ${sessionData.username}`);

    return c.json({ 
      success: true,
      message: "Progress updated successfully"
    });

  } catch (error) {
    console.error("Error in update-progress endpoint:", error);
    return c.json({ error: "Internal server error", details: error.message }, 500);
  }
});

// Logout endpoint
app.post("/make-server-51051136/logout", async (c) => {
  try {
    const authHeader = c.req.header("Authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return c.json({ error: "Missing or invalid authorization header" }, 401);
    }

    const token = authHeader.substring(7);
    await kv.del(`session:${token}`);

    return c.json({ 
      success: true,
      message: "Logged out successfully"
    });

  } catch (error) {
    console.error("Error in logout endpoint:", error);
    return c.json({ error: "Internal server error", details: error.message }, 500);
  }
});

// Password reset - request code
app.post("/make-server-51051136/request-password-reset", async (c) => {
  try {
    const body = await c.req.json();
    const { email } = body;

    if (!email) {
      return c.json({ error: "Email is required" }, 400);
    }

    // Get username from email
    const username = await kv.get(`email:${email}`);
    if (!username) {
      // Don't reveal if email exists
      return c.json({ success: true, message: "If email exists, reset code has been sent" });
    }

    // Generate reset code
    const code = Math.floor(100000 + Math.random() * 900000).toString();
    
    // Store reset code with expiration (10 minutes)
    const resetData = {
      code,
      email,
      username,
      expiresAt: new Date(Date.now() + 10 * 60 * 1000).toISOString()
    };
    await kv.set(`reset:${email}`, resetData);

    console.log(`Password reset requested for: ${email}, code: ${code}`);

    return c.json({ 
      success: true,
      message: "Reset code generated",
      code // In production, this would be sent via email only
    });

  } catch (error) {
    console.error("Error in request-password-reset:", error);
    return c.json({ error: "Internal server error", details: error.message }, 500);
  }
});

// Password reset - verify code and update password
app.post("/make-server-51051136/reset-password", async (c) => {
  try {
    const body = await c.req.json();
    const { email, code, newPassword } = body;

    if (!email || !code || !newPassword) {
      return c.json({ error: "Missing required fields" }, 400);
    }

    // Get reset data
    const resetData = await kv.get(`reset:${email}`);
    if (!resetData) {
      return c.json({ error: "Invalid or expired reset code" }, 400);
    }

    // Check expiration
    if (new Date(resetData.expiresAt) < new Date()) {
      await kv.del(`reset:${email}`);
      return c.json({ error: "Reset code expired" }, 400);
    }

    // Verify code
    if (resetData.code !== code) {
      return c.json({ error: "Invalid reset code" }, 400);
    }

    // Update password
    const userData = await kv.get(`user:${resetData.username}`);
    if (!userData) {
      return c.json({ error: "User not found" }, 404);
    }

    userData.password = hashPassword(newPassword);
    await kv.set(`user:${resetData.username}`, userData);

    // Clean up reset data
    await kv.del(`reset:${email}`);

    console.log(`Password reset successfully for: ${resetData.username}`);

    return c.json({ 
      success: true,
      message: "Password reset successfully"
    });

  } catch (error) {
    console.error("Error in reset-password:", error);
    return c.json({ error: "Internal server error", details: error.message }, 500);
  }
});

// Send progress report endpoint
app.post("/make-server-51051136/send-report", async (c) => {
  try {
    const authHeader = c.req.header("Authorization");
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return c.json({ error: "Unauthorized" }, 401);
    }

    const token = authHeader.substring(7);
    const sessionData = await kv.get(`session:${token}`);
    if (!sessionData || new Date(sessionData.expiresAt) < new Date()) {
      return c.json({ error: "Invalid or expired session" }, 401);
    }

    const body = await c.req.json();
    const { parentEmail, language = 'uk' } = body;

    if (!parentEmail) {
      return c.json({ error: "Parent email is required" }, 400);
    }

    // Get user data
    const userData = await kv.get(`user:${sessionData.username}`);
    if (!userData) {
      return c.json({ error: "User not found" }, 404);
    }

    const { username, progress, points, streak, grade, badges } = userData;

    // Calculate stats
    const mathStars = progress.math.levels.reduce((sum: number, level: any) => sum + level.stars, 0);
    const englishStars = progress.english.levels.reduce((sum: number, level: any) => sum + level.stars, 0);
    const ukrainianStars = progress.ukrainian.levels.reduce((sum: number, level: any) => sum + level.stars, 0);
    const totalStars = mathStars + englishStars + ukrainianStars;
    const maxStars = (progress.math.levels.length + progress.english.levels.length + progress.ukrainian.levels.length) * 3;
    const overallGrade = Math.round((totalStars / maxStars) * 12);

    const earnedBadges = badges.filter((b: any) => b.earned);

    // Translations
    const translations = {
      en: {
        reportTitle: '📊 Weekly Progress Report',
        student: 'Student',
        grade: 'Grade',
        reportDate: 'Report Date',
        overallPerformance: '📈 Overall Performance',
        gradeLabel: 'Grade',
        basedOn: 'Based on',
        starsEarned: 'stars earned out of',
        possible: 'possible',
        starsBySubject: '⭐ Stars by Subject',
        math: '🔢 Math',
        english: '📖 English',
        ukrainian: '🇺🇦 Ukrainian',
        stars: 'stars',
        engagementMetrics: '🔥 Engagement Metrics',
        currentStreak: 'Current Streak',
        days: 'days',
        totalPoints: 'Total Points',
        achievementsBadges: '🏆 Achievements & Badges',
        childEarned: 'Your child has earned',
        badges: 'badge(s)',
        teachersNote: "💡 Teacher's Note",
        makingProgress: 'is making',
        excellent: 'excellent',
        good: 'good',
        steady: 'steady',
        progress: 'progress!',
        outstanding: 'Outstanding performance! Keep up the great work!',
        goodEffort: 'Good effort! Consistent practice will lead to mastery.',
        encouragePractice: 'Encourage daily practice to improve skills and confidence.',
        recommendation: 'Recommendation',
        maintainStreak: 'Try to maintain a daily learning streak for better retention.',
        continueHabits: 'Continue the excellent learning habits!',
        automatedReport: 'This is an automated weekly progress report',
        platformName: 'Elementary Learning Platform',
        keepEncouraging: "Keep encouraging your child's learning journey!"
      },
      uk: {
        reportTitle: '📊 Тижневий звіт про успішність',
        student: 'Учень/Учениця',
        grade: 'Клас',
        reportDate: 'Дата звіту',
        overallPerformance: '📈 Загальна успішність',
        gradeLabel: 'Оцінка',
        basedOn: 'На основі',
        starsEarned: 'зірок отримано з',
        possible: 'можливих',
        starsBySubject: '⭐ Зірки за предметами',
        math: '🔢 Математика',
        english: '📖 Англійська',
        ukrainian: '🇺🇦 Українська',
        stars: 'зірок',
        engagementMetrics: '🔥 Метрики залученості',
        currentStreak: 'Поточна серія',
        days: 'днів',
        totalPoints: 'Всього балів',
        achievementsBadges: '🏆 Досягнення та нагороди',
        childEarned: 'Ваша дитина отримала',
        badges: 'нагород(у/и)',
        teachersNote: '💡 Нотатка вчителя',
        makingProgress: 'робить',
        excellent: 'відмінний',
        good: 'хороший',
        steady: 'стабільний',
        progress: 'прогрес!',
        outstanding: 'Чудова успішність! Так тримати!',
        goodEffort: 'Добрі зусилля! Постійна практика призведе до майстерності.',
        encouragePractice: 'Заохочуйте щоденну практику для покращення навичок та впевненості.',
        recommendation: 'Рекомендація',
        maintainStreak: 'Намагайтеся підтримувати щоденну серію навчання для кращого запам\'ятовування.',
        continueHabits: 'Продовжуйте чудові навчальні звички!',
        automatedReport: 'Це автоматичний тижневий звіт про успішність',
        platformName: 'Навчальна платформа для молодших класів',
        keepEncouraging: 'Продовжуйте заохочувати навчальну подорож вашої дитини!'
      }
    };

    const t = translations[language as keyof typeof translations] || translations.uk;

    // For demo: just return success (email sending code from original remains the same)
    console.log(`Progress report would be sent to ${parentEmail} for user ${username}`);

    return c.json({ 
      success: true, 
      message: "Progress report sent successfully"
    });

  } catch (error) {
    console.error("Error in send-report endpoint:", error);
    return c.json({ error: "Internal server error", details: error.message }, 500);
  }
});

Deno.serve(app.fetch);