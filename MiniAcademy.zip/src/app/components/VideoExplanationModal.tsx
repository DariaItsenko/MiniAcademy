import { X, Video } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface VideoExplanationModalProps {
  title: string;
  videoUrl: string;
  onClose: () => void;
}

export function VideoExplanationModal({ title, videoUrl, onClose }: VideoExplanationModalProps) {
  const { t } = useLanguage();

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-gradient-to-r from-purple-500 to-pink-500 text-white p-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Video size={28} />
            <h2 className="text-2xl font-bold">{title}</h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white hover:bg-opacity-20 rounded-full transition-colors"
          >
            <X size={24} />
          </button>
        </div>
        
        <div className="p-6">
          {/* Video Player */}
          <div className="aspect-video bg-gray-900 rounded-lg overflow-hidden mb-6">
            {videoUrl.includes('youtube.com') || videoUrl.includes('youtu.be') ? (
              <iframe
                className="w-full h-full"
                src={videoUrl}
                title={title}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            ) : (
              <video
                className="w-full h-full"
                controls
                src={videoUrl}
              >
                Your browser does not support the video tag.
              </video>
            )}
          </div>
          
          <div className="bg-purple-50 rounded-lg p-4 mb-4">
            <p className="text-gray-700">
              {t('subjectView.videoExplanation')}
            </p>
          </div>
          
          <button
            onClick={onClose}
            className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white py-3 rounded-lg font-semibold hover:from-purple-600 hover:to-pink-600 transition-all"
          >
            {t('subjectView.close')}
          </button>
        </div>
      </div>
    </div>
  );
}
