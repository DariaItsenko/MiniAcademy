import { useState } from "react";
import { ArrowLeft, Plus, Edit2, Trash2, Video, BookOpen, CheckSquare, ShoppingBag, FileText } from "lucide-react";

interface AdminPanelProps {
  onBack: () => void;
}

interface AvatarItem {
  id: string;
  name: string;
  emoji: string;
  category: 'hair' | 'clothes' | 'accessories' | 'skin';
  cost: number;
}

interface Exercise {
  id: string;
  subject: 'math' | 'english' | 'ukrainian';
  level: number;
  question: string;
  type: 'multiple-choice' | 'input';
  options?: string[];
  correctAnswer: string;
  hint: string;
  explanation: string;
}

export function ComprehensiveAdminPanel({ onBack }: AdminPanelProps) {
  const [activeSection, setActiveSection] = useState<"levels" | "exercises" | "avatarItems" | "videos">("levels");
  const [activeSubject, setActiveSubject] = useState<"math" | "english" | "ukrainian">("math");

  // Avatar Shop Items State
  const [shopItems, setShopItems] = useState<AvatarItem[]>(() => {
    const stored = localStorage.getItem("admin_avatar_shop");
    return stored ? JSON.parse(stored) : [
      { id: 'curly-blonde', name: 'Curly Blonde Hair', emoji: '👱‍♀️', category: 'hair', cost: 50 },
      { id: 'tshirt-blue', name: 'Blue T-Shirt', emoji: '👕', category: 'clothes', cost: 30 },
      { id: 'glasses-round', name: 'Round Glasses', emoji: '👓', category: 'accessories', cost: 40 },
    ];
  });

  const [newItem, setNewItem] = useState({ id: '', name: '', emoji: '', category: 'hair' as const, cost: 0 });

  // Exercise State
  const [exercises, setExercises] = useState<Exercise[]>(() => {
    const stored = localStorage.getItem("admin_exercises");
    return stored ? JSON.parse(stored) : [];
  });

  const [newExercise, setNewExercise] = useState<Exercise>({
    id: '',
    subject: 'math',
    level: 1,
    question: '',
    type: 'multiple-choice',
    options: ['', '', '', ''],
    correctAnswer: '',
    hint: '',
    explanation: ''
  });

  // Levels State
  const [levelData, setLevelData] = useState(() => {
    const stored = localStorage.getItem("admin_level_data");
    return stored ? JSON.parse(stored) : {
      math: [
        { level: 1, title: "Addition & Subtraction", description: "Master basic addition and subtraction with numbers up to 100", totalStars: 3 },
      ],
      english: [
        { level: 1, title: "Alphabet & Phonics", description: "Learn letter sounds and simple word formation", totalStars: 3 },
      ],
      ukrainian: [
        { level: 1, title: "Абетка і звуки", description: "Вивчення української абетки та звуків", totalStars: 3 },
      ],
    };
  });

  const [newLevel, setNewLevel] = useState({ title: "", description: "" });

  // Videos State
  const [videoData, setVideoData] = useState(() => {
    const stored = localStorage.getItem("admin_video_data");
    return stored ? JSON.parse(stored) : {
      math: ["https://www.youtube.com/embed/dQw4w9WgXcQ"],
      english: ["https://www.youtube.com/embed/dQw4w9WgXcQ"],
      ukrainian: ["https://www.youtube.com/embed/dQw4w9WgXcQ"],
    };
  });

  const [newVideoUrl, setNewVideoUrl] = useState("");

  // Save functions
  const saveShopItems = (items: AvatarItem[]) => {
    localStorage.setItem("admin_avatar_shop", JSON.stringify(items));
  };

  const saveExercises = (exs: Exercise[]) => {
    localStorage.setItem("admin_exercises", JSON.stringify(exs));
  };

  const saveLevelData = (levels: any) => {
    localStorage.setItem("admin_level_data", JSON.stringify(levels));
  };

  const saveVideoData = (videos: any) => {
    localStorage.setItem("admin_video_data", JSON.stringify(videos));
  };

  // Avatar Shop Functions
  const handleAddShopItem = () => {
    if (!newItem.id || !newItem.name || !newItem.emoji || newItem.cost <= 0) {
      alert("Please fill in all fields with valid values!");
      return;
    }

    const updated = [...shopItems, { ...newItem }];
    setShopItems(updated);
    saveShopItems(updated);
    setNewItem({ id: '', name: '', emoji: '', category: 'hair', cost: 0 });
    alert("✅ Item added successfully!");
  };

  const handleDeleteShopItem = (id: string) => {
    if (confirm("Delete this item?")) {
      const updated = shopItems.filter(item => item.id !== id);
      setShopItems(updated);
      saveShopItems(updated);
    }
  };

  // Exercise Functions
  const handleAddExercise = () => {
    if (!newExercise.question || !newExercise.correctAnswer || !newExercise.hint) {
      alert("Please fill in required fields!");
      return;
    }

    const exercise = {
      ...newExercise,
      id: `ex-${Date.now()}`,
    };

    const updated = [...exercises, exercise];
    setExercises(updated);
    saveExercises(updated);
    setNewExercise({
      id: '',
      subject: 'math',
      level: 1,
      question: '',
      type: 'multiple-choice',
      options: ['', '', '', ''],
      correctAnswer: '',
      hint: '',
      explanation: ''
    });
    alert("✅ Exercise added successfully!");
  };

  const handleDeleteExercise = (id: string) => {
    if (confirm("Delete this exercise?")) {
      const updated = exercises.filter(ex => ex.id !== id);
      setExercises(updated);
      saveExercises(updated);
    }
  };

  // Level Functions
  const handleAddLevel = () => {
    if (!newLevel.title || !newLevel.description) {
      alert("Please fill in all fields");
      return;
    }

    const updated = { ...levelData };
    updated[activeSubject].push({
      level: updated[activeSubject].length + 1,
      title: newLevel.title,
      description: newLevel.description,
      totalStars: 3,
    });
    setLevelData(updated);
    saveLevelData(updated);
    setNewLevel({ title: "", description: "" });
    alert("✅ Level added successfully!");
  };

  const handleDeleteLevel = (index: number) => {
    if (confirm("Delete this level?")) {
      const updated = { ...levelData };
      updated[activeSubject].splice(index, 1);
      updated[activeSubject] = updated[activeSubject].map((l: any, i: number) => ({
        ...l,
        level: i + 1,
      }));
      setLevelData(updated);
      saveLevelData(updated);
    }
  };

  // Video Functions
  const handleAddVideo = () => {
    if (!newVideoUrl) {
      alert("Please enter a video URL");
      return;
    }

    const updated = { ...videoData };
    updated[activeSubject].push(newVideoUrl);
    setVideoData(updated);
    saveVideoData(updated);
    setNewVideoUrl("");
    alert("✅ Video added successfully!");
  };

  const handleDeleteVideo = (index: number) => {
    if (confirm("Delete this video?")) {
      const updated = { ...videoData };
      updated[activeSubject].splice(index, 1);
      setVideoData(updated);
      saveVideoData(updated);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-300 via-red-300 to-pink-400 p-8">
      <button
        onClick={onBack}
        className="mb-6 flex items-center gap-2 bg-white px-6 py-3 rounded-full shadow-lg hover:shadow-xl transition-all font-bold transform hover:scale-105 border-4 border-orange-400"
      >
        <ArrowLeft size={24} />
        Back to Home
      </button>

      <div className="bg-white rounded-3xl shadow-2xl p-8 max-w-7xl mx-auto border-8 border-yellow-400">
        <div className="flex items-center gap-4 mb-8">
          <div className="text-7xl">👨‍💼</div>
          <div>
            <h1 className="text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600">
              Admin Control Panel
            </h1>
            <p className="text-xl text-gray-600 font-medium">Manage all content, exercises, and shop items</p>
          </div>
        </div>

        {/* Section Tabs */}
        <div className="grid grid-cols-4 gap-4 mb-8">
          <button
            onClick={() => setActiveSection("levels")}
            className={`py-6 px-6 rounded-2xl font-bold text-lg transition-all transform hover:scale-105 ${
              activeSection === "levels"
                ? "bg-gradient-to-r from-blue-500 to-purple-500 text-white shadow-xl scale-105"
                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            }`}
          >
            <BookOpen className="mx-auto mb-2" size={32} />
            Levels
          </button>
          <button
            onClick={() => setActiveSection("exercises")}
            className={`py-6 px-6 rounded-2xl font-bold text-lg transition-all transform hover:scale-105 ${
              activeSection === "exercises"
                ? "bg-gradient-to-r from-green-500 to-teal-500 text-white shadow-xl scale-105"
                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            }`}
          >
            <CheckSquare className="mx-auto mb-2" size={32} />
            Exercises
          </button>
          <button
            onClick={() => setActiveSection("avatarItems")}
            className={`py-6 px-6 rounded-2xl font-bold text-lg transition-all transform hover:scale-105 ${
              activeSection === "avatarItems"
                ? "bg-gradient-to-r from-pink-500 to-red-500 text-white shadow-xl scale-105"
                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            }`}
          >
            <ShoppingBag className="mx-auto mb-2" size={32} />
            Shop Items
          </button>
          <button
            onClick={() => setActiveSection("videos")}
            className={`py-6 px-6 rounded-2xl font-bold text-lg transition-all transform hover:scale-105 ${
              activeSection === "videos"
                ? "bg-gradient-to-r from-orange-500 to-yellow-500 text-white shadow-xl scale-105"
                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            }`}
          >
            <Video className="mx-auto mb-2" size={32} />
            Videos
          </button>
        </div>

        {/* Subject Tabs (for levels, exercises, videos) */}
        {(activeSection === "levels" || activeSection === "exercises" || activeSection === "videos") && (
          <div className="flex gap-4 mb-8">
            <button
              onClick={() => setActiveSubject("math")}
              className={`flex-1 py-4 px-6 rounded-2xl font-bold text-lg transition-all ${
                activeSubject === "math"
                  ? "bg-gradient-to-r from-blue-500 to-blue-700 text-white shadow-lg"
                  : "bg-gray-100 text-gray-700"
              }`}
            >
              🔢 Math
            </button>
            <button
              onClick={() => setActiveSubject("english")}
              className={`flex-1 py-4 px-6 rounded-2xl font-bold text-lg transition-all ${
                activeSubject === "english"
                  ? "bg-gradient-to-r from-green-500 to-green-700 text-white shadow-lg"
                  : "bg-gray-100 text-gray-700"
              }`}
            >
              📚 English
            </button>
            <button
              onClick={() => setActiveSubject("ukrainian")}
              className={`flex-1 py-4 px-6 rounded-2xl font-bold text-lg transition-all ${
                activeSubject === "ukrainian"
                  ? "bg-gradient-to-r from-yellow-500 to-orange-600 text-white shadow-lg"
                  : "bg-gray-100 text-gray-700"
              }`}
            >
              🇺🇦 Ukrainian
            </button>
          </div>
        )}

        {/* LEVELS SECTION */}
        {activeSection === "levels" && (
          <div>
            <h2 className="text-3xl font-bold text-gray-800 mb-6">📚 Manage Levels</h2>
            
            <div className="space-y-4 mb-6">
              {levelData[activeSubject].map((level: any, index: number) => (
                <div
                  key={index}
                  className="bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-2xl shadow-md border-4 border-blue-200"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="bg-blue-500 text-white px-4 py-1 rounded-full font-bold text-sm mr-3">
                        Level {level.level}
                      </span>
                      <h3 className="text-xl font-bold text-gray-800 inline">{level.title}</h3>
                      <p className="text-gray-600 mt-2">{level.description}</p>
                    </div>
                    <button
                      onClick={() => handleDeleteLevel(index)}
                      className="p-3 bg-red-500 text-white rounded-xl hover:bg-red-600"
                    >
                      <Trash2 size={20} />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Add New Level */}
            <div className="bg-gradient-to-r from-green-50 to-blue-50 p-6 rounded-2xl border-4 border-green-300">
              <h3 className="text-xl font-bold text-gray-800 mb-4">➕ Add New Level</h3>
              <div className="space-y-4">
                <input
                  type="text"
                  placeholder="Level title..."
                  value={newLevel.title}
                  onChange={(e) => setNewLevel({ ...newLevel, title: e.target.value })}
                  className="w-full p-4 border-4 border-purple-300 rounded-xl focus:border-purple-500 focus:outline-none text-lg"
                />
                <textarea
                  placeholder="Level description..."
                  value={newLevel.description}
                  onChange={(e) => setNewLevel({ ...newLevel, description: e.target.value })}
                  className="w-full p-4 border-4 border-purple-300 rounded-xl focus:border-purple-500 focus:outline-none text-lg"
                  rows={3}
                />
                <button
                  onClick={handleAddLevel}
                  className="bg-gradient-to-r from-green-500 to-blue-500 text-white px-8 py-4 rounded-xl font-bold text-lg shadow-lg hover:shadow-xl transform hover:scale-105"
                >
                  ➕ Add Level
                </button>
              </div>
            </div>
          </div>
        )}

        {/* EXERCISES SECTION */}
        {activeSection === "exercises" && (
          <div>
            <h2 className="text-3xl font-bold text-gray-800 mb-6">✏️ Manage Exercises</h2>
            
            <div className="space-y-4 mb-6">
              {exercises
                .filter(ex => ex.subject === activeSubject)
                .map((exercise) => (
                  <div
                    key={exercise.id}
                    className="bg-gradient-to-r from-green-50 to-teal-50 p-6 rounded-2xl shadow-md border-4 border-green-200"
                  >
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <span className="bg-green-500 text-white px-4 py-1 rounded-full font-bold text-sm mr-3">
                          Level {exercise.level}
                        </span>
                        <span className="bg-purple-500 text-white px-4 py-1 rounded-full font-bold text-sm">
                          {exercise.type}
                        </span>
                        <p className="text-xl font-bold text-gray-800 mt-3">{exercise.question}</p>
                        <p className="text-gray-600 mt-2">✅ Answer: {exercise.correctAnswer}</p>
                        <p className="text-gray-600">💡 Hint: {exercise.hint}</p>
                      </div>
                      <button
                        onClick={() => handleDeleteExercise(exercise.id)}
                        className="p-3 bg-red-500 text-white rounded-xl hover:bg-red-600"
                      >
                        <Trash2 size={20} />
                      </button>
                    </div>
                  </div>
                ))}
            </div>

            {/* Add New Exercise */}
            <div className="bg-gradient-to-r from-yellow-50 to-orange-50 p-6 rounded-2xl border-4 border-yellow-300">
              <h3 className="text-xl font-bold text-gray-800 mb-4">➕ Create New Exercise</h3>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block font-bold text-gray-700 mb-2">Level</label>
                    <input
                      type="number"
                      min="1"
                      value={newExercise.level}
                      onChange={(e) => setNewExercise({ ...newExercise, level: parseInt(e.target.value) })}
                      className="w-full p-4 border-4 border-purple-300 rounded-xl focus:border-purple-500 focus:outline-none text-lg"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-gray-700 mb-2">Type</label>
                    <select
                      value={newExercise.type}
                      onChange={(e) => setNewExercise({ ...newExercise, type: e.target.value as 'multiple-choice' | 'input' })}
                      className="w-full p-4 border-4 border-purple-300 rounded-xl focus:border-purple-500 focus:outline-none text-lg"
                    >
                      <option value="multiple-choice">Multiple Choice</option>
                      <option value="input">Text Input</option>
                    </select>
                  </div>
                </div>
                
                <div>
                  <label className="block font-bold text-gray-700 mb-2">Question</label>
                  <textarea
                    placeholder="Enter the question..."
                    value={newExercise.question}
                    onChange={(e) => setNewExercise({ ...newExercise, question: e.target.value })}
                    className="w-full p-4 border-4 border-purple-300 rounded-xl focus:border-purple-500 focus:outline-none text-lg"
                    rows={2}
                  />
                </div>

                {newExercise.type === 'multiple-choice' && (
                  <div>
                    <label className="block font-bold text-gray-700 mb-2">Options (4 choices)</label>
                    {newExercise.options?.map((opt, i) => (
                      <input
                        key={i}
                        type="text"
                        placeholder={`Option ${i + 1}`}
                        value={opt}
                        onChange={(e) => {
                          const newOpts = [...(newExercise.options || [])];
                          newOpts[i] = e.target.value;
                          setNewExercise({ ...newExercise, options: newOpts });
                        }}
                        className="w-full p-3 border-4 border-blue-300 rounded-xl focus:border-blue-500 focus:outline-none mb-2"
                      />
                    ))}
                  </div>
                )}

                <div>
                  <label className="block font-bold text-gray-700 mb-2">Correct Answer</label>
                  <input
                    type="text"
                    placeholder="Enter the correct answer..."
                    value={newExercise.correctAnswer}
                    onChange={(e) => setNewExercise({ ...newExercise, correctAnswer: e.target.value })}
                    className="w-full p-4 border-4 border-green-300 rounded-xl focus:border-green-500 focus:outline-none text-lg"
                  />
                </div>

                <div>
                  <label className="block font-bold text-gray-700 mb-2">Hint</label>
                  <input
                    type="text"
                    placeholder="Give students a hint..."
                    value={newExercise.hint}
                    onChange={(e) => setNewExercise({ ...newExercise, hint: e.target.value })}
                    className="w-full p-4 border-4 border-yellow-300 rounded-xl focus:border-yellow-500 focus:outline-none text-lg"
                  />
                </div>

                <div>
                  <label className="block font-bold text-gray-700 mb-2">Explanation</label>
                  <textarea
                    placeholder="Explain the answer..."
                    value={newExercise.explanation}
                    onChange={(e) => setNewExercise({ ...newExercise, explanation: e.target.value })}
                    className="w-full p-4 border-4 border-purple-300 rounded-xl focus:border-purple-500 focus:outline-none text-lg"
                    rows={2}
                  />
                </div>

                <button
                  onClick={handleAddExercise}
                  className="w-full bg-gradient-to-r from-green-500 to-blue-500 text-white px-8 py-4 rounded-xl font-bold text-lg shadow-lg hover:shadow-xl transform hover:scale-105"
                >
                  ➕ Create Exercise
                </button>
              </div>
            </div>
          </div>
        )}

        {/* AVATAR SHOP ITEMS SECTION */}
        {activeSection === "avatarItems" && (
          <div>
            <h2 className="text-3xl font-bold text-gray-800 mb-6">🛍️ Manage Shop Items</h2>
            
            <div className="grid grid-cols-2 gap-4 mb-6">
              {shopItems.map((item) => (
                <div
                  key={item.id}
                  className="bg-gradient-to-r from-pink-50 to-purple-50 p-6 rounded-2xl shadow-md border-4 border-pink-200"
                >
                  <div className="flex justify-between items-start">
                    <div className="flex items-center gap-4">
                      <span className="text-5xl">{item.emoji}</span>
                      <div>
                        <h3 className="text-xl font-bold text-gray-800">{item.name}</h3>
                        <p className="text-gray-600">Category: {item.category}</p>
                        <p className="text-green-600 font-bold text-lg">💎 {item.cost} points</p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleDeleteShopItem(item.id)}
                      className="p-3 bg-red-500 text-white rounded-xl hover:bg-red-600"
                    >
                      <Trash2 size={20} />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Add New Item */}
            <div className="bg-gradient-to-r from-blue-50 to-green-50 p-6 rounded-2xl border-4 border-blue-300">
              <h3 className="text-xl font-bold text-gray-800 mb-4">➕ Add New Shop Item</h3>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block font-bold text-gray-700 mb-2">Item ID</label>
                    <input
                      type="text"
                      placeholder="e.g., hat-red"
                      value={newItem.id}
                      onChange={(e) => setNewItem({ ...newItem, id: e.target.value })}
                      className="w-full p-4 border-4 border-purple-300 rounded-xl focus:border-purple-500 focus:outline-none text-lg"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-gray-700 mb-2">Item Name</label>
                    <input
                      type="text"
                      placeholder="e.g., Red Hat"
                      value={newItem.name}
                      onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
                      className="w-full p-4 border-4 border-purple-300 rounded-xl focus:border-purple-500 focus:outline-none text-lg"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <label className="block font-bold text-gray-700 mb-2">Emoji</label>
                    <input
                      type="text"
                      placeholder="🎩"
                      value={newItem.emoji}
                      onChange={(e) => setNewItem({ ...newItem, emoji: e.target.value })}
                      className="w-full p-4 border-4 border-purple-300 rounded-xl focus:border-purple-500 focus:outline-none text-3xl text-center"
                    />
                  </div>
                  <div>
                    <label className="block font-bold text-gray-700 mb-2">Category</label>
                    <select
                      value={newItem.category}
                      onChange={(e) => setNewItem({ ...newItem, category: e.target.value as any })}
                      className="w-full p-4 border-4 border-purple-300 rounded-xl focus:border-purple-500 focus:outline-none text-lg"
                    >
                      <option value="hair">Hair</option>
                      <option value="clothes">Clothes</option>
                      <option value="accessories">Accessories</option>
                      <option value="skin">Skin</option>
                    </select>
                  </div>
                  <div>
                    <label className="block font-bold text-gray-700 mb-2">Cost (Points)</label>
                    <input
                      type="number"
                      min="0"
                      placeholder="50"
                      value={newItem.cost}
                      onChange={(e) => setNewItem({ ...newItem, cost: parseInt(e.target.value) || 0 })}
                      className="w-full p-4 border-4 border-green-300 rounded-xl focus:border-green-500 focus:outline-none text-lg"
                    />
                  </div>
                </div>

                <button
                  onClick={handleAddShopItem}
                  className="w-full bg-gradient-to-r from-pink-500 to-purple-500 text-white px-8 py-4 rounded-xl font-bold text-lg shadow-lg hover:shadow-xl transform hover:scale-105"
                >
                  ➕ Add Shop Item
                </button>
              </div>
            </div>
          </div>
        )}

        {/* VIDEOS SECTION */}
        {activeSection === "videos" && (
          <div>
            <h2 className="text-3xl font-bold text-gray-800 mb-6">🎬 Manage Videos</h2>
            
            <div className="space-y-4 mb-6">
              {videoData[activeSubject].map((url: string, index: number) => (
                <div
                  key={index}
                  className="bg-gradient-to-r from-orange-50 to-yellow-50 p-6 rounded-2xl shadow-md border-4 border-orange-200"
                >
                  <div className="flex justify-between items-center">
                    <div className="flex-1">
                      <span className="bg-orange-500 text-white px-4 py-1 rounded-full font-bold text-sm mr-3">
                        Video {index + 1}
                      </span>
                      <p className="text-gray-600 mt-2 font-mono break-all">{url}</p>
                    </div>
                    <button
                      onClick={() => handleDeleteVideo(index)}
                      className="p-3 bg-red-500 text-white rounded-xl hover:bg-red-600 ml-4"
                    >
                      <Trash2 size={20} />
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {/* Add New Video */}
            <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-6 rounded-2xl border-4 border-purple-300">
              <h3 className="text-xl font-bold text-gray-800 mb-4">➕ Add New Video</h3>
              <div className="space-y-4">
                <input
                  type="text"
                  placeholder="YouTube embed URL (e.g., https://www.youtube.com/embed/...)"
                  value={newVideoUrl}
                  onChange={(e) => setNewVideoUrl(e.target.value)}
                  className="w-full p-4 border-4 border-purple-300 rounded-xl focus:border-purple-500 focus:outline-none text-lg"
                />
                <button
                  onClick={handleAddVideo}
                  className="w-full bg-gradient-to-r from-orange-500 to-red-500 text-white px-8 py-4 rounded-xl font-bold text-lg shadow-lg hover:shadow-xl transform hover:scale-105"
                >
                  ➕ Add Video
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
