import { ArrowLeft, Video, Calendar, Clock, Users, BookOpen, CheckCircle } from 'lucide-react';

interface WebinarDetailPageProps {
  webinar: {
    id: number;
    title: string;
    date: string;
    time: string;
    instructor: string;
    participants: number;
    level: string;
  };
  onBack: () => void;
}

export function WebinarDetailPage({ webinar, onBack }: WebinarDetailPageProps) {
  // Different content based on webinar ID
  const getWebinarContent = () => {
    if (webinar.id === 1) {
      return {
        description: "Join us for an engaging session on mastering multiplication! This interactive webinar will help students build confidence with multiplication tables and learn fun tricks to remember them.",
        objectives: [
          "Understand the concept of multiplication as repeated addition",
          "Master multiplication tables from 2 to 12",
          "Learn memory tricks and patterns",
          "Practice with real-world word problems",
          "Develop mental math skills"
        ],
        topics: [
          { title: "Introduction to Multiplication", duration: "10 min" },
          { title: "Tables 2, 5, and 10 - The Easy Ones", duration: "15 min" },
          { title: "Pattern Recognition in Tables", duration: "15 min" },
          { title: "Memory Tricks and Songs", duration: "10 min" },
          { title: "Practice Problems", duration: "10 min" }
        ],
        materials: "Pencil, paper, and a positive attitude! Printable worksheets will be provided.",
        videoPlaceholder: "📹 Live Session Starts on " + webinar.date
      };
    } else if (webinar.id === 4) {
      return {
        description: "Unleash your creativity in this fun writing workshop! Students will learn how to create engaging stories, develop characters, and structure their narratives effectively.",
        objectives: [
          "Learn the elements of a good story",
          "Create interesting characters",
          "Understand story structure (beginning, middle, end)",
          "Use descriptive language",
          "Share and receive feedback on writing"
        ],
        topics: [
          { title: "What Makes a Story Great?", duration: "10 min" },
          { title: "Character Creation Workshop", duration: "15 min" },
          { title: "Story Structure Basics", duration: "10 min" },
          { title: "Writing Time - Create Your Story", duration: "20 min" },
          { title: "Sharing Circle", duration: "5 min" }
        ],
        materials: "Notebook or paper, pencils, colored pens (optional), and imagination!",
        videoPlaceholder: "📹 Live Session Starts on " + webinar.date
      };
    } else if (webinar.id === 7) {
      return {
        description: "Вітаємо на нашому вебінарі з української абетки! Діти вивчать всі літери українського алфавіту, їх звуки та як правильно їх писати.",
        objectives: [
          "Вивчити всі 33 літери української абетки",
          "Розпізнавати звуки кожної літери",
          "Практикувати правильне написання",
          "Вчити прості слова",
          "Співати абетку"
        ],
        topics: [
          { title: "Знайомство з абеткою", duration: "10 хв" },
          { title: "Голосні літери", duration: "15 хв" },
          { title: "Приголосні літери", duration: "15 хв" },
          { title: "Особливі літери (Є, Ї, Ґ)", duration: "10 хв" },
          { title: "Пісня про абетку", duration: "10 хв" }
        ],
        materials: "Зошит, олівці, кольорові ручки",
        videoPlaceholder: "📹 Онлайн заняття починається " + webinar.date
      };
    }
    
    return {
      description: "An engaging webinar designed to help elementary students learn and grow. Join us for interactive lessons, fun activities, and expert instruction.",
      objectives: [
        "Learn fundamental concepts",
        "Practice new skills",
        "Engage with classmates",
        "Ask questions and get answers",
        "Build confidence"
      ],
      topics: [
        { title: "Introduction and Warm-up", duration: "10 min" },
        { title: "Main Lesson", duration: "25 min" },
        { title: "Practice Activities", duration: "15 min" },
        { title: "Q&A Session", duration: "10 min" }
      ],
      materials: "Basic school supplies",
      videoPlaceholder: "📹 Live Session Starts on " + webinar.date
    };
  };

  const content = getWebinarContent();

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-8">
      <div className="max-w-5xl mx-auto">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-700 hover:text-gray-900 mb-8 font-semibold"
        >
          <ArrowLeft size={20} />
          Back to Subject
        </button>

        {/* Header */}
        <div className="bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-2xl p-8 mb-8 shadow-lg">
          <div className="flex items-center gap-3 mb-4">
            <Video size={40} />
            <div>
              <div className="text-sm opacity-90 mb-1">Live Webinar</div>
              <h1 className="text-4xl font-bold">{webinar.title}</h1>
            </div>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
            <div className="flex items-center gap-2">
              <Calendar size={20} />
              <div>
                <div className="text-xs opacity-75">Date</div>
                <div className="font-semibold">{webinar.date}</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Clock size={20} />
              <div>
                <div className="text-xs opacity-75">Time</div>
                <div className="font-semibold">{webinar.time}</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Users size={20} />
              <div>
                <div className="text-xs opacity-75">Students</div>
                <div className="font-semibold">{webinar.participants} enrolled</div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <BookOpen size={20} />
              <div>
                <div className="text-xs opacity-75">Level</div>
                <div className="font-semibold">{webinar.level}</div>
              </div>
            </div>
          </div>
        </div>

        {/* Video Player Placeholder */}
        <div className="bg-gray-900 rounded-xl shadow-lg mb-8 overflow-hidden aspect-video flex items-center justify-center">
          <div className="text-center">
            <Video size={80} className="text-white mx-auto mb-4 opacity-50" />
            <p className="text-white text-2xl font-semibold">{content.videoPlaceholder}</p>
            <p className="text-gray-400 mt-2">{webinar.time}</p>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="md:col-span-2 space-y-6">
            {/* Description */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">About This Webinar</h2>
              <p className="text-gray-700 leading-relaxed">{content.description}</p>
            </div>

            {/* Learning Objectives */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">Learning Objectives</h2>
              <div className="space-y-3">
                {content.objectives.map((objective, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <CheckCircle size={20} className="text-green-500 mt-1 flex-shrink-0" />
                    <p className="text-gray-700">{objective}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Agenda */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">Webinar Agenda</h2>
              <div className="space-y-3">
                {content.topics.map((topic, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="bg-purple-500 text-white font-bold w-8 h-8 flex items-center justify-center rounded-full text-sm">
                        {index + 1}
                      </div>
                      <span className="font-semibold text-gray-800">{topic.title}</span>
                    </div>
                    <span className="text-gray-600 text-sm">{topic.duration}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Instructor */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="text-xl font-bold text-gray-800 mb-4">Instructor</h3>
              <div className="flex items-center gap-3 mb-3">
                <div className="bg-gradient-to-br from-purple-500 to-pink-500 w-16 h-16 rounded-full flex items-center justify-center text-white text-2xl font-bold">
                  {webinar.instructor.charAt(0)}
                </div>
                <div>
                  <div className="font-semibold text-gray-800">{webinar.instructor}</div>
                  <div className="text-sm text-gray-600">Expert Teacher</div>
                </div>
              </div>
            </div>

            {/* Materials Needed */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="text-xl font-bold text-gray-800 mb-4">Materials Needed</h3>
              <p className="text-gray-700">{content.materials}</p>
            </div>

            {/* Join Button */}
            <button className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white py-4 rounded-xl font-bold text-lg hover:from-purple-600 hover:to-pink-600 transition-all shadow-lg hover:shadow-xl">
              Join Webinar
            </button>

            {/* Status */}
            <div className="bg-green-50 border-2 border-green-200 rounded-xl p-4 text-center">
              <div className="text-green-700 font-semibold mb-1">✓ You're Registered</div>
              <div className="text-sm text-green-600">We'll send you a reminder</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
