import { useState } from 'react';
import { ArrowLeft, Lightbulb, Star, Sparkles } from 'lucide-react';
import { Exercise } from '../data/topicDataBilingual';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../contexts/LanguageContext';

interface EnhancedExerciseViewProps {
  exercises: Exercise[];
  subtopicTitle: string;
  onBack: () => void;
  onComplete: (score: number) => void;
}

export function EnhancedExerciseView({
  exercises,
  subtopicTitle,
  onBack,
  onComplete
}: EnhancedExerciseViewProps) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string>('');
  const [showResult, setShowResult] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [score, setScore] = useState(0);
  const [isComplete, setIsComplete] = useState(false);
  const { language, t } = useLanguage();
  
  // For matching exercises
  const [matchingAnswers, setMatchingAnswers] = useState<number[]>([]);
  const [selectedLeftIndex, setSelectedLeftIndex] = useState<number | null>(null);

  const currentExercise = exercises[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / exercises.length) * 100;

  const handleSubmit = () => {
    let correct = false;
    
    if (currentExercise.type === 'matching' && currentExercise.matchingPairs) {
      // Check if all matches are correct
      correct = matchingAnswers.every((ans, idx) => ans === currentExercise.matchingPairs!.correctMatches[idx]);
    } else {
      // Regular question types
      correct = selectedAnswer.toLowerCase().trim() === currentExercise.correctAnswer.toLowerCase().trim();
    }
    
    setIsCorrect(correct);
    setShowResult(true);
    if (correct) {
      setScore(score + 1);
    }
  };

  const handleNext = () => {
    if (currentQuestionIndex < exercises.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setSelectedAnswer('');
      setShowResult(false);
      setShowHint(false);
      setMatchingAnswers([]);
      setSelectedLeftIndex(null);
    } else {
      setIsComplete(true);
      onComplete(score + (isCorrect ? 1 : 0));
    }
  };
  
  const handleMatchingSelection = (leftIdx: number, rightIdx: number) => {
    const newAnswers = [...matchingAnswers];
    newAnswers[leftIdx] = rightIdx;
    setMatchingAnswers(newAnswers);
    setSelectedLeftIndex(null);
  };

  const stars = Math.ceil(((score + (isCorrect ? 1 : 0)) / exercises.length) * 3);

  if (isComplete) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-200 via-pink-200 to-yellow-200 p-8 flex items-center justify-center">
        <motion.div
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: 'spring', duration: 0.8 }}
          className="bg-white rounded-3xl shadow-2xl p-12 border-8 border-yellow-400 max-w-2xl text-center"
        >
          <motion.div
            animate={{ rotate: [0, 10, -10, 10, 0] }}
            transition={{ duration: 0.5, repeat: 3 }}
            className="text-9xl mb-6"
          >
            🎉
          </motion.div>
          
          <h1 className="text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600 mb-6">
            {t('enhancedExercise.amazingWork')}
          </h1>
          
          <p className="text-2xl text-gray-700 mb-8">
            {t('enhancedExercise.youCompleted')} <span className="font-bold text-purple-600">{subtopicTitle}</span>!
          </p>

          <div className="bg-gradient-to-r from-yellow-100 to-orange-100 p-8 rounded-2xl border-4 border-yellow-400 mb-8">
            <p className="text-xl font-bold text-gray-800 mb-4">{t('enhancedExercise.yourScore')}</p>
            <p className="text-6xl font-bold text-purple-600 mb-4">
              {score}/{exercises.length}
            </p>
            <div className="flex justify-center gap-2 text-6xl">
              {[1, 2, 3].map((star) => (
                <motion.span
                  key={star}
                  initial={{ scale: 0 }}
                  animate={{ scale: star <= stars ? 1 : 0.3 }}
                  transition={{ delay: star * 0.2, type: 'spring' }}
                >
                  {star <= stars ? '⭐' : '☆'}
                </motion.span>
              ))}
            </div>
          </div>

          {currentExercise.funFact && (
            <div className="bg-blue-100 p-6 rounded-xl border-4 border-blue-300 mb-8">
              <p className="text-lg font-bold text-blue-700 mb-2">🌟 {t('enhancedExercise.funFact')}</p>
              <p className="text-gray-700">{currentExercise.funFact[language]}</p>
            </div>
          )}

          <button
            onClick={onBack}
            className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-12 py-6 rounded-full font-bold text-2xl shadow-lg hover:shadow-xl transition-all transform hover:scale-105"
          >
            {t('enhancedExercise.continueLearning')} 🚀
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-200 via-purple-200 to-pink-200 p-8 relative overflow-hidden">
      {/* Animated background elements */}
      <motion.div
        animate={{ y: [0, -20, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
        className="absolute top-10 right-10 text-7xl opacity-20"
      >
        ✨
      </motion.div>
      <motion.div
        animate={{ rotate: 360 }}
        transition={{ duration: 10, repeat: Infinity, ease: 'linear' }}
        className="absolute bottom-20 left-20 text-7xl opacity-20"
      >
        ⭐
      </motion.div>

      <div className="max-w-4xl mx-auto relative z-10">
        {/* Header */}
        <button
          onClick={onBack}
          className="flex items-center gap-2 bg-white px-6 py-3 rounded-full shadow-lg hover:shadow-xl transition-all transform hover:scale-105 mb-8 font-bold border-4 border-purple-300"
        >
          <ArrowLeft size={24} />
          {t('enhancedExercise.backToLessons')}
        </button>

        {/* Progress Bar */}
        <div className="bg-white rounded-full p-3 shadow-lg mb-8 border-4 border-purple-300">
          <div className="flex items-center justify-between mb-2 px-4">
            <span className="font-bold text-gray-700">
              {t('enhancedExercise.questionOf')} {currentQuestionIndex + 1} {t('enhancedExercise.of')} {exercises.length}
            </span>
            <span className="font-bold text-purple-600">{Math.round(progress)}%</span>
          </div>
          <div className="bg-gray-200 rounded-full h-6 overflow-hidden border-2 border-gray-300">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              className="h-full bg-gradient-to-r from-green-400 to-blue-500 flex items-center justify-end px-2"
            >
              <span className="text-white font-bold text-sm">🚀</span>
            </motion.div>
          </div>
        </div>

        {/* Question Card */}
        <AnimatePresence mode="wait">
          <motion.div
            key={currentQuestionIndex}
            initial={{ x: 300, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: -300, opacity: 0 }}
            transition={{ type: 'spring', stiffness: 100 }}
            className="bg-white rounded-3xl shadow-2xl p-10 border-8 border-yellow-400 mb-6"
          >
            <div className="flex items-start justify-between mb-8">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-6">
                  <motion.span
                    animate={{ rotate: [0, 10, -10, 0] }}
                    transition={{ duration: 0.5, repeat: Infinity, repeatDelay: 3 }}
                    className="text-6xl"
                  >
                    📝
                  </motion.span>
                  <h2 className="text-3xl font-bold text-gray-800">{t('enhancedExercise.questionTime')}</h2>
                </div>
                <p className="text-2xl text-gray-700 font-medium leading-relaxed">
                  {currentExercise.question[language]}
                </p>
              </div>
            </div>

            {/* Answer Options */}
            <div className="space-y-4 mb-6">
              {currentExercise.type === 'multiple-choice' && currentExercise.options && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {currentExercise.options.map((option, index) => {
                    const letters = ['A', 'B', 'C', 'D'];
                    const isSelected = selectedAnswer === option;
                    const showCorrect = showResult && option === currentExercise.correctAnswer;
                    const showWrong = showResult && isSelected && !isCorrect;

                    return (
                      <motion.button
                        key={option}
                        whileHover={{ scale: showResult ? 1 : 1.05 }}
                        whileTap={{ scale: showResult ? 1 : 0.95 }}
                        onClick={() => !showResult && setSelectedAnswer(option)}
                        disabled={showResult}
                        className={`p-6 rounded-2xl border-4 font-bold text-xl text-left transition-all ${
                          showCorrect
                            ? 'bg-green-100 border-green-500 shadow-lg'
                            : showWrong
                            ? 'bg-red-100 border-red-500'
                            : isSelected
                            ? 'bg-blue-100 border-blue-500 shadow-lg'
                            : 'bg-gray-50 border-gray-300 hover:border-blue-400 hover:bg-blue-50'
                        }`}
                      >
                        <div className="flex items-center gap-4">
                          <span className={`w-12 h-12 rounded-full flex items-center justify-center text-white font-bold ${
                            showCorrect ? 'bg-green-500' : showWrong ? 'bg-red-500' : isSelected ? 'bg-blue-500' : 'bg-gray-400'
                          }`}>
                            {showCorrect ? '✓' : showWrong ? '✗' : letters[index]}
                          </span>
                          <span className="text-gray-800">{option}</span>
                        </div>
                      </motion.button>
                    );
                  })}
                </div>
              )}

              {currentExercise.type === 'input' && (
                <div>
                  <input
                    type="text"
                    value={selectedAnswer}
                    onChange={(e) => !showResult && setSelectedAnswer(e.target.value)}
                    disabled={showResult}
                    placeholder="Type your answer here..."
                    className="w-full px-8 py-6 rounded-2xl border-4 border-purple-300 text-2xl font-bold focus:outline-none focus:border-purple-500 transition-all"
                  />
                </div>
              )}
              
              {currentExercise.type === 'matching' && currentExercise.matchingPairs && (
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gray-100 p-4 rounded-2xl border-4 border-gray-300">
                    <h3 className="text-xl font-bold text-gray-800 mb-4">{t('enhancedExercise.leftColumn')}</h3>
                    {currentExercise.matchingPairs.left.map((item, idx) => (
                      <motion.button
                        key={idx}
                        whileHover={{ scale: showResult ? 1 : selectedLeftIndex === idx ? 1 : 1.05 }}
                        whileTap={{ scale: showResult ? 1 : selectedLeftIndex === idx ? 1 : 0.95 }}
                        onClick={() => !showResult && setSelectedLeftIndex(idx)}
                        disabled={showResult}
                        className={`w-full p-4 mb-3 rounded-2xl border-4 font-bold text-xl text-left transition-all ${
                          selectedLeftIndex === idx ? 'bg-blue-100 border-blue-500 shadow-lg' : 'bg-white border-gray-300 hover:border-blue-400 hover:bg-blue-50'
                        }`}
                      >
                        <div className="flex items-center gap-4">
                          <span className={`w-12 h-12 rounded-full flex items-center justify-center text-white font-bold ${
                            selectedLeftIndex === idx ? 'bg-blue-500' : 'bg-gray-400'
                          }`}>
                            {selectedLeftIndex === idx ? '👆' : idx + 1}
                          </span>
                          <span className="text-gray-800">{item[language]}</span>
                        </div>
                      </motion.button>
                    ))}
                  </div>
                  <div className="bg-gray-100 p-4 rounded-2xl border-4 border-gray-300">
                    <h3 className="text-xl font-bold text-gray-800 mb-4">{t('enhancedExercise.rightColumn')}</h3>
                    {currentExercise.matchingPairs.right.map((item, idx) => {
                      const isMatched = matchingAnswers.some((match, leftIdx) => match === idx);
                      const isCorrect = showResult && currentExercise.matchingPairs!.correctMatches.some((match, leftIdx) => match === idx && matchingAnswers[leftIdx] === idx);
                      const isWrong = showResult && matchingAnswers.some((match, leftIdx) => match === idx && currentExercise.matchingPairs!.correctMatches[leftIdx] !== idx);
                      
                      return (
                        <motion.button
                          key={idx}
                          whileHover={{ scale: showResult ? 1 : 1.05 }}
                          whileTap={{ scale: showResult ? 1 : 0.95 }}
                          onClick={() => selectedLeftIndex !== null && !showResult && handleMatchingSelection(selectedLeftIndex, idx)}
                          disabled={showResult || selectedLeftIndex === null}
                          className={`w-full p-4 mb-3 rounded-2xl border-4 font-bold text-xl text-left transition-all ${
                            isCorrect
                              ? 'bg-green-100 border-green-500 shadow-lg'
                              : isWrong
                              ? 'bg-red-100 border-red-500'
                              : isMatched
                              ? 'bg-blue-100 border-blue-500 shadow-lg'
                              : 'bg-white border-gray-300 hover:border-blue-400 hover:bg-blue-50'
                          }`}
                        >
                          <div className="flex items-center gap-4">
                            <span className={`w-12 h-12 rounded-full flex items-center justify-center text-white font-bold ${
                              isCorrect
                                ? 'bg-green-500'
                                : isWrong
                                ? 'bg-red-500'
                                : isMatched
                                ? 'bg-blue-500'
                                : 'bg-gray-400'
                            }`}>
                              {isCorrect ? '✓' : isWrong ? '✗' : isMatched ? '🔗' : idx + 1}
                            </span>
                            <span className="text-gray-800">{item[language]}</span>
                          </div>
                        </motion.button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* Result Message */}
            <AnimatePresence>
              {showResult && (
                <motion.div
                  initial={{ scale: 0, y: 20 }}
                  animate={{ scale: 1, y: 0 }}
                  exit={{ scale: 0 }}
                  className={`p-6 rounded-2xl border-4 mb-6 ${
                    isCorrect
                      ? 'bg-green-100 border-green-400'
                      : 'bg-orange-100 border-orange-400'
                  }`}
                >
                  <div className="flex items-start gap-4">
                    <span className="text-5xl">{isCorrect ? '🎉' : '📚'}</span>
                    <div>
                      <p className="text-2xl font-bold text-gray-800 mb-2">
                        {isCorrect ? t('enhancedExercise.correct') : t('enhancedExercise.notQuite')}
                      </p>
                      <p className="text-lg text-gray-700">{currentExercise.explanation[language]}</p>
                      {currentExercise.funFact && (
                        <div className="mt-4 p-4 bg-white rounded-lg border-2 border-blue-300">
                          <p className="text-sm font-bold text-blue-700 mb-1">💡 {t('enhancedExercise.funFact')}</p>
                          <p className="text-gray-700">{currentExercise.funFact[language]}</p>
                        </div>
                      )}
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Action Buttons */}
            <div className="flex gap-4">
              {!showResult && (
                <button
                  onClick={handleSubmit}
                  disabled={
                    (currentExercise.type === 'matching' 
                      ? matchingAnswers.length === 0 
                      : !selectedAnswer)
                  }
                  className={`flex-1 py-6 rounded-2xl font-bold text-2xl shadow-lg transition-all transform hover:scale-105 ${
                    (currentExercise.type === 'matching' ? matchingAnswers.length > 0 : selectedAnswer)
                      ? 'bg-gradient-to-r from-green-500 to-blue-500 text-white hover:shadow-xl'
                      : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  }`}
                >
                  ✓ {t('enhancedExercise.checkAnswer')}
                </button>
              )}
              {showResult && (
                <button
                  onClick={handleNext}
                  className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 text-white py-6 rounded-2xl font-bold text-2xl shadow-lg hover:shadow-xl transition-all transform hover:scale-105"
                >
                  {currentQuestionIndex < exercises.length - 1 ? t('enhancedExercise.nextQuestion') + ' →' : '🎯 ' + t('enhancedExercise.finish')}
                </button>
              )}
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Hint Box (Fixed Position) */}
        <motion.div
          initial={{ x: 300, opacity: 0 }}
          animate={{ x: showHint ? 0 : 300, opacity: showHint ? 1 : 0 }}
          className="fixed bottom-8 right-8 bg-yellow-100 p-6 rounded-2xl border-4 border-yellow-400 shadow-2xl max-w-md"
        >
          <div className="flex items-start gap-3">
            <Lightbulb size={32} className="text-yellow-600 flex-shrink-0" />
            <div>
              <p className="font-bold text-lg text-gray-800 mb-2">{t('enhancedExercise.hint')}</p>
              <p className="text-gray-700">{currentExercise.hint[language]}</p>
            </div>
          </div>
        </motion.div>

        {/* Hint Button (Fixed Position) */}
        {!showResult && (
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => setShowHint(!showHint)}
            className={`fixed bottom-8 right-8 w-16 h-16 rounded-full shadow-2xl transition-all ${
              showHint
                ? 'bg-yellow-500 text-white'
                : 'bg-white text-yellow-500 border-4 border-yellow-400'
            }`}
          >
            <Lightbulb size={32} className="mx-auto" />
          </motion.button>
        )}
      </div>
    </div>
  );
}