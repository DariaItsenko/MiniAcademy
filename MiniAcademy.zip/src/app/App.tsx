import { useState, useEffect } from 'react';
import { Calculator, BookOpen, Globe, User, LogOut, Shield, BarChart3 } from 'lucide-react';
import { LanguageProvider, useLanguage } from './contexts/LanguageContext';
import { ThemeProvider, useTheme } from './contexts/ThemeContext';
import { AuthScreen } from './components/AuthScreen';
import { PasswordReset } from './components/PasswordReset';
import { AvatarSelection } from './components/AvatarSelection';
import { AvatarShop } from './components/AvatarShop';
import { ExerciseView } from './components/ExerciseView';
import { SubjectView } from './components/SubjectView';
import { EnhancedAccountPage } from './components/EnhancedAccountPage';
import { WebinarDetailPage } from './components/WebinarDetailPage';
import { EnhancedAdminPanel } from './components/EnhancedAdminPanel';
import { InteractiveExerciseAdmin } from './components/InteractiveExerciseAdmin';
import { TopicGroupView } from './components/TopicGroupView';
import { SubtopicDetailView } from './components/SubtopicDetailView';
import { StatisticsPage } from './components/StatisticsPage';
import { CurriculumView } from './components/student/CurriculumView';
import { LanguageSwitcher } from './components/LanguageSwitcher';
import { MobileMenu } from './components/MobileMenu';
import { bilingualTopicData } from './data/topicDataBilingual';
import { verifySession, updateProgress, logoutUser, getSessionToken } from '/src/utils/api';

type Subject = "math" | "english" | "ukrainian" | null;
type View =
  | "home"
  | "subject"
  | "exercise"
  | "account"
  | "webinar"
  | "admin"
  | "interactive-exercise-admin"
  | "avatar-select"
  | "avatar-shop"
  | "topic-groups"
  | "subtopic-detail"
  | "password-reset"
  | "statistics"
  | "curriculum";

interface UserProgress {
  math: {
    levels: Array<{ completed: boolean; stars: number }>;
  };
  english: {
    levels: Array<{ completed: boolean; stars: number }>;
  };
  ukrainian: {
    levels: Array<{ completed: boolean; stars: number }>;
  };
}

interface UserData {
  password: string;
  grade: number;
  progress: UserProgress;
  avatar: string;
  points: number;
  streak: number;
  lastLoginDate: string;
  tasksCompleted: number;
  coursesCompleted: number;
  ownedItems: string[];
  equippedItems: string[];
  profilePhoto: string | null;
  parentEmail: string | null;
  lastReportSent: string | null;
  email: string;
  age?: number;
  sessionDurationLimit?: number;
  totalTimeSpent?: number;
}

interface Badge {
  id: string;
  name: string;
  nameUk: string;
  emoji: string;
  description: string;
  descriptionUk: string;
  earned: boolean;
}

const videoData = {
  math: [
    "https://www.youtube.com/embed/dQw4w9WgXcQ",
    "https://www.youtube.com/embed/dQw4w9WgXcQ",
    "https://www.youtube.com/embed/dQw4w9WgXcQ",
    "https://www.youtube.com/embed/dQw4w9WgXcQ",
  ],
  english: [
    "https://www.youtube.com/embed/dQw4w9WgXcQ",
    "https://www.youtube.com/embed/dQw4w9WgXcQ",
    "https://www.youtube.com/embed/dQw4w9WgXcQ",
    "https://www.youtube.com/embed/dQw4w9WgXcQ",
  ],
  ukrainian: [
    "https://www.youtube.com/embed/dQw4w9WgXcQ",
    "https://www.youtube.com/embed/dQw4w9WgXcQ",
    "https://www.youtube.com/embed/dQw4w9WgXcQ",
    "https://www.youtube.com/embed/dQw4w9WgXcQ",
  ],
};

const defaultLevelData = {
  math: [
    {
      level: 1,
      title: "Addition & Subtraction",
      description: "Master basic addition and subtraction with numbers up to 100",
      totalStars: 3,
    },
    {
      level: 2,
      title: "Multiplication Tables",
      description: "Learn multiplication tables from 1 to 10",
      totalStars: 3,
    },
    {
      level: 3,
      title: "Division Basics",
      description: "Understand division and solve simple division problems",
      totalStars: 3,
    },
    {
      level: 4,
      title: "Advanced Problem Solving",
      description: "Apply all operations to solve word problems",
      totalStars: 3,
    },
  ],
  english: [
    {
      level: 1,
      title: "Alphabet & Phonics",
      description: "Learn letter sounds and simple word formation",
      totalStars: 3,
    },
    {
      level: 2,
      title: "Reading Simple Sentences",
      description: "Practice reading and understanding basic sentences",
      totalStars: 3,
    },
    {
      level: 3,
      title: "Story Writing",
      description: "Create your own short stories with proper structure",
      totalStars: 3,
    },
    {
      level: 4,
      title: "Advanced Grammar",
      description: "Master punctuation, tenses, and sentence structure",
      totalStars: 3,
    },
  ],
  ukrainian: [
    {
      level: 1,
      title: "Абетка і звуки",
      description: "Вивчення української абетки та звуків",
      totalStars: 3,
    },
    {
      level: 2,
      title: "Прості слова",
      description: "Читання та написання простих українських слів",
      totalStars: 3,
    },
    {
      level: 3,
      title: "Речення",
      description: "Складання та читання простих речень",
      totalStars: 3,
    },
    {
      level: 4,
      title: "Твори і оповідання",
      description: "Написання коротких творів українською мовою",
      totalStars: 3,
    },
  ],
};

const webinarData = {
  math: [
    {
      id: 1,
      title: "Multiplication Mastery",
      date: "January 25, 2026",
      time: "3:00 PM - 4:00 PM",
      instructor: "Ms. Johnson",
      participants: 24,
      level: "Grade 3-4",
    },
    {
      id: 2,
      title: "Fun with Fractions",
      date: "January 28, 2026",
      time: "2:30 PM - 3:30 PM",
      instructor: "Mr. Davis",
      participants: 18,
      level: "Grade 4-5",
    },
  ],
  english: [
    {
      id: 4,
      title: "Creative Writing Workshop",
      date: "January 26, 2026",
      time: "3:30 PM - 4:30 PM",
      instructor: "Mrs. Thompson",
      participants: 30,
      level: "Grade 3-5",
    },
    {
      id: 5,
      title: "Reading Comprehension Skills",
      date: "January 29, 2026",
      time: "2:00 PM - 3:00 PM",
      instructor: "Mr. Wilson",
      participants: 26,
      level: "Grade 2-4",
    },
  ],
  ukrainian: [
    {
      id: 7,
      title: "Українська абетка (Ukrainian Alphabet)",
      date: "January 27, 2026",
      time: "4:00 PM - 5:00 PM",
      instructor: "Пані Коваленко",
      participants: 19,
      level: "Grade 1-2",
    },
    {
      id: 8,
      title: "Читання казок (Reading Fairy Tales)",
      date: "January 30, 2026",
      time: "3:00 PM - 4:00 PM",
      instructor: "Пані Шевченко",
      participants: 25,
      level: "Grade 2-3",
    },
  ],
};

const subjectColors = {
  math: "bg-gradient-to-br from-blue-500 to-blue-700",
  english: "bg-gradient-to-br from-green-500 to-green-700",
  ukrainian: "bg-gradient-to-br from-yellow-500 to-orange-600",
};

interface SubjectCardProps {
  title: string;
  icon: any;
  color: string;
  onClick: () => void;
}

function SubjectCard({ title, icon: Icon, color, onClick }: SubjectCardProps) {
  return (
    <button
      onClick={onClick}
      className={`${color} text-white p-8 rounded-3xl shadow-2xl hover:shadow-3xl transition-all transform hover:scale-105 w-full border-8 border-white`}
    >
      <div className="flex flex-col items-center gap-4">
        <Icon size={64} className="drop-shadow-lg" />
        <h3 className="text-3xl font-bold drop-shadow-md">{title}</h3>
      </div>
    </button>
  );
}

function AppContent({ onGradeChange }: { onGradeChange: (grade: number) => void }) {
  const { t, language } = useLanguage();
  const { currentTheme } = useTheme();
  const [currentUser, setCurrentUser] = useState<string | null>(null);
  const [userData, setUserData] = useState<UserData | null>(null);
  const [currentView, setCurrentView] = useState<View>("home");
  const [selectedSubject, setSelectedSubject] = useState<Subject>(null);
  const [selectedLevel, setSelectedLevel] = useState<number>(0);
  const [selectedWebinar, setSelectedWebinar] = useState<number | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [selectedGroupId, setSelectedGroupId] = useState<string>("");
  const [selectedSubtopicId, setSelectedSubtopicId] = useState<string>("");

  // Calculate badges based on user progress
  const calculateBadges = (user: UserData): Badge[] => {
    return [
      {
        id: "tasks-10",
        name: "Task Master",
        nameUk: "Майстер завдань",
        emoji: "📝",
        description: "Complete 10 tasks",
        descriptionUk: "Виконайте 10 завдань",
        earned: user.tasksCompleted >= 10,
      },
      {
        id: "course-complete",
        name: "Course Hero",
        nameUk: "Герой курсу",
        emoji: "🎓",
        description: "Complete a full course",
        descriptionUk: "Завершіть повний курс",
        earned: user.coursesCompleted >= 1,
      },
      {
        id: "streak-20",
        name: "Dedication",
        nameUk: "Відданість",
        emoji: "🔥",
        description: "20 day login streak",
        descriptionUk: "20-дневний ряд вхідів",
        earned: user.streak >= 20,
      },
      {
        id: "star-collector",
        name: "Star Collector",
        nameUk: "Зібравець зірочок",
        emoji: "⭐",
        description: "Earn 50 stars total",
        descriptionUk: "Здобути 50 зірочок загалом",
        earned: 
          (user.progress.math.levels.reduce((a, l) => a + l.stars, 0) +
          user.progress.english.levels.reduce((a, l) => a + l.stars, 0) +
          user.progress.ukrainian.levels.reduce((a, l) => a + l.stars, 0)) >= 50,
      },
      {
        id: "points-master",
        name: "Points Master",
        nameUk: "Майстер балів",
        emoji: "💎",
        description: "Earn 500 points",
        descriptionUk: "Здобути 500 балів",
        earned: user.points >= 500,
      },
      {
        id: "early-bird",
        name: "Early Bird",
        nameUk: "Ранній птах",
        emoji: "🌅",
        description: "Log in 7 days in a row",
        descriptionUk: "Увійти 7 днів підряд",
        earned: user.streak >= 7,
      },
    ];
  };

  // Update streak on login
  const updateStreak = (user: UserData): UserData => {
    const today = new Date().toDateString();
    const lastLogin = user.lastLoginDate;
    
    if (!lastLogin || lastLogin !== today) {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yesterdayStr = yesterday.toDateString();
      
      if (lastLogin === yesterdayStr) {
        // Consecutive day
        user.streak += 1;
      } else if (lastLogin !== today) {
        // Streak broken
        user.streak = 1;
      }
      user.lastLoginDate = today;
    }
    
    return user;
  };

  useEffect(() => {
    // Check if user is already logged in via session token
    const checkSession = async () => {
      const token = getSessionToken();
      if (!token) {
        return;
      }

      try {
        const result = await verifySession();
        if (result.success && result.user) {
          setCurrentUser(result.user.username);
          setUserData(result.user);
          setIsAdmin(false);
          onGradeChange(result.user.grade);
          localStorage.setItem("elementary_current_user", result.user.username);
          localStorage.setItem("elementary_is_admin", "false");
        }
      } catch (error) {
        console.log('No valid session found');
        // Check for admin
        const loggedInUser = localStorage.getItem("elementary_current_user");
        const isAdminUser = localStorage.getItem("elementary_is_admin") === "true";
        
        if (loggedInUser && isAdminUser) {
          setCurrentUser(loggedInUser);
          setIsAdmin(true);
        }
      }
    };

    checkSession();
  }, []);

  const handleLogin = (username: string, grade: number = 1, userData: any, admin: boolean = false) => {
    console.log('🔐 Logging in user:', username, 'Grade:', grade, 'Admin:', admin);
    setCurrentUser(username);
    setIsAdmin(admin);
    localStorage.setItem("elementary_current_user", username);
    localStorage.setItem("elementary_is_admin", admin ? "true" : "false");
    
    console.log('✅ Login info saved to localStorage');

    if (admin) {
      setCurrentView("admin");
      console.log('👨‍💼 Admin logged in');
      return;
    }

    // Use userData from API
    if (userData) {
      console.log('✅ User found:', username);
      console.log('User data from API:', userData);
      
      // Update streak
      const updatedUser = updateStreak(userData);
      
      setUserData(updatedUser);
      onGradeChange(grade);
      console.log('✅ Login complete!');
      
      // Sync back to server
      updateProgress({
        progress: updatedUser.progress,
        points: updatedUser.points,
        streak: updatedUser.streak
      }).catch(err => console.error('Failed to sync progress:', err));
    } else {
      console.error('❌ User data not provided!');
      alert('⚠️ Error: User account not found. Please try registering again.');
      handleLogout();
    }
  };

  const handleAvatarSelect = (avatar: string) => {
    if (!currentUser) return;
    
    const users = JSON.parse(localStorage.getItem("elementary_users") || "{}");
    if (users[currentUser]) {
      users[currentUser].avatar = avatar;
      localStorage.setItem("elementary_users", JSON.stringify(users));
      setUserData(users[currentUser]);
      setCurrentView("home");
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setUserData(null);
    setIsAdmin(false);
    localStorage.removeItem("elementary_current_user");
    localStorage.removeItem("elementary_is_admin");
    setCurrentView("home");
    setSelectedSubject(null);
  };

  const handleGradeChange = (newGrade: number) => {
    if (!currentUser || !userData) return;
    
    const users = JSON.parse(localStorage.getItem("elementary_users") || "{}");
    if (users[currentUser]) {
      users[currentUser].grade = newGrade;
      localStorage.setItem("elementary_users", JSON.stringify(users));
      setUserData({ ...userData, grade: newGrade });
      onGradeChange(newGrade);
    }
  };

  const handlePurchaseItem = (itemId: string, cost: number) => {
    if (!currentUser || !userData) return;
    
    if (userData.points >= cost && !userData.ownedItems.includes(itemId)) {
      const users = JSON.parse(localStorage.getItem("elementary_users") || "{}");
      if (users[currentUser]) {
        users[currentUser].points -= cost;
        users[currentUser].ownedItems.push(itemId);
        localStorage.setItem("elementary_users", JSON.stringify(users));
        setUserData(users[currentUser]);
      }
    }
  };

  const handleEquipItem = (itemId: string) => {
    if (!currentUser || !userData) return;
    
    const users = JSON.parse(localStorage.getItem("elementary_users") || "{}");
    if (users[currentUser]) {
      const equipped = [...users[currentUser].equippedItems];
      const index = equipped.indexOf(itemId);
      
      if (index > -1) {
        // Unequip
        equipped.splice(index, 1);
      } else {
        // Equip
        equipped.push(itemId);
      }
      
      users[currentUser].equippedItems = equipped;
      localStorage.setItem("elementary_users", JSON.stringify(users));
      setUserData(users[currentUser]);
    }
  };

  const handlePhotoUpload = (photo: string) => {
    if (!currentUser || !userData) return;
    
    const users = JSON.parse(localStorage.getItem("elementary_users") || "{}");
    if (users[currentUser]) {
      users[currentUser].profilePhoto = photo;
      localStorage.setItem("elementary_users", JSON.stringify(users));
      setUserData(users[currentUser]);
    }
  };

  const handleParentEmailUpdate = (email: string) => {
    if (!currentUser || !userData) return;
    
    const users = JSON.parse(localStorage.getItem("elementary_users") || "{}");
    if (users[currentUser]) {
      users[currentUser].parentEmail = email;
      localStorage.setItem("elementary_users", JSON.stringify(users));
      setUserData(users[currentUser]);
    }
  };

  const handleSendProgressReport = async () => {
    if (!currentUser || !userData || !userData.parentEmail) return;

    // Show loading state or toast here later
    try {
      const response = await fetch(`https://akvkqgxbckbygzcfcuoy.supabase.co/functions/v1/make-server-51051136/send-report`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFrdmtxZ3hiY2tieWd6Y2ZjdW95Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDc0NTE0ODAsImV4cCI6MjA2MzAyNzQ4MH0.P_j-5zzv_LlKZ8-Cxu0HLv2VZb-wJ3OxOLGJ_f8L5_4`
        },
        body: JSON.stringify({
          username: currentUser,
          parentEmail: userData.parentEmail,
          progress: userData.progress,
          points: userData.points,
          streak: userData.streak,
          grade: userData.grade,
          badges: calculateBadges(userData),
          language: language // Pass current language to server
        })
      });

      if (response.ok) {
        // Update last report sent date
        const users = JSON.parse(localStorage.getItem("elementary_users") || "{}");
        if (users[currentUser]) {
          users[currentUser].lastReportSent = new Date().toISOString();
          localStorage.setItem("elementary_users", JSON.stringify(users));
          setUserData(users[currentUser]);
        }
        const successMessage = language === 'uk' 
          ? `📧 Звіт про успішність успішно надіслано на ${userData.parentEmail}!`
          : `📧 Progress report sent successfully to ${userData.parentEmail}!`;
        alert(successMessage);
      } else {
        const errorText = await response.text();
        console.error('Error sending report:', errorText);
        const errorMessage = language === 'uk'
          ? '❌ Не вдалося надіслати звіт. Перевірте адресу електронної пошти та спробуйте ще раз.'
          : '❌ Failed to send report. Please check the email address and try again.';
        alert(errorMessage);
      }
    } catch (error) {
      console.error('Error sending report:', error);
      const networkErrorMessage = language === 'uk'
        ? '❌ Помилка мережі. Перевірте підключення та спробуйте ще раз.'
        : '❌ Network error. Please check your connection and try again.';
      alert(networkErrorMessage);
    }
  };

  const saveProgress = (subject: Subject, levelIndex: number, stars: number) => {
    if (!currentUser || !userData || !subject) return;

    const users = JSON.parse(localStorage.getItem("elementary_users") || "{}");
    if (users[currentUser]) {
      const user = users[currentUser];
      
      user.progress[subject].levels[levelIndex] = {
        completed: stars > 0,
        stars,
      };

      // Award points based on stars (30, 20, 10 for 3, 2, 1 stars)
      const pointsAwarded = stars === 3 ? 30 : stars === 2 ? 20 : stars === 1 ? 10 : 0;
      user.points += pointsAwarded;
      user.tasksCompleted += 1;

      // Check if course is completed
      const allLevelsCompleted = user.progress[subject].levels.every(l => l.completed);
      if (allLevelsCompleted) {
        user.coursesCompleted += 1;
      }

      localStorage.setItem("elementary_users", JSON.stringify(users));
      setUserData(user);
    }
  };

  const getLevelsForSubject = (subject: Subject) => {
    if (!subject || !userData) return [];

    // Try to get admin-created levels first
    const adminLevels = localStorage.getItem("admin_level_data");
    const levelData = adminLevels ? JSON.parse(adminLevels)[subject] : defaultLevelData[subject];

    return levelData.map((levelInfo: any, index: number) => {
      const progress = userData.progress[subject].levels[index] || { completed: false, stars: 0 };
      let status: "locked" | "available" | "completed" = "locked";

      if (index === 0) {
        status = progress.completed ? "completed" : "available";
      } else {
        const previousLevel = userData.progress[subject].levels[index - 1];
        if (previousLevel && previousLevel.completed) {
          status = progress.completed ? "completed" : "available";
        }
      }

      return {
        ...levelInfo,
        status,
        stars: progress.stars,
        videoUrl: videoData[subject][index],
      };
    });
  };

  const handleStartLevel = (levelIndex: number) => {
    setSelectedLevel(levelIndex);
    setCurrentView("exercise");
  };

  const handleCompleteExercise = (stars: number) => {
    if (selectedSubject) {
      saveProgress(selectedSubject, selectedLevel, stars);
    }
    setCurrentView("subject");
  };

  const handleViewWebinar = (webinarId: number) => {
    setSelectedWebinar(webinarId);
    setCurrentView("webinar");
  };

  if (currentView === "password-reset") {
    return <PasswordReset onBack={() => setCurrentView("home")} />;
  }

  if (!currentUser) {
    return <AuthScreen onLogin={handleLogin} onForgotPassword={() => setCurrentView("password-reset")} />;
  }

  if (currentView === "avatar-select") {
    return <AvatarSelection onSelect={handleAvatarSelect} />;
  }

  if (currentView === "avatar-shop" && userData) {
    return (
      <AvatarShop
        onBack={() => setCurrentView("account")}
        currentAvatar={userData.avatar}
        ownedItems={userData.ownedItems}
        points={userData.points}
        onPurchase={handlePurchaseItem}
        onEquip={handleEquipItem}
        equippedItems={userData.equippedItems}
      />
    );
  }

  if (currentView === "exercise" && selectedSubject && userData) {
    return (
      <ExerciseView
        subject={selectedSubject}
        level={selectedLevel + 1}
        onBack={() => setCurrentView("subject")}
        onComplete={handleCompleteExercise}
      />
    );
  }

  if (currentView === "subject" && selectedSubject && userData) {
    const levels = getLevelsForSubject(selectedSubject);
    return (
      <SubjectView
        subject={t(`subject.${selectedSubject}`)}
        color={subjectColors[selectedSubject]}
        webinars={webinarData[selectedSubject]}
        levels={levels}
        onBack={() => {
          setCurrentView("home");
          setSelectedSubject(null);
        }}
        onStartLevel={handleStartLevel}
        onWebinarClick={handleViewWebinar}
      />
    );
  }

  if (currentView === "account" && userData) {
    const badges = calculateBadges(userData);
    return (
      <EnhancedAccountPage
        username={currentUser}
        progress={userData.progress}
        grade={userData.grade}
        avatar={userData.avatar}
        points={userData.points}
        streak={userData.streak}
        badges={badges}
        profilePhoto={userData.profilePhoto}
        onBack={() => setCurrentView("home")}
        onGradeChange={handleGradeChange}
        onAvatarShop={() => setCurrentView("avatar-shop")}
        onPhotoUpload={handlePhotoUpload}
        onParentEmailUpdate={handleParentEmailUpdate}
        onSendReport={handleSendProgressReport}
        parentEmail={userData.parentEmail}
        lastReportSent={userData.lastReportSent}
        equippedItems={userData.equippedItems}
        ownedItems={userData.ownedItems}
      />
    );
  }

  if (currentView === "webinar" && selectedWebinar !== null) {
    const allWebinars = [
      ...webinarData.math,
      ...webinarData.english,
      ...webinarData.ukrainian,
    ];
    const webinar = allWebinars.find((w) => w.id === selectedWebinar);
    if (webinar) {
      return (
        <WebinarDetailPage
          webinar={webinar}
          onBack={() => setCurrentView("subject")}
        />
      );
    }
  }

  if (currentView === "admin") {
    return <EnhancedAdminPanel onBack={() => setCurrentView("home")} onLogout={handleLogout} onNavigateToInteractive={() => setCurrentView("interactive-exercise-admin")} />;
  }

  if (currentView === "interactive-exercise-admin") {
    return <InteractiveExerciseAdmin onBack={() => setCurrentView("admin")} />;
  }

  if (currentView === "topic-groups" && selectedSubject) {
    return (
      <TopicGroupView
        subject={selectedSubject}
        topicGroups={bilingualTopicData[selectedSubject]}
        onBack={() => {
          setCurrentView("home");
          setSelectedSubject(null);
        }}
        onSelectSubtopic={(groupId, subtopicId) => {
          setSelectedGroupId(groupId);
          setSelectedSubtopicId(subtopicId);
          setCurrentView("subtopic-detail");
        }}
      />
    );
  }

  if (currentView === "subtopic-detail" && selectedSubject && selectedGroupId && selectedSubtopicId) {
    const group = bilingualTopicData[selectedSubject].find((g) => g.id === selectedGroupId);
    const subtopic = group?.subtopics.find((s) => s.id === selectedSubtopicId);
    
    if (group && subtopic) {
      return (
        <SubtopicDetailView
          subtopic={subtopic}
          groupColor={group.color}
          onBack={() => setCurrentView("topic-groups")}
          onCompleteExercises={(score) => {
            // Award points based on score
            if (!currentUser || !userData) return;
            const users = JSON.parse(localStorage.getItem("elementary_users") || "{}");
            if (users[currentUser]) {
              const pointsAwarded = score * 10;
              users[currentUser].points += pointsAwarded;
              users[currentUser].tasksCompleted += 1;
              localStorage.setItem("elementary_users", JSON.stringify(users));
              setUserData(users[currentUser]);
            }
            setCurrentView("topic-groups");
          }}
        />
      );
    }
  }

  if (currentView === "statistics" && userData) {
    return (
      <StatisticsPage
        username={currentUser || ''}
        progress={userData.progress}
        grade={userData.grade}
        streak={userData.streak}
        points={userData.points}
        onBack={() => setCurrentView("home")}
      />
    );
  }

  if (currentView === "curriculum" && selectedSubject) {
    return (
      <CurriculumView
        subject={selectedSubject}
        onBack={() => {
          setCurrentView("home");
          setSelectedSubject(null);
        }}
        onComplete={(lessonId, score, totalQuestions) => {
          // Award points
          if (!currentUser || !userData) return;
          const users = JSON.parse(localStorage.getItem("elementary_users") || "{}");
          if (users[currentUser]) {
            const pointsAwarded = (score / totalQuestions) * 50; // Up to 50 points per lesson
            users[currentUser].points += Math.round(pointsAwarded);
            users[currentUser].tasksCompleted += 1;
            localStorage.setItem("elementary_users", JSON.stringify(users));
            setUserData(users[currentUser]);
          }
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-200 via-pink-200 to-blue-300 flex flex-col items-center justify-center p-4 md:p-8 relative overflow-hidden">
      {/* Playful background decorations */}
      <div className="absolute top-10 left-10 text-5xl md:text-9xl animate-bounce">🐻</div>
      <div className="absolute top-20 right-10 md:right-20 text-4xl md:text-8xl animate-pulse">🦊</div>
      <div className="absolute bottom-20 left-10 md:left-20 text-5xl md:text-9xl">🌺</div>
      <div className="absolute bottom-10 right-10 text-5xl md:text-9xl animate-bounce" style={{ animationDelay: '0.5s' }}>🐰</div>
      <div className="absolute top-1/2 right-5 md:right-10 text-4xl md:text-7xl">⭐</div>
      <div className="absolute top-1/3 left-5 text-4xl md:text-8xl">🎨</div>
      
      <div className="absolute top-4 right-4 flex items-center gap-2 md:gap-4 z-20">
        {/* Mobile Menu - Shows on small screens */}
        {!isAdmin && userData && (
          <div className="md:hidden">
            <MobileMenu
              username={currentUser}
              onAccountClick={() => setCurrentView("account")}
              onStatisticsClick={() => setCurrentView("statistics")}
              onLogout={handleLogout}
            />
          </div>
        )}
        
        {/* Desktop Navigation - Hidden on mobile */}
        <div className="hidden md:flex items-center gap-4">
          <LanguageSwitcher />
          {!isAdmin && userData && (
            <>
              <button
                onClick={() => setCurrentView("statistics")}
                className="flex items-center gap-2 bg-white px-6 py-3 rounded-full shadow-lg hover:shadow-xl transition-all transform hover:scale-105 border-4 border-indigo-400"
              >
                <BarChart3 size={24} className="text-indigo-600" />
                <span className="font-bold text-gray-800 text-lg">
                  {language === 'uk' ? 'Статистика' : 'Statistics'}
                </span>
              </button>
              <button
                onClick={() => setCurrentView("account")}
                className="flex items-center gap-2 bg-white px-6 py-3 rounded-full shadow-lg hover:shadow-xl transition-all transform hover:scale-105 border-4 border-purple-400"
              >
                <User size={24} className="text-purple-600" />
                <span className="font-bold text-gray-800 text-lg">
                  {currentUser}
                </span>
              </button>
              <button
                onClick={handleLogout}
                className="flex items-center gap-2 bg-gradient-to-r from-red-400 to-pink-500 text-white px-6 py-3 rounded-full shadow-lg hover:shadow-xl transition-all transform hover:scale-105 font-bold"
              >
                <LogOut size={24} />
                {t("home.logout")}
              </button>
            </>
          )}
        </div>
        
        {/* Admin button always visible */}
        {isAdmin && (
          <button
            onClick={() => setCurrentView("admin")}
            className="flex items-center gap-1 md:gap-2 bg-gradient-to-r from-orange-500 to-red-600 text-white px-3 md:px-6 py-2 md:py-3 rounded-full shadow-lg hover:shadow-xl transition-all transform hover:scale-105 font-bold text-sm md:text-base"
          >
            <Shield size={20} className="md:w-6 md:h-6" />
            <span className="hidden md:inline">Admin Panel</span>
            <span className="md:hidden">Admin</span>
          </button>
        )}
      </div>

      <div className="text-center mb-8 md:mb-12 relative z-10 px-4">
        <div className="flex flex-col md:flex-row items-center justify-center gap-2 md:gap-4 mb-4 md:mb-6">
          <span className="text-5xl md:text-8xl animate-bounce">🎓</span>
          <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-7xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 via-pink-600 to-blue-600 leading-tight">
            {t("home.title")}
          </h1>
          <span className="text-5xl md:text-8xl animate-bounce" style={{ animationDelay: '0.3s' }}>📚</span>
        </div>
        <p className="text-base sm:text-lg md:text-xl lg:text-2xl text-gray-700 font-semibold px-2">
          {t("home.subtitle")}
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 md:gap-10 max-w-6xl w-full relative z-10 px-4">
        <div className="transform hover:scale-110 transition-all duration-300">
          <div className="text-center mb-4 text-4xl md:text-6xl animate-pulse">🔢</div>
          <SubjectCard
            title={t("subject.math")}
            icon={Calculator}
            color="bg-gradient-to-br from-blue-400 to-blue-600"
            onClick={() => {
              setSelectedSubject("math");
              setCurrentView("topic-groups");
            }}
          />
        </div>
        <div className="transform hover:scale-110 transition-all duration-300">
          <div className="text-center mb-4 text-4xl md:text-6xl animate-pulse" style={{ animationDelay: '0.2s' }}>📖</div>
          <SubjectCard
            title={t("subject.english")}
            icon={BookOpen}
            color="bg-gradient-to-br from-green-400 to-green-600"
            onClick={() => {
              setSelectedSubject("english");
              setCurrentView("topic-groups");
            }}
          />
        </div>
        <div className="transform hover:scale-110 transition-all duration-300 sm:col-span-2 md:col-span-1">
          <div className="text-center mb-4 text-4xl md:text-6xl animate-pulse" style={{ animationDelay: '0.4s' }}>🇺🇦</div>
          <SubjectCard
            title={t("subject.ukrainian")}
            icon={Globe}
            color="bg-gradient-to-br from-yellow-400 to-orange-600"
            onClick={() => {
              setSelectedSubject("ukrainian");
              setCurrentView("topic-groups");
            }}
          />
        </div>
      </div>

      <div className="mt-8 md:mt-16 text-center text-gray-700 relative z-10 px-4">
        <p className="text-sm sm:text-base md:text-lg lg:text-xl font-semibold">{t("home.tagline")}</p>
      </div>
    </div>
  );
}

export default function App() {
  // Get current user's grade to apply theme
  const [userGrade, setUserGrade] = useState<number>(1);

  useEffect(() => {
    const loggedInUser = localStorage.getItem("elementary_current_user");
    const isAdminUser = localStorage.getItem("elementary_is_admin") === "true";
    
    if (loggedInUser && !isAdminUser) {
      const users = JSON.parse(localStorage.getItem("elementary_users") || "{}");
      if (users[loggedInUser] && users[loggedInUser].grade) {
        setUserGrade(users[loggedInUser].grade);
      }
    }
  }, []);

  return (
    <LanguageProvider>
      <ThemeProvider grade={userGrade}>
        <AppContent onGradeChange={setUserGrade} />
      </ThemeProvider>
    </LanguageProvider>
  );
}