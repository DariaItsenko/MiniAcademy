import { useState, useRef } from 'react';
import { useLanguage } from '../../contexts/LanguageContext';
import { Trophy, RefreshCw } from 'lucide-react';

interface MatchPair {
  id: string;
  left: string;
  right: string;
  leftEmoji: string;
  rightEmoji: string;
}

interface Connection {
  leftId: string;
  rightId: string;
}

interface ColumnMatchingProps {
  onComplete: (score: number) => void;
  subject: 'math' | 'english' | 'ukrainian';
}

export function ColumnMatching({ onComplete, subject }: ColumnMatchingProps) {
  const { language } = useLanguage();
  const svgRef = useRef<SVGSVGElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const exerciseData = {
    math: {
      title: language === 'uk' ? 'З\'єднай приклади з відповідями' : 'Match Problems with Answers',
      pairs: [
        { id: '1', left: '5 + 3', right: '8', leftEmoji: '➕', rightEmoji: '8️⃣' },
        { id: '2', left: '10 - 4', right: '6', leftEmoji: '➖', rightEmoji: '6️⃣' },
        { id: '3', left: '3 × 2', right: '6', leftEmoji: '✖️', rightEmoji: '6️⃣' },
        { id: '4', left: '12 ÷ 3', right: '4', leftEmoji: '➗', rightEmoji: '4️⃣' },
        { id: '5', left: '7 + 2', right: '9', leftEmoji: '➕', rightEmoji: '9️⃣' },
      ],
    },
    english: {
      title: language === 'uk' ? 'З\'єднай слова з перекладами' : 'Match Words with Meanings',
      pairs: [
        { id: '1', left: 'Cat', right: language === 'uk' ? 'Кіт' : 'Feline pet', leftEmoji: '🐱', rightEmoji: '🐈' },
        { id: '2', left: 'Dog', right: language === 'uk' ? 'Собака' : 'Canine pet', leftEmoji: '🐶', rightEmoji: '🦴' },
        { id: '3', left: 'Apple', right: language === 'uk' ? 'Яблуко' : 'Red fruit', leftEmoji: '🍎', rightEmoji: '🌳' },
        { id: '4', left: 'Book', right: language === 'uk' ? 'Книга' : 'For reading', leftEmoji: '📚', rightEmoji: '📖' },
        { id: '5', left: 'Sun', right: language === 'uk' ? 'Сонце' : 'Star in sky', leftEmoji: '☀️', rightEmoji: '🌞' },
      ],
    },
    ukrainian: {
      title: language === 'uk' ? 'З\'єднай слова з перекладами' : 'Match Ukrainian Words',
      pairs: [
        { id: '1', left: language === 'uk' ? 'Кіт' : 'Кіт', right: 'Cat', leftEmoji: '🐱', rightEmoji: '🐈' },
        { id: '2', left: language === 'uk' ? 'Сонце' : 'Сонце', right: 'Sun', leftEmoji: '☀️', rightEmoji: '🌞' },
        { id: '3', left: language === 'uk' ? 'Квітка' : 'Квітка', right: 'Flower', leftEmoji: '🌺', rightEmoji: '🌸' },
        { id: '4', left: language === 'uk' ? 'Вода' : 'Вода', right: 'Water', leftEmoji: '💧', rightEmoji: '💦' },
        { id: '5', left: language === 'uk' ? 'Дерево' : 'Дерево', right: 'Tree', leftEmoji: '🌳', rightEmoji: '🌲' },
      ],
    },
  };

  const data = exerciseData[subject];
  const [pairs] = useState<MatchPair[]>(data.pairs);
  const [rightItems] = useState(() => 
    [...data.pairs].map(p => ({ id: p.id, text: p.right, emoji: p.rightEmoji })).sort(() => Math.random() - 0.5)
  );
  
  const [connections, setConnections] = useState<Connection[]>([]);
  const [selectedLeft, setSelectedLeft] = useState<string | null>(null);
  const [isComplete, setIsComplete] = useState(false);
  const [score, setScore] = useState(0);

  const handleLeftClick = (id: string) => {
    // Check if already connected
    const existingConnection = connections.find(c => c.leftId === id);
    if (existingConnection) {
      // Remove connection
      setConnections(connections.filter(c => c.leftId !== id));
      setSelectedLeft(null);
    } else {
      setSelectedLeft(id);
    }
  };

  const handleRightClick = (rightId: string) => {
    if (!selectedLeft) return;

    // Check if right item already connected
    const existingConnection = connections.find(c => c.rightId === rightId);
    if (existingConnection) {
      setConnections(connections.filter(c => c.rightId !== rightId));
    }

    const newConnection: Connection = {
      leftId: selectedLeft,
      rightId: rightId,
    };

    const newConnections = [...connections.filter(c => c.leftId !== selectedLeft), newConnection];
    setConnections(newConnections);
    setSelectedLeft(null);
  };

  const checkAnswers = () => {
    if (connections.length !== pairs.length) {
      alert(language === 'uk' ? '❌ З\'єднайте всі пари!' : '❌ Connect all pairs!');
      return;
    }

    let correct = 0;
    connections.forEach(conn => {
      if (conn.leftId === conn.rightId) {
        correct++;
      }
    });

    setScore(correct);
    setIsComplete(true);
    setTimeout(() => {
      onComplete(correct);
    }, 2500);
  };

  const resetConnections = () => {
    setConnections([]);
    setSelectedLeft(null);
  };

  const getConnectionPath = (leftId: string, rightId: string) => {
    const leftElement = document.getElementById(`left-${leftId}`);
    const rightElement = document.getElementById(`right-${rightId}`);
    const container = containerRef.current;

    if (!leftElement || !rightElement || !container) return '';

    const containerRect = container.getBoundingClientRect();
    const leftRect = leftElement.getBoundingClientRect();
    const rightRect = rightElement.getBoundingClientRect();

    const x1 = leftRect.right - containerRect.left;
    const y1 = leftRect.top + leftRect.height / 2 - containerRect.top;
    const x2 = rightRect.left - containerRect.left;
    const y2 = rightRect.top + rightRect.height / 2 - containerRect.top;

    const midX = (x1 + x2) / 2;

    return `M ${x1} ${y1} Q ${midX} ${y1}, ${midX} ${(y1 + y2) / 2} T ${x2} ${y2}`;
  };

  if (isComplete) {
    const percentage = Math.round((score / pairs.length) * 100);
    return (
      <div className="text-center py-12 px-4">
        <div className="mb-8">
          <Trophy size={80} className="text-yellow-500 mx-auto mb-4" />
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">
            {percentage === 100
              ? language === 'uk' ? '🎉 Досконало!' : '🎉 Perfect!'
              : percentage >= 60
              ? language === 'uk' ? '👍 Добре!' : '👍 Good!'
              : language === 'uk' ? '💪 Спробуй ще!' : '💪 Try Again!'}
          </h2>
          <p className="text-2xl text-gray-600">
            {language === 'uk' ? 'Правильних пар' : 'Correct Matches'}: {score}/{pairs.length}
          </p>
          <p className="text-xl text-gray-500 mt-2">
            {percentage}%
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-4 md:p-8">
      <div className="mb-8">
        <h2 className="text-2xl md:text-4xl font-bold text-gray-800 mb-4 text-center">
          {data.title}
        </h2>
        <p className="text-center text-gray-600 text-base md:text-lg">
          {language === 'uk'
            ? '🎯 Клацніть на елемент зліва, потім на відповідний елемент справа'
            : '🎯 Click an item on the left, then click its match on the right'}
        </p>
      </div>

      <div ref={containerRef} className="relative">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-16 relative z-10">
          {/* Left Column */}
          <div className="space-y-4">
            {pairs.map((pair) => {
              const isConnected = connections.some(c => c.leftId === pair.id);
              const isSelected = selectedLeft === pair.id;
              
              return (
                <button
                  key={pair.id}
                  id={`left-${pair.id}`}
                  onClick={() => handleLeftClick(pair.id)}
                  className={`w-full bg-gradient-to-r from-blue-400 to-blue-600 text-white font-bold px-6 py-4 rounded-2xl shadow-lg transform transition-all ${
                    isSelected
                      ? 'scale-105 ring-4 ring-yellow-400'
                      : isConnected
                      ? 'opacity-75'
                      : 'hover:scale-105'
                  } border-4 border-white`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-3xl">{pair.leftEmoji}</span>
                    <span className="text-lg md:text-xl">{pair.left}</span>
                    <div className={`w-4 h-4 rounded-full ${isConnected ? 'bg-green-400' : 'bg-white/30'}`} />
                  </div>
                </button>
              );
            })}
          </div>

          {/* Right Column */}
          <div className="space-y-4">
            {rightItems.map((item) => {
              const isConnected = connections.some(c => c.rightId === item.id);
              const canConnect = selectedLeft !== null;
              
              return (
                <button
                  key={item.id}
                  id={`right-${item.id}`}
                  onClick={() => handleRightClick(item.id)}
                  disabled={!canConnect && !isConnected}
                  className={`w-full bg-gradient-to-r from-purple-400 to-purple-600 text-white font-bold px-6 py-4 rounded-2xl shadow-lg transform transition-all ${
                    canConnect && !isConnected
                      ? 'hover:scale-105 cursor-pointer'
                      : isConnected
                      ? 'opacity-75 cursor-pointer'
                      : 'opacity-50 cursor-not-allowed'
                  } border-4 border-white`}
                >
                  <div className="flex items-center justify-between">
                    <div className={`w-4 h-4 rounded-full ${isConnected ? 'bg-green-400' : 'bg-white/30'}`} />
                    <span className="text-lg md:text-xl">{item.text}</span>
                    <span className="text-3xl">{item.emoji}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* SVG for connections */}
        <svg
          ref={svgRef}
          className="absolute top-0 left-0 w-full h-full pointer-events-none z-0"
          style={{ overflow: 'visible' }}
        >
          {connections.map((conn, index) => {
            const path = getConnectionPath(conn.leftId, conn.rightId);
            const isCorrect = conn.leftId === conn.rightId;
            
            return (
              <path
                key={index}
                d={path}
                stroke={isCorrect ? '#10b981' : '#8b5cf6'}
                strokeWidth="4"
                fill="none"
                strokeLinecap="round"
                className="drop-shadow-lg"
              />
            );
          })}
        </svg>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 justify-center mt-8">
        <button
          onClick={checkAnswers}
          className="bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold px-8 py-4 rounded-2xl shadow-lg hover:shadow-xl transform hover:scale-105 transition-all text-lg md:text-xl"
        >
          ✅ {language === 'uk' ? 'Перевірити' : 'Check Answers'}
        </button>
        <button
          onClick={resetConnections}
          className="bg-gradient-to-r from-orange-400 to-red-500 text-white font-bold px-8 py-4 rounded-2xl shadow-lg hover:shadow-xl transform hover:scale-105 transition-all flex items-center gap-2 justify-center text-lg md:text-xl"
        >
          <RefreshCw size={24} />
          {language === 'uk' ? 'Скинути' : 'Reset'}
        </button>
      </div>

      <div className="mt-6 text-center">
        <div className="inline-flex items-center gap-2 bg-blue-100 px-6 py-3 rounded-full border-2 border-blue-400">
          <span className="text-2xl">🔗</span>
          <span className="font-bold text-gray-800">
            {language === 'uk' ? 'З\'єднано' : 'Connected'}: {connections.length}/{pairs.length}
          </span>
        </div>
      </div>
    </div>
  );
}
