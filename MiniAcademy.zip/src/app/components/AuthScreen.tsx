import { useState } from 'react';
import { User, Lock, LogIn, UserPlus, GraduationCap, Shield, Mail, Eye, EyeOff } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { LanguageSwitcher } from './LanguageSwitcher';
import { loginUser, registerUser } from '/src/utils/api';

interface AuthScreenProps {
  onLogin: (username: string, grade: number, userData: any, isAdmin?: boolean) => void;
  onForgotPassword?: () => void;
}

export function AuthScreen({ onLogin, onForgotPassword }: AuthScreenProps) {
  const { t, language } = useLanguage();
  const [isLogin, setIsLogin] = useState(true);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [email, setEmail] = useState('');
  const [parentEmail, setParentEmail] = useState('');
  const [selectedGrade, setSelectedGrade] = useState<number>(1);
  const [error, setError] = useState('');
  const [isAdminMode, setIsAdminMode] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!username || !password) {
      setError(t('auth.fillAllFields'));
      return;
    }

    // Check for admin login
    if (isAdminMode) {
      const adminUsername = localStorage.getItem('admin_username') || 'admin';
      const adminPassword = localStorage.getItem('admin_password') || 'admin100';
      
      if (username === adminUsername && password === adminPassword) {
        onLogin(username, 0, { username, isAdmin: true }, true);
      } else {
        setError(language === 'uk' ? 'Невірні дані адміністратора' : 'Invalid admin credentials');
      }
      return;
    }

    setIsLoading(true);

    try {
      if (isLogin) {
        // Login
        const result = await loginUser(username, password);
        console.log('Login successful!', result);
        onLogin(username, result.user.grade, result.user, false);
      } else {
        // Register
        if (!email) {
          setError(language === 'uk' ? 'Будь ласка, введіть вашу електронну адресу' : 'Please enter your email address');
          setIsLoading(false);
          return;
        }

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
          setError(language === 'uk' ? 'Будь ласка, введіть дійсну електронну адресу' : 'Please enter a valid email address');
          setIsLoading(false);
          return;
        }

        const result = await registerUser({
          username,
          password,
          email,
          grade: selectedGrade,
          parentEmail: parentEmail || undefined
        });

        console.log('Registration successful!', result);
        onLogin(username, selectedGrade, result.user, false);
      }
    } catch (error: any) {
      console.error('Authentication error:', error);
      
      // Translate error messages
      let errorMessage = error.message;
      if (language === 'uk') {
        if (errorMessage.includes('Username already exists')) {
          errorMessage = 'Це ім\'я користувача вже зайняте';
        } else if (errorMessage.includes('Email already registered')) {
          errorMessage = 'Акаунт з цією електронною адресою вже існує';
        } else if (errorMessage.includes('Invalid username or password')) {
          errorMessage = 'Невірне ім\'я користувача або пароль';
        } else if (errorMessage.includes('Missing required fields')) {
          errorMessage = 'Заповніть всі обов\'язкові поля';
        }
      }
      
      setError(errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-300 via-pink-300 to-purple-400 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Playful background decorations */}
      <div className="absolute top-10 left-10 text-8xl animate-bounce">🦁</div>
      <div className="absolute top-20 right-20 text-7xl animate-pulse">🦋</div>
      <div className="absolute bottom-20 left-20 text-9xl">🌈</div>
      <div className="absolute bottom-10 right-10 text-8xl animate-bounce" style={{ animationDelay: '0.5s' }}>🐘</div>
      <div className="absolute top-1/2 right-5 text-6xl">🌟</div>
      <div className="absolute top-1/3 left-5 text-7xl">🎈</div>
      
      <div className="absolute top-4 right-4 z-20">
        <LanguageSwitcher />
      </div>
      
      <div className="bg-white rounded-3xl shadow-2xl p-8 w-full max-w-md relative z-10 border-8 border-yellow-400">
        <div className="text-center mb-8">
          {isAdminMode ? (
            <div className="bg-gradient-to-br from-red-500 to-orange-600 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-4 shadow-xl">
              <Shield size={50} className="text-white" />
            </div>
          ) : (
            <div className="bg-gradient-to-br from-purple-500 to-pink-500 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-4 shadow-xl">
              <User size={50} className="text-white" />
            </div>
          )}
          <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600 mb-2">
            {isAdminMode ? '👨‍💼 Admin Login' : t('home.title')}
          </h1>
          <p className="text-gray-600 text-lg">
            {isAdminMode ? 'Access the admin dashboard' : (isLogin ? t('auth.welcome') : t('auth.createAccount'))}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">
              {t('auth.username')}
            </label>
            <div className="relative">
              <User size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border-4 border-purple-300 rounded-2xl focus:border-purple-500 focus:outline-none text-lg"
                placeholder={t('auth.enterUsername')}
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold text-gray-700 mb-2">
              {t('auth.password')}
            </label>
            <div className="relative">
              <Lock size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border-4 border-purple-300 rounded-2xl focus:border-purple-500 focus:outline-none text-lg"
                placeholder={t('auth.enterPassword')}
              />
              <button
                type="button"
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
              </button>
            </div>
          </div>

          {!isLogin && !isAdminMode && (
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">
                <div className="flex items-center gap-2">
                  <Mail size={18} />
                  {t('auth.email')}
                </div>
              </label>
              <div className="relative">
                <Mail size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border-4 border-purple-300 rounded-2xl focus:border-purple-500 focus:outline-none text-lg"
                  placeholder={t('auth.enterEmail')}
                />
              </div>
            </div>
          )}

          {!isLogin && !isAdminMode && (
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">
                <div className="flex items-center gap-2">
                  👶 {t('auth.age')}
                </div>
              </label>
              <div className="grid grid-cols-5 gap-2">
                {[6, 7, 8, 9, 10].map((ageOption) => (
                  <button
                    key={ageOption}
                    type="button"
                    onClick={() => setAge(ageOption)}
                    className={`py-3 rounded-xl font-bold text-lg transition-all transform hover:scale-110 shadow-md ${
                      age === ageOption
                        ? 'bg-gradient-to-r from-blue-500 to-cyan-500 text-white scale-110'
                        : 'bg-gradient-to-r from-blue-200 to-cyan-200 text-gray-700 hover:from-blue-300 hover:to-cyan-300'
                    }`}
                  >
                    {ageOption}
                  </button>
                ))}
              </div>
            </div>
          )}

          {!isLogin && !isAdminMode && (
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">
                <div className="flex items-center gap-2">
                  <GraduationCap size={18} />
                  {t('auth.selectGrade')}
                </div>
              </label>
              <div className="grid grid-cols-5 gap-2">
                {[1, 2, 3, 4, 5].map((grade) => (
                  <button
                    key={grade}
                    type="button"
                    onClick={() => setSelectedGrade(grade)}
                    className={`py-3 rounded-xl font-bold text-lg transition-all transform hover:scale-110 shadow-md ${
                      selectedGrade === grade
                        ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white scale-110'
                        : 'bg-gradient-to-r from-yellow-200 to-orange-200 text-gray-700 hover:from-yellow-300 hover:to-orange-300'
                    }`}
                  >
                    {grade}
                  </button>
                ))}
              </div>
            </div>
          )}

          {!isLogin && !isAdminMode && (
            <div>
              <label className="block text-sm font-bold text-gray-700 mb-2">
                <div className="flex items-center gap-2">
                  <Mail size={18} />
                  {t('auth.parentEmail')}
                </div>
              </label>
              <div className="relative">
                <Mail size={20} className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                <input
                  type="email"
                  value={parentEmail}
                  onChange={(e) => setParentEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border-4 border-purple-300 rounded-2xl focus:border-purple-500 focus:outline-none text-lg"
                  placeholder={t('auth.enterParentEmail')}
                />
              </div>
            </div>
          )}

          {error && (
            <div className="bg-red-100 border-4 border-red-400 text-red-700 px-4 py-3 rounded-2xl text-sm font-bold">
              ⚠️ {error}
            </div>
          )}

          <button
            type="submit"
            className={`w-full py-4 rounded-2xl font-bold text-lg transition-all flex items-center justify-center gap-2 shadow-lg transform hover:scale-105 ${
              isAdminMode
                ? 'bg-gradient-to-r from-red-500 to-orange-600 hover:from-red-600 hover:to-orange-700'
                : 'bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600'
            } text-white`}
          >
            {isLoading ? (
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
            ) : isLogin || isAdminMode ? (
              <>
                <LogIn size={24} />
                {isAdminMode ? 'Admin Login' : t('auth.login')}
              </>
            ) : (
              <>
                <UserPlus size={24} />
                {t('auth.signup')}
              </>
            )}
          </button>
        </form>

        {!isAdminMode && (
          <div className="mt-6 text-center">
            <button
              onClick={() => {
                setIsLogin(!isLogin);
                setError('');
              }}
              className="text-purple-600 hover:text-purple-700 font-bold text-lg"
            >
              {isLogin ? t('auth.noAccount') : t('auth.hasAccount')}
            </button>
          </div>
        )}

        {isLogin && !isAdminMode && onForgotPassword && (
          <div className="mt-3 text-center">
            <button
              onClick={onForgotPassword}
              className="text-sm text-blue-600 hover:text-blue-700 font-semibold flex items-center gap-1 mx-auto"
            >
              <Lock size={16} />
              Forgot Password?
            </button>
          </div>
        )}

        <div className="mt-4 text-center">
          <button
            onClick={() => {
              setIsAdminMode(!isAdminMode);
              setIsLogin(true);
              setError('');
              setUsername('');
              setPassword('');
            }}
            className="text-sm text-gray-500 hover:text-orange-600 font-medium flex items-center gap-1 mx-auto"
          >
            <Shield size={16} />
            {isAdminMode ? 'Back to Student Login' : 'Admin Login'}
          </button>
        </div>
      </div>
    </div>
  );
}