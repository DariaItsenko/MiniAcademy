import { Languages } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export function LanguageSwitcher() {
  const { language, setLanguage } = useLanguage();

  return (
    <div className="flex items-center gap-2 bg-white px-4 py-2 rounded-full shadow-md">
      <Languages size={20} className="text-purple-600" />
      <button
        onClick={() => setLanguage('en')}
        className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
          language === 'en'
            ? 'bg-purple-600 text-white'
            : 'text-gray-600 hover:bg-gray-100'
        }`}
      >
        EN
      </button>
      <button
        onClick={() => setLanguage('uk')}
        className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
          language === 'uk'
            ? 'bg-purple-600 text-white'
            : 'text-gray-600 hover:bg-gray-100'
        }`}
      >
        UK
      </button>
    </div>
  );
}
