import { Calendar, Clock, Users } from 'lucide-react';

interface WebinarCardProps {
  title: string;
  date: string;
  time: string;
  instructor: string;
  participants: number;
  level: string;
  onClick?: () => void;
}

export function WebinarCard({ title, date, time, instructor, participants, level, onClick }: WebinarCardProps) {
  return (
    <div 
      onClick={onClick}
      className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow p-6 border-2 border-gray-100 cursor-pointer"
    >
      <div className="flex justify-between items-start mb-4">
        <h3 className="text-xl font-semibold text-gray-800">{title}</h3>
        <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium">
          {level}
        </span>
      </div>
      
      <div className="space-y-2 text-gray-600">
        <div className="flex items-center gap-2">
          <Calendar size={18} />
          <span>{date}</span>
        </div>
        <div className="flex items-center gap-2">
          <Clock size={18} />
          <span>{time}</span>
        </div>
        <div className="flex items-center gap-2">
          <Users size={18} />
          <span>{participants} students enrolled</span>
        </div>
      </div>
      
      <div className="mt-4 pt-4 border-t border-gray-100">
        <p className="text-sm text-gray-600">Instructor: <span className="font-medium text-gray-800">{instructor}</span></p>
      </div>
      
      <button className="w-full mt-4 bg-gradient-to-r from-purple-500 to-pink-500 text-white py-3 rounded-lg font-semibold hover:from-purple-600 hover:to-pink-600 transition-all">
        View Details
      </button>
    </div>
  );
}