import { useState, useEffect } from 'react';
import { CheckCircle, XCircle } from 'lucide-react';

interface Question {
  question: string;
  answer: number;
  options: number[];
}

interface MathExerciseProps {
  level: number;
  onComplete: (stars: number) => void;
}

const generateQuestions = (level: number): Question[] => {
  const questions: Question[] = [];
  
  for (let i = 0; i < 10; i++) {
    let question: Question;
    
    switch (level) {
      case 1: // Addition & Subtraction
        const num1 = Math.floor(Math.random() * 50) + 1;
        const num2 = Math.floor(Math.random() * 50) + 1;
        const isAddition = Math.random() > 0.5;
        const answer = isAddition ? num1 + num2 : Math.max(num1, num2) - Math.min(num1, num2);
        question = {
          question: isAddition ? `${num1} + ${num2} = ?` : `${Math.max(num1, num2)} - ${Math.min(num1, num2)} = ?`,
          answer,
          options: [answer, answer + 1, answer - 1, answer + 2].sort(() => Math.random() - 0.5)
        };
        break;
        
      case 2: // Multiplication
        const mult1 = Math.floor(Math.random() * 10) + 1;
        const mult2 = Math.floor(Math.random() * 10) + 1;
        const multAnswer = mult1 * mult2;
        question = {
          question: `${mult1} × ${mult2} = ?`,
          answer: multAnswer,
          options: [multAnswer, multAnswer + mult1, multAnswer - mult2, multAnswer + 5].sort(() => Math.random() - 0.5)
        };
        break;
        
      case 3: // Division
        const div2 = Math.floor(Math.random() * 9) + 2;
        const divAnswer = Math.floor(Math.random() * 10) + 1;
        const div1 = div2 * divAnswer;
        question = {
          question: `${div1} ÷ ${div2} = ?`,
          answer: divAnswer,
          options: [divAnswer, divAnswer + 1, divAnswer - 1, divAnswer + 2].sort(() => Math.random() - 0.5)
        };
        break;
        
      default: // Word problems
        const apples = Math.floor(Math.random() * 20) + 10;
        const given = Math.floor(Math.random() * 10) + 5;
        const wordAnswer = apples + given;
        question = {
          question: `Sarah has ${apples} apples. Her friend gives her ${given} more. How many does she have now?`,
          answer: wordAnswer,
          options: [wordAnswer, wordAnswer - 5, wordAnswer + 3, apples - given].sort(() => Math.random() - 0.5)
        };
    }
    
    questions.push(question);
  }
  
  return questions;
};

export function MathExercise({ level, onComplete }: MathExerciseProps) {
  const [questions] = useState<Question[]>(generateQuestions(level));
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);

  const handleAnswer = (answer: number) => {
    setSelectedAnswer(answer);
    const correct = answer === questions[currentQuestion].answer;
    setIsCorrect(correct);
    
    if (correct) {
      setScore(score + 1);
    }

    setTimeout(() => {
      if (currentQuestion < questions.length - 1) {
        setCurrentQuestion(currentQuestion + 1);
        setSelectedAnswer(null);
        setIsCorrect(null);
      } else {
        setShowResult(true);
      }
    }, 1000);
  };

  useEffect(() => {
    if (showResult) {
      const stars = score >= 9 ? 3 : score >= 7 ? 2 : score >= 5 ? 1 : 0;
      setTimeout(() => onComplete(stars), 2000);
    }
  }, [showResult, score, onComplete]);

  if (showResult) {
    const stars = score >= 9 ? 3 : score >= 7 ? 2 : score >= 5 ? 1 : 0;
    
    return (
      <div className="text-center py-12">
        <div className="mb-8">
          <div className="text-6xl mb-4">
            {stars === 3 ? '🌟🌟🌟' : stars === 2 ? '🌟🌟' : stars === 1 ? '🌟' : '📚'}
          </div>
          <h2 className="text-3xl font-bold text-gray-800 mb-2">
            {stars === 3 ? 'Excellent!' : stars === 2 ? 'Great Job!' : stars === 1 ? 'Good Try!' : 'Keep Practicing!'}
          </h2>
          <p className="text-xl text-gray-600">
            You scored {score} out of {questions.length}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto">
      <div className="mb-6">
        <div className="flex justify-between text-sm text-gray-600 mb-2">
          <span>Question {currentQuestion + 1} of {questions.length}</span>
          <span>Score: {score}/{questions.length}</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div
            className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full transition-all"
            style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
          />
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-lg p-8 mb-6">
        <h3 className="text-2xl font-bold text-gray-800 mb-8 text-center">
          {questions[currentQuestion].question}
        </h3>

        <div className="grid grid-cols-2 gap-4">
          {questions[currentQuestion].options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleAnswer(option)}
              disabled={selectedAnswer !== null}
              className={`p-6 rounded-lg font-bold text-xl transition-all ${
                selectedAnswer === option
                  ? isCorrect
                    ? 'bg-green-500 text-white'
                    : 'bg-red-500 text-white'
                  : 'bg-gray-100 hover:bg-gray-200 text-gray-800'
              } ${selectedAnswer !== null ? 'cursor-not-allowed' : 'hover:shadow-md'}`}
            >
              <div className="flex items-center justify-center gap-2">
                {option}
                {selectedAnswer === option && (
                  isCorrect ? <CheckCircle size={24} /> : <XCircle size={24} />
                )}
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
