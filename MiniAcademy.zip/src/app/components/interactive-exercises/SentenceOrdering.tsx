import { useState } from 'react';
import { DndProvider, useDrag, useDrop } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { useLanguage } from '../../contexts/LanguageContext';
import { Trophy, RefreshCw } from 'lucide-react';

interface WordPiece {
  id: string;
  text: string;
  order: number;
}

interface DraggableWordProps {
  word: WordPiece;
  index: number;
  moveWord: (dragIndex: number, hoverIndex: number) => void;
}

const DraggableWord = ({ word, index, moveWord }: DraggableWordProps) => {
  const [{ isDragging }, drag] = useDrag(() => ({
    type: 'word',
    item: { index },
    collect: (monitor) => ({
      isDragging: !!monitor.isDragging(),
    }),
  }), [index]);

  const [, drop] = useDrop(() => ({
    accept: 'word',
    hover: (item: { index: number }) => {
      if (item.index !== index) {
        moveWord(item.index, index);
        item.index = index;
      }
    },
  }), [index, moveWord]);

  return (
    <div
      ref={(node) => drag(drop(node))}
      className={`bg-gradient-to-r from-purple-400 to-pink-400 text-white font-bold px-6 py-4 rounded-2xl shadow-lg cursor-move transform hover:scale-105 transition-all border-4 border-white ${
        isDragging ? 'opacity-50' : ''
      }`}
    >
      <span className="text-xl md:text-2xl">{word.text}</span>
    </div>
  );
};

interface SentenceOrderingProps {
  onComplete: (score: number) => void;
  subject: 'math' | 'english' | 'ukrainian';
}

export function SentenceOrdering({ onComplete, subject }: SentenceOrderingProps) {
  const { language } = useLanguage();

  const exerciseData = {
    math: [
      {
        sentence: language === 'uk'
          ? ['Якщо', 'додати', '5', 'і', '3', 'вийде', '8']
          : ['If', 'you', 'add', '5', 'and', '3', 'you', 'get', '8'],
        emoji: '➕',
      },
      {
        sentence: language === 'uk'
          ? ['Квадрат', 'має', 'чотири', 'рівні', 'сторони']
          : ['A', 'square', 'has', 'four', 'equal', 'sides'],
        emoji: '🟦',
      },
      {
        sentence: language === 'uk'
          ? ['Половина', 'від', '10', 'дорівнює', '5']
          : ['Half', 'of', '10', 'equals', '5'],
        emoji: '➗',
      },
    ],
    english: [
      {
        sentence: language === 'uk'
          ? ['The', 'cat', 'is', 'sleeping', 'on', 'the', 'mat']
          : ['The', 'cat', 'is', 'sleeping', 'on', 'the', 'mat'],
        emoji: '🐱',
      },
      {
        sentence: language === 'uk'
          ? ['I', 'love', 'to', 'read', 'books', 'every', 'day']
          : ['I', 'love', 'to', 'read', 'books', 'every', 'day'],
        emoji: '📚',
      },
      {
        sentence: language === 'uk'
          ? ['The', 'sun', 'shines', 'brightly', 'in', 'the', 'sky']
          : ['The', 'sun', 'shines', 'brightly', 'in', 'the', 'sky'],
        emoji: '☀️',
      },
    ],
    ukrainian: [
      {
        sentence: language === 'uk'
          ? ['Я', 'люблю', 'вивчати', 'українську', 'мову']
          : ['Я', 'люблю', 'вивчати', 'українську', 'мову'],
        emoji: '🇺🇦',
      },
      {
        sentence: language === 'uk'
          ? ['Діти', 'граються', 'у', 'парку', 'щодня']
          : ['Діти', 'граються', 'у', 'парку', 'щодня'],
        emoji: '🎈',
      },
      {
        sentence: language === 'uk'
          ? ['Сонце', 'світить', 'яскраво', 'на', 'небі']
          : ['Сонце', 'світить', 'яскраво', 'на', 'небі'],
        emoji: '🌞',
      },
    ],
  };

  const sentences = exerciseData[subject];
  const [currentSentence, setCurrentSentence] = useState(0);
  const [words, setWords] = useState<WordPiece[]>(
    sentences[0].sentence
      .map((word, index) => ({ id: `${index}`, text: word, order: index }))
      .sort(() => Math.random() - 0.5)
  );
  const [isComplete, setIsComplete] = useState(false);
  const [totalScore, setTotalScore] = useState(0);

  const moveWord = (dragIndex: number, hoverIndex: number) => {
    const newWords = [...words];
    const [removed] = newWords.splice(dragIndex, 1);
    newWords.splice(hoverIndex, 0, removed);
    setWords(newWords);
  };

  const checkAnswer = () => {
    const isCorrect = words.every((word, index) => word.order === index);
    
    if (isCorrect) {
      const newScore = totalScore + 1;
      setTotalScore(newScore);
      
      if (currentSentence < sentences.length - 1) {
        setTimeout(() => {
          const nextIndex = currentSentence + 1;
          setCurrentSentence(nextIndex);
          setWords(
            sentences[nextIndex].sentence
              .map((word, index) => ({ id: `${index}`, text: word, order: index }))
              .sort(() => Math.random() - 0.5)
          );
        }, 1500);
      } else {
        setIsComplete(true);
        setTimeout(() => {
          onComplete(newScore);
        }, 2500);
      }
    } else {
      alert(language === 'uk' ? '❌ Спробуйте ще раз!' : '❌ Try again!');
    }
  };

  const resetPuzzle = () => {
    setWords(
      sentences[currentSentence].sentence
        .map((word, index) => ({ id: `${index}`, text: word, order: index }))
        .sort(() => Math.random() - 0.5)
    );
  };

  if (isComplete) {
    const percentage = Math.round((totalScore / sentences.length) * 100);
    return (
      <div className="text-center py-12 px-4">
        <div className="mb-8">
          <Trophy size={80} className="text-yellow-500 mx-auto mb-4" />
          <h2 className="text-4xl md:text-5xl font-bold text-gray-800 mb-4">
            {percentage === 100
              ? language === 'uk' ? '🎉 Досконало!' : '🎉 Perfect!'
              : percentage >= 66
              ? language === 'uk' ? '👍 Чудово!' : '👍 Great!'
              : language === 'uk' ? '💪 Добре!' : '💪 Good!'}
          </h2>
          <p className="text-2xl text-gray-600">
            {language === 'uk' ? 'Правильних речень' : 'Correct Sentences'}: {totalScore}/{sentences.length}
          </p>
          <p className="text-xl text-gray-500 mt-2">
            {percentage}%
          </p>
        </div>
      </div>
    );
  }

  return (
    <DndProvider backend={HTML5Backend}>
      <div className="max-w-4xl mx-auto p-4 md:p-8">
        <div className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl md:text-4xl font-bold text-gray-800">
              {language === 'uk' ? '🧩 Складіть речення' : '🧩 Build the Sentence'}
            </h2>
            <div className="text-lg font-bold text-gray-600">
              {currentSentence + 1}/{sentences.length}
            </div>
          </div>
          <p className="text-center text-gray-600 text-base md:text-lg mb-2">
            {language === 'uk'
              ? 'Перетягніть слова у правильному порядку'
              : 'Drag the words into the correct order'}
          </p>
          <div className="text-center text-5xl mb-6">
            {sentences[currentSentence].emoji}
          </div>
        </div>

        <div className="bg-gradient-to-br from-blue-100 to-purple-100 rounded-3xl p-6 md:p-8 mb-8 border-4 border-white shadow-xl">
          <div className="flex flex-wrap gap-3 md:gap-4 justify-center">
            {words.map((word, index) => (
              <DraggableWord
                key={word.id}
                word={word}
                index={index}
                moveWord={moveWord}
              />
            ))}
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button
            onClick={checkAnswer}
            className="bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold px-8 py-4 rounded-2xl shadow-lg hover:shadow-xl transform hover:scale-105 transition-all text-lg md:text-xl"
          >
            ✅ {language === 'uk' ? 'Перевірити' : 'Check Answer'}
          </button>
          <button
            onClick={resetPuzzle}
            className="bg-gradient-to-r from-orange-400 to-red-500 text-white font-bold px-8 py-4 rounded-2xl shadow-lg hover:shadow-xl transform hover:scale-105 transition-all flex items-center gap-2 justify-center text-lg md:text-xl"
          >
            <RefreshCw size={24} />
            {language === 'uk' ? 'Скинути' : 'Reset'}
          </button>
        </div>

        <div className="mt-8 text-center">
          <div className="inline-flex items-center gap-2 bg-yellow-100 px-6 py-3 rounded-full border-2 border-yellow-400">
            <span className="text-2xl">🏆</span>
            <span className="font-bold text-gray-800">
              {language === 'uk' ? 'Бали' : 'Score'}: {totalScore}
            </span>
          </div>
        </div>
      </div>
    </DndProvider>
  );
}
