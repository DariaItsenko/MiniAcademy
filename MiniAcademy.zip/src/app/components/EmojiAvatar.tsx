import { useState, useEffect } from 'react';
import { RotateCw } from 'lucide-react';

interface EmojiAvatarProps {
  baseAvatar: string; // 'boy', 'girl', 'cat', 'dog', 'bear', 'fox', 'rabbit', 'panda'
  size?: 'small' | 'medium' | 'large';
  showRotation?: boolean;
  animated?: boolean;
  accessories?: string[];
}

const avatarEmojis: Record<string, string> = {
  boy: '👦',
  girl: '👧',
  cat: '🐱',
  dog: '🐶',
  bear: '🐻',
  fox: '🦊',
  rabbit: '🐰',
  panda: '🐼',
};

export function EmojiAvatar({ 
  baseAvatar, 
  size = 'medium',
  showRotation = false,
  animated = true,
  accessories = [],
}: EmojiAvatarProps) {
  const [isJumping, setIsJumping] = useState(false);
  const [rotation, setRotation] = useState(0);

  const sizeMap = {
    small: '120px',
    medium: '180px',
    large: '240px',
  };

  const fontSize = sizeMap[size];

  // Jumping animation
  useEffect(() => {
    if (!animated) return;
    const jumpInterval = setInterval(() => {
      setIsJumping(true);
      setTimeout(() => setIsJumping(false), 500);
    }, 4000 + Math.random() * 3000);
    return () => clearInterval(jumpInterval);
  }, [animated]);

  const rotateCharacter = () => {
    setRotation(prev => (prev + 90) % 360);
  };

  const emoji = avatarEmojis[baseAvatar] || avatarEmojis.boy;

  return (
    <div className="flex flex-col items-center gap-4">
      <div className="relative">
        {/* Main character */}
        <div 
          className={`
            text-center transition-all duration-500
            ${isJumping ? 'animate-bounce' : ''}
          `}
          style={{
            fontSize,
            transform: `rotateY(${rotation}deg)`,
            transformStyle: 'preserve-3d',
          }}
        >
          {emoji}
        </div>

        {/* Accessories overlay */}
        {accessories && accessories.length > 0 && (
          <div className="absolute top-0 left-1/2 transform -translate-x-1/2 flex flex-col items-center">
            {accessories.includes('crown') && (
              <div className="text-4xl" style={{ marginBottom: '-20px' }}>👑</div>
            )}
            {accessories.includes('hat') && (
              <div className="text-4xl" style={{ marginBottom: '-15px' }}>🎩</div>
            )}
            {accessories.includes('cap') && (
              <div className="text-4xl" style={{ marginBottom: '-15px' }}>🧢</div>
            )}
            {accessories.includes('glasses') && (
              <div className="text-3xl absolute" style={{ top: '40%' }}>🕶️</div>
            )}
          </div>
        )}

        {/* Backpack accessory */}
        {accessories.includes('backpack') && (
          <div 
            className="absolute text-3xl" 
            style={{ 
              top: '35%',
              right: '-10%',
              transform: `rotateY(${rotation}deg)`,
            }}
          >
            🎒
          </div>
        )}
      </div>

      {/* Manual rotation button */}
      {showRotation && (
        <button
          onClick={rotateCharacter}
          className="flex items-center gap-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white px-4 py-2 rounded-full shadow-lg hover:shadow-xl transition-all transform hover:scale-110 font-bold"
        >
          <RotateCw size={20} />
          Rotate
        </button>
      )}
    </div>
  );
}
