// Topic-based learning structure with groups, subtopics, and resources

export interface WorkedExample {
  id: string;
  title: string;
  problem: string;
  steps: Array<{
    stepNumber: number;
    explanation: string;
    calculation?: string;
    result?: string;
  }>;
  finalAnswer: string;
  tips?: string[];
}

export interface Lecture {
  id: string;
  title: string;
  content: string;
  keyPoints: string[];
  examples?: string[];
}

export interface Video {
  id: string;
  title: string;
  description: string;
  thumbnailEmoji: string;
  duration: string;
  url: string; // YouTube embed or video URL
}

export interface Exercise {
  id: string;
  question: string;
  type: 'multiple-choice' | 'input' | 'drag-drop';
  options?: string[];
  correctAnswer: string;
  hint: string;
  explanation: string;
  funFact?: string;
}

export interface Subtopic {
  id: string;
  title: string;
  description: string;
  emoji: string;
  videos: Video[];
  lectures: Lecture[];
  workedExamples: WorkedExample[];
  exercises: Exercise[];
}

export interface TopicGroup {
  id: string;
  title: string;
  description: string;
  emoji: string;
  color: string;
  subtopics: Subtopic[];
}

export interface SubjectTopics {
  math: TopicGroup[];
  english: TopicGroup[];
  ukrainian: TopicGroup[];
}

export const topicData: SubjectTopics = {
  math: [
    {
      id: 'numbers-operations',
      title: 'Numbers & Operations',
      description: 'Learn about numbers and how to work with them!',
      emoji: '🔢',
      color: 'from-blue-400 to-blue-600',
      subtopics: [
        {
          id: 'addition',
          title: 'Addition',
          description: 'Learn how to add numbers together',
          emoji: '➕',
          videos: [
            {
              id: 'addition-basics',
              title: 'Addition Basics for Beginners',
              description: 'Learn what addition means and how to add small numbers',
              thumbnailEmoji: '🎬',
              duration: '5:30',
              url: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
            },
            {
              id: 'addition-advanced',
              title: 'Adding Bigger Numbers',
              description: 'Master addition with two-digit numbers',
              thumbnailEmoji: '🎥',
              duration: '7:15',
              url: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
            }
          ],
          lectures: [
            {
              id: 'addition-lecture',
              title: 'Understanding Addition',
              content: `Addition is one of the most basic math operations. When we add, we combine two or more numbers to get a total.

**What is Addition?**
Addition means putting things together. If you have 3 apples and your friend gives you 2 more apples, you now have 5 apples total! We write this as: 3 + 2 = 5

**The Plus Sign (+)**
The plus sign (+) tells us to add numbers together. It's like saying "and" or "plus."

**Addition Facts**
- The numbers we add are called "addends"
- The answer is called the "sum"
- Example: In 4 + 5 = 9, the addends are 4 and 5, and the sum is 9

**Adding in Your Head**
Start with simple numbers and count up! For 6 + 3, start at 6 and count up 3 more: "7, 8, 9"`,
              keyPoints: [
                'Addition means combining numbers',
                'The + symbol means "add"',
                'The answer to addition is called the sum',
                'You can use your fingers or objects to help count',
                'Addition makes numbers bigger'
              ],
              examples: [
                '2 + 3 = 5 (Two plus three equals five)',
                '10 + 5 = 15 (Ten plus five equals fifteen)',
                '7 + 0 = 7 (Adding zero doesn\'t change the number!)'
              ]
            }
          ],
          workedExamples: [
            {
              id: 'example-1',
              title: 'Adding Two-Digit Numbers',
              problem: 'What is 23 + 15?',
              steps: [
                {
                  stepNumber: 1,
                  explanation: 'First, line up the numbers by place value (ones and tens)',
                  calculation: '  23\n+ 15\n----'
                },
                {
                  stepNumber: 2,
                  explanation: 'Add the ones column first: 3 + 5',
                  calculation: '3 + 5 = 8',
                  result: 'Write 8 in the ones place'
                },
                {
                  stepNumber: 3,
                  explanation: 'Add the tens column: 2 + 1',
                  calculation: '2 + 1 = 3',
                  result: 'Write 3 in the tens place'
                },
                {
                  stepNumber: 4,
                  explanation: 'Combine the results',
                  calculation: '  23\n+ 15\n----\n  38'
                }
              ],
              finalAnswer: '38',
              tips: [
                'Always start from the ones column (right side)',
                'Line up numbers carefully',
                'Check your work by adding in reverse: 15 + 23 should give the same answer!'
              ]
            },
            {
              id: 'example-2',
              title: 'Addition with Carrying',
              problem: 'What is 47 + 28?',
              steps: [
                {
                  stepNumber: 1,
                  explanation: 'Line up the numbers',
                  calculation: '  47\n+ 28\n----'
                },
                {
                  stepNumber: 2,
                  explanation: 'Add ones: 7 + 8 = 15. That\'s more than 10!',
                  calculation: '7 + 8 = 15',
                  result: 'Write 5, carry 1 to tens column'
                },
                {
                  stepNumber: 3,
                  explanation: 'Add tens: 4 + 2 = 6, plus the carried 1 = 7',
                  calculation: '4 + 2 + 1 = 7',
                  result: 'Write 7 in the tens place'
                }
              ],
              finalAnswer: '75',
              tips: [
                'When the sum is 10 or more, carry the 1 to the next column',
                'Don\'t forget to add the carried number!'
              ]
            }
          ],
          exercises: [
            {
              id: 'add-1',
              question: 'What is 5 + 3?',
              type: 'multiple-choice',
              options: ['6', '7', '8', '9'],
              correctAnswer: '8',
              hint: '🤔 Try counting on your fingers! Start with 5, then count up 3 more.',
              explanation: '5 + 3 = 8! Great job! When you have 5 things and add 3 more, you get 8 total.',
              funFact: '🎉 Did you know? 8 is called a "perfect cube" because 2 × 2 × 2 = 8!'
            },
            {
              id: 'add-2',
              question: 'If you have 12 candies and get 7 more, how many do you have?',
              type: 'multiple-choice',
              options: ['17', '18', '19', '20'],
              correctAnswer: '19',
              hint: '🍬 Count up from 12: add 7 more one at a time!',
              explanation: '12 + 7 = 19! You have 19 candies total. Yummy!',
              funFact: '🌟 19 is a prime number - it can only be divided by 1 and itself!'
            },
            {
              id: 'add-3',
              question: 'What is 25 + 34?',
              type: 'input',
              correctAnswer: '59',
              hint: '💡 Add the ones first (5 + 4 = 9), then the tens (2 + 3 = 5)',
              explanation: '25 + 34 = 59! You added the ones (5+4=9) and tens (2+3=5) correctly!',
              funFact: '🚀 59 is another prime number! There are only 15 prime numbers under 50.'
            }
          ]
        },
        {
          id: 'subtraction',
          title: 'Subtraction',
          description: 'Learn how to subtract and find the difference',
          emoji: '➖',
          videos: [
            {
              id: 'subtraction-basics',
              title: 'Subtraction Made Easy',
              description: 'Understand what subtraction means',
              thumbnailEmoji: '🎬',
              duration: '6:00',
              url: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
            }
          ],
          lectures: [
            {
              id: 'subtraction-lecture',
              title: 'Understanding Subtraction',
              content: `Subtraction is taking away! When we subtract, we remove some items from a group to find out how many are left.

**What is Subtraction?**
If you have 8 cookies and eat 3 of them, how many are left? We subtract: 8 - 3 = 5 cookies left!

**The Minus Sign (-)**
The minus sign (-) means "take away" or "subtract."

**Subtraction Vocabulary**
- The number you start with is called the "minuend"
- The number you subtract is called the "subtrahend"  
- The answer is called the "difference"
- Example: In 9 - 4 = 5, we have minuend (9), subtrahend (4), and difference (5)`,
              keyPoints: [
                'Subtraction means taking away',
                'The - symbol means "subtract"',
                'Subtraction makes numbers smaller',
                'You can check subtraction with addition!',
                'The answer is called the difference'
              ],
              examples: [
                '10 - 3 = 7',
                '15 - 5 = 10',
                '8 - 0 = 8 (Subtracting zero doesn\'t change the number!)'
              ]
            }
          ],
          workedExamples: [
            {
              id: 'sub-example-1',
              title: 'Simple Subtraction',
              problem: 'What is 45 - 23?',
              steps: [
                {
                  stepNumber: 1,
                  explanation: 'Line up the numbers',
                  calculation: '  45\n- 23\n----'
                },
                {
                  stepNumber: 2,
                  explanation: 'Subtract ones: 5 - 3',
                  calculation: '5 - 3 = 2'
                },
                {
                  stepNumber: 3,
                  explanation: 'Subtract tens: 4 - 2',
                  calculation: '4 - 2 = 2'
                }
              ],
              finalAnswer: '22',
              tips: ['Always start from the ones place', 'Check with addition: 22 + 23 = 45 ✓']
            }
          ],
          exercises: [
            {
              id: 'sub-1',
              question: 'What is 9 - 4?',
              type: 'multiple-choice',
              options: ['3', '4', '5', '6'],
              correctAnswer: '5',
              hint: '🖐️ Start with 9 and count back 4: 8, 7, 6, 5...',
              explanation: '9 - 4 = 5! Perfect! When you take 4 away from 9, you have 5 left.',
              funFact: '⭐ 5 is the number of fingers on one hand!'
            }
          ]
        },
        {
          id: 'multiplication',
          title: 'Multiplication',
          description: 'Master multiplication tables and repeated addition',
          emoji: '✖️',
          videos: [
            {
              id: 'mult-intro',
              title: 'Introduction to Multiplication',
              description: 'Learn what multiplication really means',
              thumbnailEmoji: '🎬',
              duration: '8:00',
              url: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
            }
          ],
          lectures: [
            {
              id: 'mult-lecture',
              title: 'Understanding Multiplication',
              content: `Multiplication is a fast way to add the same number many times!

**What is Multiplication?**
Instead of adding 3 + 3 + 3 + 3, we can multiply: 4 × 3 = 12
This means "4 groups of 3" or "3 added 4 times"

**The Times Sign (×)**
The × symbol means "times" or "multiply."

**Multiplication Makes Math Faster!**
- 2 + 2 + 2 + 2 + 2 = 10 (slow way)
- 5 × 2 = 10 (fast way!)`,
              keyPoints: [
                'Multiplication is repeated addition',
                'The × symbol means multiply',
                'Learn your times tables!',
                'Order doesn\'t matter: 3×4 = 4×3',
                'Any number times 0 equals 0'
              ],
              examples: [
                '3 × 4 = 12 (three groups of four)',
                '5 × 2 = 10 (five groups of two)',
                '7 × 1 = 7 (any number times 1 stays the same!)'
              ]
            }
          ],
          workedExamples: [
            {
              id: 'mult-example',
              title: 'Multiplication Tables',
              problem: 'What is 6 × 7?',
              steps: [
                {
                  stepNumber: 1,
                  explanation: 'Think of it as 6 groups of 7',
                  calculation: '7 + 7 + 7 + 7 + 7 + 7'
                },
                {
                  stepNumber: 2,
                  explanation: 'Or use the times table you memorized!',
                  calculation: '6 × 7 = 42'
                }
              ],
              finalAnswer: '42',
              tips: ['Practice times tables daily', 'Use skip counting: 7, 14, 21, 28, 35, 42!']
            }
          ],
          exercises: [
            {
              id: 'mult-1',
              question: 'What is 5 × 3?',
              type: 'multiple-choice',
              options: ['12', '13', '15', '18'],
              correctAnswer: '15',
              hint: '🔢 Count by 5s three times: 5, 10, 15!',
              explanation: '5 × 3 = 15! That means 5 + 5 + 5 = 15. Awesome!',
              funFact: '🎯 15 minutes is a quarter of an hour!'
            }
          ]
        }
      ]
    },
    {
      id: 'geometry',
      title: 'Shapes & Geometry',
      description: 'Explore shapes, patterns, and spatial reasoning',
      emoji: '📐',
      color: 'from-purple-400 to-purple-600',
      subtopics: [
        {
          id: 'basic-shapes',
          title: 'Basic Shapes',
          description: 'Learn about circles, squares, triangles and more!',
          emoji: '🔷',
          videos: [
            {
              id: 'shapes-video',
              title: 'All About Shapes',
              description: 'Discover different shapes around us',
              thumbnailEmoji: '🎬',
              duration: '5:00',
              url: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
            }
          ],
          lectures: [
            {
              id: 'shapes-lecture',
              title: 'Understanding Shapes',
              content: `Shapes are all around us! Let's learn about the most common shapes.

**Circle ⭕**
A circle is perfectly round with no corners. Examples: wheels, coins, pizza!

**Square ◻️**
A square has 4 equal sides and 4 corners. Examples: windows, crackers, chess board!

**Triangle 🔺**
A triangle has 3 sides and 3 corners. Examples: pizza slice, road signs, pyramids!

**Rectangle ▭**
A rectangle has 4 sides (opposite sides are equal) and 4 corners. Examples: doors, books, phones!`,
              keyPoints: [
                'Circles are round with no corners',
                'Squares have 4 equal sides',
                'Triangles have 3 sides',
                'Rectangles have 4 sides with opposite sides equal',
                'Look for shapes everywhere around you!'
              ]
            }
          ],
          workedExamples: [
            {
              id: 'shapes-example',
              title: 'Counting Sides and Corners',
              problem: 'How many sides does a pentagon have?',
              steps: [
                {
                  stepNumber: 1,
                  explanation: 'Pentagon means "5 sides"',
                  calculation: 'Penta = 5 in Greek'
                },
                {
                  stepNumber: 2,
                  explanation: 'Count each side of a pentagon',
                  result: '1, 2, 3, 4, 5 sides'
                }
              ],
              finalAnswer: '5 sides',
              tips: ['Pentagon has 5 sides and 5 corners']
            }
          ],
          exercises: [
            {
              id: 'shapes-1',
              question: 'Which shape has no corners?',
              type: 'multiple-choice',
              options: ['Square', 'Triangle', 'Circle', 'Rectangle'],
              correctAnswer: 'Circle',
              hint: '⭕ Think about something that rolls!',
              explanation: 'A circle has no corners! It\'s perfectly round and smooth.',
              funFact: '🍕 Pizzas are circles, but we cut them into triangular slices!'
            }
          ]
        }
      ]
    }
  ],
  english: [
    {
      id: 'phonics-reading',
      title: 'Phonics & Reading',
      description: 'Learn sounds, letters, and how to read!',
      emoji: '📖',
      color: 'from-green-400 to-green-600',
      subtopics: [
        {
          id: 'alphabet',
          title: 'The Alphabet',
          description: 'Learn all 26 letters and their sounds',
          emoji: '🔤',
          videos: [
            {
              id: 'abc-song',
              title: 'ABC Song and Letter Sounds',
              description: 'Learn the alphabet with a fun song!',
              thumbnailEmoji: '🎵',
              duration: '4:30',
              url: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
            }
          ],
          lectures: [
            {
              id: 'alphabet-lecture',
              title: 'The English Alphabet',
              content: `The English alphabet has 26 letters. Each letter has a name and makes a sound!

**Uppercase and Lowercase**
Every letter comes in two forms:
- UPPERCASE (Capital): A, B, C, D...
- lowercase (Small): a, b, c, d...

**Vowels and Consonants**
- Vowels: A, E, I, O, U (and sometimes Y)
- Consonants: All the other letters

**Letter Sounds**
Each letter makes a sound:
- A says "ah" like in Apple
- B says "buh" like in Ball
- C says "kuh" like in Cat`,
              keyPoints: [
                'There are 26 letters in the alphabet',
                'Each letter has uppercase and lowercase forms',
                'Vowels are A, E, I, O, U',
                'Letters make sounds that form words',
                'Practice writing each letter!'
              ]
            }
          ],
          workedExamples: [
            {
              id: 'alphabet-example',
              title: 'Identifying Vowels',
              problem: 'Circle the vowels in the word: APPLE',
              steps: [
                {
                  stepNumber: 1,
                  explanation: 'Remember: vowels are A, E, I, O, U',
                  calculation: 'Look at each letter: A - P - P - L - E'
                },
                {
                  stepNumber: 2,
                  explanation: 'Check which letters are vowels',
                  result: 'A is a vowel ✓, E is a vowel ✓'
                }
              ],
              finalAnswer: 'A and E are the vowels',
              tips: ['Every word has at least one vowel!']
            }
          ],
          exercises: [
            {
              id: 'alphabet-1',
              question: 'Which of these is a vowel?',
              type: 'multiple-choice',
              options: ['B', 'C', 'E', 'D'],
              correctAnswer: 'E',
              hint: '🎯 Remember: A, E, I, O, U are vowels!',
              explanation: 'E is a vowel! The vowels are A, E, I, O, and U.',
              funFact: '🌟 The letter E is the most commonly used letter in English!'
            }
          ]
        }
      ]
    }
  ],
  ukrainian: [
    {
      id: 'ukrainian-alphabet',
      title: 'Українська абетка',
      description: 'Вивчай літери та звуки української мови',
      emoji: '🇺🇦',
      color: 'from-yellow-400 to-blue-500',
      subtopics: [
        {
          id: 'cyrillic-letters',
          title: 'Кирилиця',
          description: 'Український алфавіт - 33 літери',
          emoji: '📝',
          videos: [
            {
              id: 'ukrainian-abc',
              title: 'Українська абетка',
              description: 'Пісня про українські літери',
              thumbnailEmoji: '🎵',
              duration: '5:00',
              url: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
            }
          ],
          lectures: [
            {
              id: 'cyrillic-lecture',
              title: 'Українська абетка',
              content: `Український алфавіт має 33 літери!

**Наша абетка:**
А, Б, В, Г, Ґ, Д, Е, Є, Ж, З, И, І, Ї, Й, К, Л, М, Н, О, П, Р, С, Т, У, Ф, Х, Ц, Ч, Ш, Щ, Ь, Ю, Я

**Голосні звуки:**
А, Е, Є, И, І, Ї, О, У, Ю, Я

**Приголосні звуки:**
Всі інші літери!`,
              keyPoints: [
                '33 літери в українській абетці',
                '10 голосних літер',
                'М\'який знак (Ь) не має звуку',
                'Кожна літера важлива!',
                'Практикуй написання кожної літери'
              ]
            }
          ],
          workedExamples: [],
          exercises: [
            {
              id: 'uk-1',
              question: 'Скільки літер в українській абетці?',
              type: 'multiple-choice',
              options: ['26', '30', '33', '35'],
              correctAnswer: '33',
              hint: '🇺🇦 Українська абетка більша за англійську!',
              explanation: 'Правильно! В українській абетці 33 літери.',
              funFact: '🌟 Літера Ґ повернулася в абетку у 1990 році!'
            }
          ]
        }
      ]
    }
  ]
};
