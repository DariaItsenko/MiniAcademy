import { useState, useEffect } from 'react';
import { RotateCw, Sparkles } from 'lucide-react';

interface FullBodyAvatarProps {
  baseAvatar: string; // 'boy', 'girl', 'cat', 'dog'
  skinTone?: string;
  hair?: string;
  clothes?: string;
  accessories?: string[];
  size?: 'small' | 'medium' | 'large';
  showRotation?: boolean;
  animated?: boolean;
  previewItem?: string | null; // Item being previewed (not yet purchased)
}

export function FullBodyAvatar({ 
  baseAvatar, 
  skinTone = 'light',
  hair = 'none',
  clothes = 'none',
  accessories = [],
  size = 'medium',
  showRotation = false,
  animated = true,
  previewItem = null,
}: FullBodyAvatarProps) {
  const [rotation, setRotation] = useState<'front' | 'side' | 'back'>('front');
  const [isBlinking, setIsBlinking] = useState(false);
  const [isWaving, setIsWaving] = useState(false);
  const [itemJustChanged, setItemJustChanged] = useState(false);
  const [autoRotate, setAutoRotate] = useState(false);

  const sizeMap = {
    small: { width: 150, height: 300 },
    medium: { width: 200, height: 400 },
    large: { width: 250, height: 500 },
  };

  const { width, height } = sizeMap[size];

  // Determine which items to show (including preview)
  const displayHair = previewItem?.includes('curly') || previewItem?.includes('long') || previewItem?.includes('short') ? previewItem : hair;
  const displayClothes = previewItem?.includes('shirt') || previewItem?.includes('dress') || previewItem?.includes('hoodie') ? previewItem : clothes;
  const displaySkin = previewItem?.includes('skin-') ? previewItem.replace('skin-', '') : skinTone;
  const displayAccessories = previewItem && (previewItem.includes('glasses') || previewItem.includes('hat') || previewItem.includes('cap') || previewItem.includes('crown') || previewItem.includes('backpack'))
    ? [...accessories, previewItem]
    : accessories;

  // Blinking animation
  useEffect(() => {
    if (!animated) return;
    const blinkInterval = setInterval(() => {
      setIsBlinking(true);
      setTimeout(() => setIsBlinking(false), 150);
    }, 3000 + Math.random() * 2000);
    return () => clearInterval(blinkInterval);
  }, [animated]);

  // Wave animation
  useEffect(() => {
    if (!animated) return;
    const waveInterval = setInterval(() => {
      setIsWaving(true);
      setTimeout(() => setIsWaving(false), 600);
    }, 8000 + Math.random() * 4000);
    return () => clearInterval(waveInterval);
  }, [animated]);

  // Auto-rotation
  useEffect(() => {
    if (!autoRotate) return;
    const rotateInterval = setInterval(() => {
      setRotation(prev => {
        if (prev === 'front') return 'side';
        if (prev === 'side') return 'back';
        return 'front';
      });
    }, 2000);
    return () => clearInterval(rotateInterval);
  }, [autoRotate]);

  // Item change effect
  useEffect(() => {
    setItemJustChanged(true);
    const timer = setTimeout(() => setItemJustChanged(false), 600);
    return () => clearTimeout(timer);
  }, [displayHair, displayClothes, displaySkin, displayAccessories.length]);

  const skinColors = {
    light: '#FFD8B5',
    medium: '#D4A574',
    dark: '#8B5A3C',
    rainbow: 'url(#rainbowGradient)',
  };

  const hairColors = {
    blonde: '#F4E4C1',
    brown: '#8B4513',
    black: '#2C2C2C',
    red: '#C14A09',
    blue: '#4A90E2',
    pink: '#FF69B4',
    green: '#32CD32',
  };

  const rotateAvatar = () => {
    setRotation(prev => {
      if (prev === 'front') return 'side';
      if (prev === 'side') return 'back';
      return 'front';
    });
  };

  const getHairPath = (hairType: string, view: string) => {
    if (hairType === 'none' || hairType === 'short') return null;
    
    const hairStyle = hairType.split('-')[0]; // 'curly', 'long', etc.
    
    if (view === 'front') {
      if (hairStyle === 'curly') {
        return (
          <>
            <ellipse cx={width/2 - 30} cy={height/8} rx="25" ry="30" />
            <ellipse cx={width/2 + 30} cy={height/8} rx="25" ry="30" />
            <path d={`M ${width/2 - 40} ${height/8 - 10} Q ${width/2} ${height/8 - 40} ${width/2 + 40} ${height/8 - 10}`} />
          </>
        );
      } else if (hairStyle === 'long') {
        return (
          <>
            <rect x={width/2 - 50} y={height/8 - 30} width="100" height="120" rx="10" />
            <path d={`M ${width/2 - 50} ${height/8 + 60} L ${width/2 - 55} ${height/4 + 20}`} />
            <path d={`M ${width/2 + 50} ${height/8 + 60} L ${width/2 + 55} ${height/4 + 20}`} />
          </>
        );
      }
    } else if (view === 'side') {
      if (hairStyle === 'curly') {
        return <ellipse cx={width/2 + 10} cy={height/8} rx="35" ry="35" />;
      } else if (hairStyle === 'long') {
        return (
          <>
            <path d={`M ${width/2 - 10} ${height/8 - 20} Q ${width/2 + 30} ${height/8 - 10} ${width/2 + 20} ${height/8 + 80}`} />
            <ellipse cx={width/2 + 15} cy={height/8 + 70} rx="15" ry="25" />
          </>
        );
      }
    } else if (view === 'back') {
      if (hairStyle === 'curly' || hairStyle === 'long') {
        return (
          <>
            <ellipse cx={width/2} cy={height/8 - 10} rx="45" ry="30" />
            {hairStyle === 'long' && (
              <rect x={width/2 - 45} y={height/8} width="90" height="100" rx="10" />
            )}
          </>
        );
      }
    }
    return null;
  };

  const getClothesPath = (clothesType: string, view: string) => {
    if (clothesType === 'none') return null;

    const clothesColor = clothesType.includes('blue') ? '#4A90E2' : 
                         clothesType.includes('red') ? '#E74C3C' :
                         clothesType.includes('green') ? '#2ECC71' :
                         clothesType.includes('pink') ? '#FF69B4' : '#9B59B6';

    if (view === 'front') {
      if (clothesType.includes('shirt') || clothesType.includes('tshirt')) {
        return (
          <g fill={clothesColor}>
            {/* Shirt body */}
            <rect x={width/2 - 45} y={height/4 + 10} width="90" height="80" rx="5" />
            {/* Sleeves */}
            <rect x={width/2 - 70} y={height/4 + 10} width="30" height="50" rx="5" />
            <rect x={width/2 + 40} y={height/4 + 10} width="30" height="50" rx="5" />
            {/* Collar */}
            <path d={`M ${width/2 - 15} ${height/4 + 10} L ${width/2} ${height/4 + 20} L ${width/2 + 15} ${height/4 + 10}`} fill="white" />
          </g>
        );
      } else if (clothesType.includes('dress')) {
        return (
          <g fill={clothesColor}>
            {/* Dress top */}
            <rect x={width/2 - 45} y={height/4 + 10} width="90" height="60" rx="5" />
            {/* Dress skirt */}
            <path d={`M ${width/2 - 45} ${height/4 + 70} L ${width/2 - 60} ${height/2 + 20} L ${width/2 + 60} ${height/2 + 20} L ${width/2 + 45} ${height/4 + 70} Z`} />
            {/* Sleeves */}
            <circle cx={width/2 - 60} cy={height/4 + 30} r="15" opacity="0.8" />
            <circle cx={width/2 + 60} cy={height/4 + 30} r="15" opacity="0.8" />
          </g>
        );
      } else if (clothesType.includes('hoodie')) {
        return (
          <g fill={clothesColor}>
            {/* Hoodie body */}
            <rect x={width/2 - 50} y={height/4 + 10} width="100" height="90" rx="8" />
            {/* Hood */}
            <path d={`M ${width/2 - 35} ${height/4 + 10} Q ${width/2} ${height/8 + 30} ${width/2 + 35} ${height/4 + 10}`} opacity="0.7" />
            {/* Sleeves */}
            <rect x={width/2 - 75} y={height/4 + 10} width="30" height="60" rx="5" />
            <rect x={width/2 + 45} y={height/4 + 10} width="30" height="60" rx="5" />
            {/* Pocket */}
            <rect x={width/2 - 20} y={height/4 + 50} width="40" height="30" rx="3" opacity="0.5" />
          </g>
        );
      }
    } else if (view === 'side') {
      return (
        <g fill={clothesColor}>
          <path d={`M ${width/2 - 20} ${height/4 + 10} L ${width/2 + 30} ${height/4 + 10} L ${width/2 + 25} ${height/4 + 90} L ${width/2 - 15} ${height/4 + 90} Z`} />
          <rect x={width/2 + 25} y={height/4 + 15} width="25" height="45" rx="5" opacity="0.8" />
        </g>
      );
    } else if (view === 'back') {
      if (clothesType.includes('hoodie')) {
        return (
          <g fill={clothesColor}>
            <rect x={width/2 - 50} y={height/4 + 10} width="100" height="90" rx="8" />
            <ellipse cx={width/2} cy={height/8 + 40} rx="40" ry="35" opacity="0.6" />
          </g>
        );
      } else {
        return (
          <g fill={clothesColor}>
            <rect x={width/2 - 45} y={height/4 + 10} width="90" height="80" rx="5" />
          </g>
        );
      }
    }
    return null;
  };

  const getAccessoryPath = (accessory: string, view: string) => {
    if (view === 'back' && !accessory.includes('backpack')) return null;

    if (accessory.includes('glasses')) {
      if (view === 'front') {
        return (
          <g stroke="#333" strokeWidth="3" fill="rgba(200, 230, 255, 0.3)">
            <circle cx={width/2 - 20} cy={height/8 + 5} r="12" />
            <circle cx={width/2 + 20} cy={height/8 + 5} r="12" />
            <line x1={width/2 - 8} y1={height/8 + 5} x2={width/2 + 8} y2={height/8 + 5} />
          </g>
        );
      } else if (view === 'side') {
        return (
          <g stroke="#333" strokeWidth="3" fill="rgba(200, 230, 255, 0.3)">
            <ellipse cx={width/2 + 5} cy={height/8 + 5} rx="15" ry="12" />
            <line x1={width/2 + 20} y1={height/8 + 5} x2={width/2 + 35} y2={height/8 + 3} />
          </g>
        );
      }
    } else if (accessory.includes('hat') || accessory.includes('cap')) {
      if (view === 'front' || view === 'side') {
        return (
          <g fill="#E74C3C">
            {accessory.includes('cap') ? (
              <>
                <ellipse cx={width/2} cy={height/8 - 25} rx="40" ry="20" />
                <rect x={width/2 - 30} y={height/8 - 35} width="60" height="15" rx="8" />
                {view === 'front' && (
                  <ellipse cx={width/2} cy={height/8 - 30} rx="25" ry="8" fill="#C0392B" />
                )}
              </>
            ) : (
              <>
                <path d={`M ${width/2 - 50} ${height/8 - 20} L ${width/2 + 50} ${height/8 - 20} L ${width/2 + 35} ${height/8 - 40} L ${width/2 - 35} ${height/8 - 40} Z`} />
                <ellipse cx={width/2} cy={height/8 - 40} rx="20" ry="10" />
              </>
            )}
          </g>
        );
      } else if (view === 'back') {
        return (
          <g fill="#E74C3C">
            <ellipse cx={width/2} cy={height/8 - 25} rx="45" ry="20" />
          </g>
        );
      }
    } else if (accessory.includes('crown')) {
      if (view === 'front') {
        return (
          <g fill="#FFD700" stroke="#FFA500" strokeWidth="2">
            <path d={`M ${width/2 - 40} ${height/8 - 30} L ${width/2 - 30} ${height/8 - 45} L ${width/2 - 20} ${height/8 - 35} L ${width/2} ${height/8 - 50} L ${width/2 + 20} ${height/8 - 35} L ${width/2 + 30} ${height/8 - 45} L ${width/2 + 40} ${height/8 - 30} L ${width/2 + 35} ${height/8 - 20} L ${width/2 - 35} ${height/8 - 20} Z`} />
            <circle cx={width/2} cy={height/8 - 43} r="4" fill="#FF0000" />
          </g>
        );
      }
    } else if (accessory.includes('backpack')) {
      if (view === 'back') {
        return (
          <g fill="#4A90E2">
            <rect x={width/2 - 35} y={height/4 + 20} width="70" height="60" rx="8" />
            <rect x={width/2 - 30} y={height/4 + 30} width="60" height="40" rx="5" fill="#5AA3F2" />
            <line x1={width/2 - 35} y1={height/4 + 15} x2={width/2 - 50} y2={height/4 + 35} stroke="#3A7BC2" strokeWidth="4" />
            <line x1={width/2 + 35} y1={height/4 + 15} x2={width/2 + 50} y2={height/4 + 35} stroke="#3A7BC2" strokeWidth="4" />
          </g>
        );
      }
    }
    return null;
  };

  return (
    <div className="flex flex-col items-center gap-4">
      <div className={`relative ${itemJustChanged ? 'animate-pulse' : ''}`}>
        {itemJustChanged && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
            <Sparkles className="text-yellow-400 animate-spin" size={48} />
          </div>
        )}
        
        <svg 
          width={width} 
          height={height} 
          viewBox={`0 0 ${width} ${height}`} 
          className="transition-all duration-500"
          style={{
            filter: itemJustChanged ? 'drop-shadow(0 0 20px rgba(255, 215, 0, 0.8))' : 'none',
          }}
        >
          {/* Rainbow gradient definition */}
          <defs>
            <linearGradient id="rainbowGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#FF6B6B">
                <animate attributeName="stop-color" values="#FF6B6B; #FFD93D; #FF6B6B" dur="3s" repeatCount="indefinite" />
              </stop>
              <stop offset="20%" stopColor="#FFD93D">
                <animate attributeName="stop-color" values="#FFD93D; #6BCB77; #FFD93D" dur="3s" repeatCount="indefinite" />
              </stop>
              <stop offset="40%" stopColor="#6BCB77">
                <animate attributeName="stop-color" values="#6BCB77; #4D96FF; #6BCB77" dur="3s" repeatCount="indefinite" />
              </stop>
              <stop offset="60%" stopColor="#4D96FF">
                <animate attributeName="stop-color" values="#4D96FF; #9D84B7; #4D96FF" dur="3s" repeatCount="indefinite" />
              </stop>
              <stop offset="80%" stopColor="#9D84B7">
                <animate attributeName="stop-color" values="#9D84B7; #FF6B9D; #9D84B7" dur="3s" repeatCount="indefinite" />
              </stop>
              <stop offset="100%" stopColor="#FF6B9D">
                <animate attributeName="stop-color" values="#FF6B9D; #FF6B6B; #FF6B9D" dur="3s" repeatCount="indefinite" />
              </stop>
            </linearGradient>
          </defs>

          {/* Body base (depends on base avatar type) */}
          <g className="transition-all duration-300">
            {/* Head */}
            <circle 
              cx={width/2} 
              cy={height/8} 
              r={rotation === 'side' ? 35 : 40} 
              fill={displaySkin === 'rainbow' ? 'url(#rainbowGradient)' : skinColors[displaySkin]} 
              stroke="#8B7355" 
              strokeWidth="2"
              className="transition-all duration-500"
            />
            
            {/* Facial features based on rotation */}
            {rotation === 'front' && (
              <g className="transition-all duration-300">
                {/* Eyes */}
                {baseAvatar === 'cat' || baseAvatar === 'dog' ? (
                  <>
                    <ellipse 
                      cx={width/2 - 15} 
                      cy={height/8} 
                      rx="8" 
                      ry={isBlinking ? "2" : "12"} 
                      fill="#2C3E50"
                      className="transition-all duration-150"
                    />
                    <ellipse 
                      cx={width/2 + 15} 
                      cy={height/8} 
                      rx="8" 
                      ry={isBlinking ? "2" : "12"} 
                      fill="#2C3E50"
                      className="transition-all duration-150"
                    />
                    {!isBlinking && (
                      <>
                        <ellipse cx={width/2 - 15} cy={height/8 + 2} rx="4" ry="6" fill="white">
                          <animate attributeName="opacity" values="1; 0.7; 1" dur="2s" repeatCount="indefinite" />
                        </ellipse>
                        <ellipse cx={width/2 + 15} cy={height/8 + 2} rx="4" ry="6" fill="white">
                          <animate attributeName="opacity" values="1; 0.7; 1" dur="2s" repeatCount="indefinite" />
                        </ellipse>
                      </>
                    )}
                  </>
                ) : (
                  <>
                    <circle 
                      cx={width/2 - 15} 
                      cy={height/8} 
                      r={isBlinking ? 2 : 5} 
                      fill="#2C3E50"
                      className="transition-all duration-150"
                    />
                    <circle 
                      cx={width/2 + 15} 
                      cy={height/8} 
                      r={isBlinking ? 2 : 5} 
                      fill="#2C3E50"
                      className="transition-all duration-150"
                    />
                    {!isBlinking && (
                      <>
                        <circle cx={width/2 - 13} cy={height/8 - 1} r="2" fill="white">
                          <animate attributeName="opacity" values="1; 0.6; 1" dur="2s" repeatCount="indefinite" />
                        </circle>
                        <circle cx={width/2 + 17} cy={height/8 - 1} r="2" fill="white">
                          <animate attributeName="opacity" values="1; 0.6; 1" dur="2s" repeatCount="indefinite" />
                        </circle>
                      </>
                    )}
                  </>
                )}
                
                {/* Nose */}
                {baseAvatar === 'cat' ? (
                  <path d={`M ${width/2} ${height/8 + 12} L ${width/2 - 4} ${height/8 + 18} L ${width/2 + 4} ${height/8 + 18} Z`} fill="#FFB6C1" />
                ) : baseAvatar === 'dog' ? (
                  <ellipse cx={width/2} cy={height/8 + 15} rx="6" ry="8" fill="#2C3E50" />
                ) : (
                  <ellipse cx={width/2} cy={height/8 + 12} rx="3" ry="4" fill="#D4A574" />
                )}
                
                {/* Mouth - animated smile */}
                <path 
                  d={`M ${width/2 - 10} ${height/8 + 20} Q ${width/2} ${height/8 + (itemJustChanged ? 28 : 25)} ${width/2 + 10} ${height/8 + 20}`} 
                  stroke="#2C3E50" 
                  strokeWidth="2" 
                  fill="none"
                  className="transition-all duration-300"
                />
                
                {/* Animal ears */}
                {baseAvatar === 'cat' && (
                  <>
                    <path d={`M ${width/2 - 35} ${height/8 - 30} L ${width/2 - 25} ${height/8 - 50} L ${width/2 - 15} ${height/8 - 30} Z`} fill={displaySkin === 'rainbow' ? 'url(#rainbowGradient)' : skinColors[displaySkin]} stroke="#8B7355" strokeWidth="2">
                      <animateTransform attributeName="transform" type="rotate" values="0 100 50; -5 100 50; 0 100 50" dur="3s" repeatCount="indefinite" />
                    </path>
                    <path d={`M ${width/2 + 35} ${height/8 - 30} L ${width/2 + 25} ${height/8 - 50} L ${width/2 + 15} ${height/8 - 30} Z`} fill={displaySkin === 'rainbow' ? 'url(#rainbowGradient)' : skinColors[displaySkin]} stroke="#8B7355" strokeWidth="2">
                      <animateTransform attributeName="transform" type="rotate" values="0 100 50; 5 100 50; 0 100 50" dur="3s" repeatCount="indefinite" />
                    </path>
                  </>
                )}
                {baseAvatar === 'dog' && (
                  <>
                    <ellipse cx={width/2 - 40} cy={height/8 - 10} rx="15" ry="25" fill={displaySkin === 'rainbow' ? 'url(#rainbowGradient)' : skinColors[displaySkin]} stroke="#8B7355" strokeWidth="2">
                      <animate attributeName="ry" values="25; 28; 25" dur="2s" repeatCount="indefinite" />
                    </ellipse>
                    <ellipse cx={width/2 + 40} cy={height/8 - 10} rx="15" ry="25" fill={displaySkin === 'rainbow' ? 'url(#rainbowGradient)' : skinColors[displaySkin]} stroke="#8B7355" strokeWidth="2">
                      <animate attributeName="ry" values="25; 28; 25" dur="2s" repeatCount="indefinite" />
                    </ellipse>
                  </>
                )}
              </g>
            )}

            {rotation === 'side' && (
              <>
                <circle cx={width/2 + 10} cy={height/8} r={isBlinking ? 2 : 4} fill="#2C3E50" className="transition-all duration-150" />
                {!isBlinking && <circle cx={width/2 + 12} cy={height/8 - 1} r="1.5" fill="white" />}
                <ellipse cx={width/2 + 5} cy={height/8 + 12} rx="2" ry="3" fill="#D4A574" />
                <path d={`M ${width/2 + 8} ${height/8 + 18} Q ${width/2 + 15} ${height/8 + 20} ${width/2 + 12} ${height/8 + 22}`} stroke="#2C3E50" strokeWidth="2" fill="none" />
                
                {baseAvatar === 'cat' && (
                  <path d={`M ${width/2 + 25} ${height/8 - 25} L ${width/2 + 30} ${height/8 - 40} L ${width/2 + 20} ${height/8 - 20} Z`} fill={displaySkin === 'rainbow' ? 'url(#rainbowGradient)' : skinColors[displaySkin]} stroke="#8B7355" strokeWidth="2" />
                )}
                {baseAvatar === 'dog' && (
                  <ellipse cx={width/2 + 35} cy={height/8 - 5} rx="12" ry="20" fill={displaySkin === 'rainbow' ? 'url(#rainbowGradient)' : skinColors[displaySkin]} stroke="#8B7355" strokeWidth="2" />
                )}
              </>
            )}

            {rotation === 'back' && (
              <>
                {/* Just the back of head, maybe some hair */}
              </>
            )}

            {/* Hair - rendered after head but before accessories */}
            {displayHair !== 'none' && (
              <g 
                fill={hairColors[displayHair.split('-')[1] as keyof typeof hairColors] || hairColors.brown}
                className="transition-all duration-500"
                style={{ opacity: itemJustChanged ? 0.7 : 1 }}
              >
                {getHairPath(displayHair, rotation)}
              </g>
            )}

            {/* Neck */}
            <rect 
              x={rotation === 'side' ? width/2 - 10 : width/2 - 15} 
              y={height/8 + 35} 
              width={rotation === 'side' ? 20 : 30} 
              height="20" 
              fill={displaySkin === 'rainbow' ? 'url(#rainbowGradient)' : skinColors[displaySkin]}
              className="transition-all duration-500"
            />

            {/* Torso */}
            <rect 
              x={rotation === 'side' ? width/2 - 25 : width/2 - 50} 
              y={height/4} 
              width={rotation === 'side' ? 50 : 100} 
              height="120" 
              rx="10" 
              fill={displaySkin === 'rainbow' ? 'url(#rainbowGradient)' : skinColors[displaySkin]}
              className="transition-all duration-300"
            >
              {animated && (
                <animate attributeName="height" values="120; 122; 120" dur="3s" repeatCount="indefinite" />
              )}
            </rect>

            {/* Clothes - rendered over torso */}
            <g className="transition-all duration-500" style={{ opacity: itemJustChanged ? 0.7 : 1 }}>
              {getClothesPath(displayClothes, rotation)}
            </g>

            {/* Arms */}
            {rotation === 'front' && (
              <>
                <rect 
                  x={width/2 - 70} 
                  y={height/4 + 10} 
                  width="20" 
                  height="80" 
                  rx="10" 
                  fill={displaySkin === 'rainbow' ? 'url(#rainbowGradient)' : skinColors[displaySkin]}
                  className="transition-all duration-300"
                >
                  {animated && (
                    <animate attributeName="height" values="80; 82; 80" dur="2.5s" repeatCount="indefinite" />
                  )}
                </rect>
                <circle cx={width/2 - 60} cy={height/4 + 95} r="12" fill={displaySkin === 'rainbow' ? 'url(#rainbowGradient)' : skinColors[displaySkin]} />
                
                <rect 
                  x={width/2 + 50} 
                  y={height/4 + 10} 
                  width="20" 
                  height="80" 
                  rx="10" 
                  fill={displaySkin === 'rainbow' ? 'url(#rainbowGradient)' : skinColors[displaySkin]}
                  className="transition-all duration-300"
                  transform={isWaving ? `rotate(-20 ${width/2 + 60} ${height/4 + 10})` : ''}
                >
                  {animated && (
                    <animate attributeName="height" values="80; 82; 80" dur="2.5s" repeatCount="indefinite" />
                  )}
                </rect>
                <circle 
                  cx={width/2 + 60} 
                  cy={height/4 + 95} 
                  r="12" 
                  fill={displaySkin === 'rainbow' ? 'url(#rainbowGradient)' : skinColors[displaySkin]}
                  transform={isWaving ? `rotate(-20 ${width/2 + 60} ${height/4 + 10})` : ''}
                  className="transition-all duration-300"
                />
              </>
            )}

            {rotation === 'side' && (
              <>
                <rect x={width/2 + 20} y={height/4 + 15} width="15" height="70" rx="8" fill={displaySkin === 'rainbow' ? 'url(#rainbowGradient)' : skinColors[displaySkin]} />
                <circle cx={width/2 + 27} cy={height/4 + 90} r="10" fill={displaySkin === 'rainbow' ? 'url(#rainbowGradient)' : skinColors[displaySkin]} />
              </>
            )}

            {/* Legs */}
            <rect 
              x={rotation === 'side' ? width/2 - 15 : width/2 - 40} 
              y={height/2 + 10} 
              width={rotation === 'side' ? 20 : 30} 
              height="100" 
              rx="10" 
              fill="#4A90E2"
              className="transition-all duration-300"
            />
            {rotation === 'front' && (
              <rect x={width/2 + 10} y={height/2 + 10} width="30" height="100" rx="10" fill="#4A90E2" className="transition-all duration-300" />
            )}

            {/* Feet */}
            <ellipse 
              cx={rotation === 'side' ? width/2 - 5 : width/2 - 25} 
              cy={height/2 + 115} 
              rx="18" 
              ry="10" 
              fill="#2C3E50"
            />
            {rotation === 'front' && (
              <ellipse cx={width/2 + 25} cy={height/2 + 115} rx="18" ry="10" fill="#2C3E50" />
            )}

            {/* Accessories - rendered on top */}
            {displayAccessories.map((acc, idx) => (
              <g 
                key={idx} 
                className="transition-all duration-500" 
                style={{ 
                  opacity: itemJustChanged && acc === previewItem ? 0.7 : 1,
                }}
              >
                {getAccessoryPath(acc, rotation)}
              </g>
            ))}
          </g>
        </svg>
      </div>

      {showRotation && (
        <div className="flex gap-4">
          <button
            onClick={rotateAvatar}
            className="flex items-center gap-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white px-6 py-3 rounded-full shadow-lg hover:shadow-xl transition-all transform hover:scale-105 font-bold"
          >
            <RotateCw size={20} />
            Rotate ({rotation})
          </button>
          <button
            onClick={() => setAutoRotate(!autoRotate)}
            className={`flex items-center gap-2 px-6 py-3 rounded-full shadow-lg hover:shadow-xl transition-all transform hover:scale-105 font-bold ${
              autoRotate 
                ? 'bg-gradient-to-r from-green-500 to-blue-500 text-white'
                : 'bg-white text-gray-700 border-4 border-purple-400'
            }`}
          >
            {autoRotate ? '⏸️ Stop' : '▶️ Auto Rotate'}
          </button>
        </div>
      )}
    </div>
  );
}