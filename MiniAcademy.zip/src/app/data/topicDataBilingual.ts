// Bilingual topic data structure
export interface LocalizedText {
  en: string;
  uk: string;
}

export interface WorkedExampleStep {
  stepNumber: number;
  explanation: LocalizedText;
  calculation?: string;
  result?: LocalizedText;
}

export interface WorkedExample {
  id: string;
  title: LocalizedText;
  problem: LocalizedText;
  steps: WorkedExampleStep[];
  finalAnswer: string;
  tips?: LocalizedText[];
}

export interface Lecture {
  id: string;
  title: LocalizedText;
  content: LocalizedText;
  keyPoints: LocalizedText[];
  examples?: string[];
}

export interface Video {
  id: string;
  title: LocalizedText;
  description: LocalizedText;
  thumbnailEmoji: string;
  duration: string;
  url: string;
}

export interface Exercise {
  id: string;
  question: LocalizedText;
  type: 'multiple-choice' | 'input' | 'drag-drop' | 'matching';
  options?: string[];
  correctAnswer: string;
  hint: LocalizedText;
  explanation: LocalizedText;
  funFact?: LocalizedText;
  // For matching type exercises
  matchingPairs?: {
    left: LocalizedText[];
    right: LocalizedText[];
    correctMatches: number[]; // indices mapping left to right
  };
}

export interface Subtopic {
  id: string;
  title: LocalizedText;
  description: LocalizedText;
  emoji: string;
  videos: Video[];
  lectures: Lecture[];
  workedExamples: WorkedExample[];
  exercises: Exercise[];
}

export interface TopicGroup {
  id: string;
  title: LocalizedText;
  description: LocalizedText;
  emoji: string;
  color: string;
  subtopics: Subtopic[];
}

export interface SubjectTopics {
  math: TopicGroup[];
  english: TopicGroup[];
  ukrainian: TopicGroup[];
}

export const bilingualTopicData: SubjectTopics = {
  math: [
    {
      id: 'numbers-operations',
      title: {
        en: 'Numbers & Operations',
        uk: 'Числа та операції'
      },
      description: {
        en: 'Learn about numbers and how to work with them!',
        uk: 'Вивчай числа та дії з ними!'
      },
      emoji: '🔢',
      color: 'from-blue-400 to-blue-600',
      subtopics: [
        {
          id: 'addition',
          title: {
            en: 'Addition',
            uk: 'Додавання'
          },
          description: {
            en: 'Learn how to add numbers together',
            uk: 'Навчись додавати числа'
          },
          emoji: '➕',
          videos: [
            {
              id: 'addition-basics',
              title: {
                en: 'Addition Basics for Beginners',
                uk: 'Основи додавання для початківців'
              },
              description: {
                en: 'Learn what addition means and how to add small numbers',
                uk: 'Дізнайся, що таке додавання та як додавати маленькі числа'
              },
              thumbnailEmoji: '🎬',
              duration: '5:30',
              url: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
            },
            {
              id: 'addition-advanced',
              title: {
                en: 'Adding Bigger Numbers',
                uk: 'Додавання великих чисел'
              },
              description: {
                en: 'Master addition with two-digit numbers',
                uk: 'Опануй додавання двозначних чисел'
              },
              thumbnailEmoji: '🎥',
              duration: '7:15',
              url: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
            }
          ],
          lectures: [
            {
              id: 'addition-lecture',
              title: {
                en: 'Understanding Addition',
                uk: 'Розуміння додавання'
              },
              content: {
                en: `Addition is one of the most basic math operations. When we add, we combine two or more numbers to get a total.

**What is Addition?**
Addition means putting things together. If you have 3 apples and your friend gives you 2 more apples, you now have 5 apples total! We write this as: 3 + 2 = 5

**The Plus Sign (+)**
The plus sign (+) tells us to add numbers together. It's like saying "and" or "plus."

**Addition Facts**
- The numbers we add are called "addends"
- The answer is called the "sum"
- Example: In 4 + 5 = 9, the addends are 4 and 5, and the sum is 9

**Adding in Your Head**
Start with simple numbers and count up! For 6 + 3, start at 6 and count up 3 more: "7, 8, 9"`,
                uk: `Додавання - це одна з найпростіших математичних операцій. Коли ми додаємо, ми об'єднуємо два або більше чисел, щоб отримати загальну суму.

**Що таке додавання?**
Додавання означає складання речей разом. Якщо у тебе є 3 яблука, а друг дає тобі ще 2 яблука, то тепер у тебе 5 яблук! Ми пишемо це так: 3 + 2 = 5

**Знак плюс (+)**
Знак плюс (+) показує нам, що треба додати числа. Це як сказати "та" або "плюс".

**Факти про додавання**
- Числа, які ми додаємо, називаються "доданки"
- Відповідь називається "сума"
- Приклад: У 4 + 5 = 9, доданки це 4 і 5, а сума це 9

**Додавання в умі**
Почни з простих чисел і рахуй далі! Для 6 + 3, почни з 6 і порахуй ще 3: "7, 8, 9"`
              },
              keyPoints: [
                {
                  en: 'Addition means combining numbers',
                  uk: 'Додавання означає об\'єднання чисел'
                },
                {
                  en: 'The + symbol means "add"',
                  uk: 'Символ + означає "додати"'
                },
                {
                  en: 'The answer to addition is called the sum',
                  uk: 'Відповідь при додаванні називається сума'
                },
                {
                  en: 'You can use your fingers or objects to help count',
                  uk: 'Можеш використовувати пальці або предмети для рахунку'
                },
                {
                  en: 'Addition makes numbers bigger',
                  uk: 'Додавання робить числа більшими'
                }
              ],
              examples: [
                '2 + 3 = 5',
                '10 + 5 = 15',
                '7 + 0 = 7'
              ]
            }
          ],
          workedExamples: [
            {
              id: 'example-1',
              title: {
                en: 'Adding Two-Digit Numbers',
                uk: 'Додавання двозначних чисел'
              },
              problem: {
                en: 'What is 23 + 15?',
                uk: 'Скільки буде 23 + 15?'
              },
              steps: [
                {
                  stepNumber: 1,
                  explanation: {
                    en: 'First, line up the numbers by place value (ones and tens)',
                    uk: 'Спочатку вирівняй числа за розрядами (одиниці та десятки)'
                  },
                  calculation: '  23\n+ 15\n----'
                },
                {
                  stepNumber: 2,
                  explanation: {
                    en: 'Add the ones column first: 3 + 5',
                    uk: 'Додай спочатку одиниці: 3 + 5'
                  },
                  calculation: '3 + 5 = 8',
                  result: {
                    en: 'Write 8 in the ones place',
                    uk: 'Запиши 8 у розряді одиниць'
                  }
                },
                {
                  stepNumber: 3,
                  explanation: {
                    en: 'Add the tens column: 2 + 1',
                    uk: 'Додай десятки: 2 + 1'
                  },
                  calculation: '2 + 1 = 3',
                  result: {
                    en: 'Write 3 in the tens place',
                    uk: 'Запиши 3 у розряді десятків'
                  }
                },
                {
                  stepNumber: 4,
                  explanation: {
                    en: 'Combine the results',
                    uk: 'Об\'єднай результати'
                  },
                  calculation: '  23\n+ 15\n----\n  38'
                }
              ],
              finalAnswer: '38',
              tips: [
                {
                  en: 'Always start from the ones column (right side)',
                  uk: 'Завжди починай з розряду одиниць (права сторона)'
                },
                {
                  en: 'Line up numbers carefully',
                  uk: 'Вирівнюй числа акуратно'
                },
                {
                  en: 'Check your work by adding in reverse: 15 + 23 should give the same answer!',
                  uk: 'Перевір свою роботу, додавши навпаки: 15 + 23 має дати ту саму відповідь!'
                }
              ]
            }
          ],
          exercises: [
            {
              id: 'add-1',
              question: {
                en: 'What is 5 + 3?',
                uk: 'Скільки буде 5 + 3?'
              },
              type: 'multiple-choice',
              options: ['6', '7', '8', '9'],
              correctAnswer: '8',
              hint: {
                en: '🤔 Try counting on your fingers! Start with 5, then count up 3 more.',
                uk: '🤔 Спробуй порахувати на пальцях! Почни з 5, потім порахуй ще 3.'
              },
              explanation: {
                en: '5 + 3 = 8! Great job! When you have 5 things and add 3 more, you get 8 total.',
                uk: '5 + 3 = 8! Чудова робота! Коли у тебе є 5 речей і додаєш ще 3, то отримуєш 8 в сумі.'
              },
              funFact: {
                en: '🎉 Did you know? 8 is called a "perfect cube" because 2 × 2 × 2 = 8!',
                uk: '🎉 Чи знаєш? 8 називається "ідеальним кубом", бо 2 × 2 × 2 = 8!'
              }
            },
            {
              id: 'add-2',
              question: {
                en: 'If you have 12 candies and get 7 more, how many do you have?',
                uk: 'Якщо у тебе є 12 цукерок і ти отримуєш ще 7, скільки у тебе буде?'
              },
              type: 'multiple-choice',
              options: ['17', '18', '19', '20'],
              correctAnswer: '19',
              hint: {
                en: '🍬 Count up from 12: add 7 more one at a time!',
                uk: '🍬 Рахуй від 12: додавай 7 по одній!'
              },
              explanation: {
                en: '12 + 7 = 19! You have 19 candies total. Yummy!',
                uk: '12 + 7 = 19! У тебе 19 цукерок загалом. Смачно!'
              },
              funFact: {
                en: '🌟 19 is a prime number - it can only be divided by 1 and itself!',
                uk: '🌟 19 - це просте число. Воно ділиться лише на 1 і на себе!'
              }
            },
            {
              id: 'add-3',
              question: {
                en: 'What is 25 + 34?',
                uk: 'Скільки буде 25 + 34?'
              },
              type: 'input',
              correctAnswer: '59',
              hint: {
                en: '💡 Add the ones first (5 + 4 = 9), then the tens (2 + 3 = 5)',
                uk: '💡 Спочатку додай одиниці (5 + 4 = 9), потім десятки (2 + 3 = 5)'
              },
              explanation: {
                en: '25 + 34 = 59! You added the ones (5+4=9) and tens (2+3=5) correctly!',
                uk: '25 + 34 = 59! Ти правильно додав одиниці (5+4=9) і десятки (2+3=5)!'
              },
              funFact: {
                en: '🚀 59 is another prime number! There are only 15 prime numbers under 50.',
                uk: '🚀 59 - теж просте число! Існує лише 15 простих чисел менше 50.'
              }
            }
          ]
        },
        {
          id: 'subtraction',
          title: {
            en: 'Subtraction',
            uk: 'Віднімання'
          },
          description: {
            en: 'Learn how to subtract and find the difference',
            uk: 'Навчись віднімати і знаходити різницю'
          },
          emoji: '➖',
          videos: [
            {
              id: 'subtraction-basics',
              title: {
                en: 'Subtraction Made Easy',
                uk: 'Віднімання - це легко'
              },
              description: {
                en: 'Understand what subtraction means',
                uk: 'Зрозумій, що таке віднімання'
              },
              thumbnailEmoji: '🎬',
              duration: '6:00',
              url: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
            }
          ],
          lectures: [
            {
              id: 'subtraction-lecture',
              title: {
                en: 'Understanding Subtraction',
                uk: 'Розуміння віднімання'
              },
              content: {
                en: `Subtraction is taking away! When we subtract, we remove some items from a group to find out how many are left.

**What is Subtraction?**
If you have 8 cookies and eat 3 of them, how many are left? We subtract: 8 - 3 = 5 cookies left!

**The Minus Sign (-)**
The minus sign (-) means "take away" or "subtract."

**Subtraction Vocabulary**
- The number you start with is called the "minuend"
- The number you subtract is called the "subtrahend"  
- The answer is called the "difference"`,
                uk: `Віднімання - це забирання! Коли ми віднімаємо, ми забираємо деякі предмети з групи, щоб дізнатися, скільки залишилось.

**Що таке віднімання?**
Якщо у тебе є 8 печива і ти з'їв 3, скільки залишилось? Ми віднімаємо: 8 - 3 = 5 печива залишилось!

**Знак мінус (-)**
Знак мінус (-) означає "забрати" або "відняти".

**Термінологія віднімання**
- Число, з якого віднімають, називається "зменшуване"
- Число, яке віднімають, називається "від'ємник"
- Відповідь називається "різниця"`
              },
              keyPoints: [
                {
                  en: 'Subtraction means taking away',
                  uk: 'Віднімання означає забирання'
                },
                {
                  en: 'The - symbol means "subtract"',
                  uk: 'Символ - означає "відняти"'
                },
                {
                  en: 'Subtraction makes numbers smaller',
                  uk: 'Віднімання робить числа меншими'
                },
                {
                  en: 'You can check subtraction with addition!',
                  uk: 'Можеш перевірити віднімання додаванням!'
                },
                {
                  en: 'The answer is called the difference',
                  uk: 'Відповідь називається різниця'
                }
              ],
              examples: [
                '10 - 3 = 7',
                '15 - 5 = 10',
                '8 - 0 = 8'
              ]
            }
          ],
          workedExamples: [
            {
              id: 'sub-example-1',
              title: {
                en: 'Simple Subtraction',
                uk: 'Просте віднімання'
              },
              problem: {
                en: 'What is 45 - 23?',
                uk: 'Скільки буде 45 - 23?'
              },
              steps: [
                {
                  stepNumber: 1,
                  explanation: {
                    en: 'Line up the numbers',
                    uk: 'Вирівняй числа'
                  },
                  calculation: '  45\n- 23\n----'
                },
                {
                  stepNumber: 2,
                  explanation: {
                    en: 'Subtract ones: 5 - 3',
                    uk: 'Віднімаємо одиниці: 5 - 3'
                  },
                  calculation: '5 - 3 = 2'
                },
                {
                  stepNumber: 3,
                  explanation: {
                    en: 'Subtract tens: 4 - 2',
                    uk: 'Віднімаємо десятки: 4 - 2'
                  },
                  calculation: '4 - 2 = 2'
                }
              ],
              finalAnswer: '22',
              tips: [
                {
                  en: 'Always start from the ones place',
                  uk: 'Завжди починай з розряду одиниць'
                },
                {
                  en: 'Check with addition: 22 + 23 = 45 ✓',
                  uk: 'Перевір додаванням: 22 + 23 = 45 ✓'
                }
              ]
            }
          ],
          exercises: [
            {
              id: 'sub-1',
              question: {
                en: 'What is 9 - 4?',
                uk: 'Скільки буде 9 - 4?'
              },
              type: 'multiple-choice',
              options: ['3', '4', '5', '6'],
              correctAnswer: '5',
              hint: {
                en: '🖐️ Start with 9 and count back 4: 8, 7, 6, 5...',
                uk: '🖐️ Почни з 9 і рахуй назад 4: 8, 7, 6, 5...'
              },
              explanation: {
                en: '9 - 4 = 5! Perfect! When you take 4 away from 9, you have 5 left.',
                uk: '9 - 4 = 5! Чудово! Коли ти забираєш 4 з 9, залишається 5.'
              },
              funFact: {
                en: '⭐ 5 is the number of fingers on one hand!',
                uk: '⭐ 5 - це кількість пальців на одній руці!'
              }
            }
          ]
        },
        {
          id: 'multiplication',
          title: {
            en: 'Multiplication',
            uk: 'Множення'
          },
          description: {
            en: 'Master multiplication tables and repeated addition',
            uk: 'Опануй таблицю множення та повторне додавання'
          },
          emoji: '✖️',
          videos: [
            {
              id: 'mult-intro',
              title: {
                en: 'Introduction to Multiplication',
                uk: 'Знайомство з множенням'
              },
              description: {
                en: 'Learn what multiplication really means',
                uk: 'Дізнайся, що насправді означає множення'
              },
              thumbnailEmoji: '🎬',
              duration: '8:00',
              url: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
            }
          ],
          lectures: [
            {
              id: 'mult-lecture',
              title: {
                en: 'Understanding Multiplication',
                uk: 'Розуміння множення'
              },
              content: {
                en: `Multiplication is a fast way to add the same number many times!

**What is Multiplication?**
Instead of adding 3 + 3 + 3 + 3, we can multiply: 4 × 3 = 12
This means "4 groups of 3" or "3 added 4 times"

**The Times Sign (×)**
The × symbol means "times" or "multiply."

**Multiplication Makes Math Faster!**
- 2 + 2 + 2 + 2 + 2 = 10 (slow way)
- 5 × 2 = 10 (fast way!)`,
                uk: `Множення - це швидкий спосіб додати одне і те саме число багато разів!

**Що таке множення?**
Замість того, щоб додавати 3 + 3 + 3 + 3, ми можемо помножити: 4 × 3 = 12
Це означає "4 групи по 3" або "3 додане 4 рази"

**Знак множення (×)**
Символ × означає "помножити" або "рази".

**Множення робить математику швидшою!**
- 2 + 2 + 2 + 2 + 2 = 10 (повільний спосіб)
- 5 × 2 = 10 (швидкий спосіб!)`
              },
              keyPoints: [
                {
                  en: 'Multiplication is repeated addition',
                  uk: 'Множення - це повторне додавання'
                },
                {
                  en: 'The × symbol means multiply',
                  uk: 'Символ × означає помножити'
                },
                {
                  en: 'Learn your times tables!',
                  uk: 'Вивчи таблицю множення!'
                },
                {
                  en: 'Order doesn\'t matter: 3×4 = 4×3',
                  uk: 'Порядок не має значення: 3×4 = 4×3'
                },
                {
                  en: 'Any number times 0 equals 0',
                  uk: 'Будь-яке число помножене на 0 дорівнює 0'
                }
              ],
              examples: [
                '3 × 4 = 12',
                '5 × 2 = 10',
                '7 × 1 = 7'
              ]
            }
          ],
          workedExamples: [
            {
              id: 'mult-example',
              title: {
                en: 'Multiplication Tables',
                uk: 'Таблиця множення'
              },
              problem: {
                en: 'What is 6 × 7?',
                uk: 'Скільки буде 6 × 7?'
              },
              steps: [
                {
                  stepNumber: 1,
                  explanation: {
                    en: 'Think of it as 6 groups of 7',
                    uk: 'Подумай про це як про 6 груп по 7'
                  },
                  calculation: '7 + 7 + 7 + 7 + 7 + 7'
                },
                {
                  stepNumber: 2,
                  explanation: {
                    en: 'Or use the times table you memorized!',
                    uk: 'Або використай таблицю множення, яку вивчив!'
                  },
                  calculation: '6 × 7 = 42'
                }
              ],
              finalAnswer: '42',
              tips: [
                {
                  en: 'Practice times tables daily',
                  uk: 'Практикуй таблицю множення щодня'
                },
                {
                  en: 'Use skip counting: 7, 14, 21, 28, 35, 42!',
                  uk: 'Використовуй лічбу через один: 7, 14, 21, 28, 35, 42!'
                }
              ]
            }
          ],
          exercises: [
            {
              id: 'mult-1',
              question: {
                en: 'What is 5 × 3?',
                uk: 'Скільки буде 5 × 3?'
              },
              type: 'multiple-choice',
              options: ['12', '13', '15', '18'],
              correctAnswer: '15',
              hint: {
                en: '🔢 Count by 5s three times: 5, 10, 15!',
                uk: '🔢 Рахуй п\'ятірками три рази: 5, 10, 15!'
              },
              explanation: {
                en: '5 × 3 = 15! That means 5 + 5 + 5 = 15. Awesome!',
                uk: '5 × 3 = 15! Це означає 5 + 5 + 5 = 15. Чудово!'
              },
              funFact: {
                en: '🎯 15 minutes is a quarter of an hour!',
                uk: '🎯 15 хвилин - це чверть години!'
              }
            }
          ]
        }
      ]
    },
    {
      id: 'geometry',
      title: {
        en: 'Shapes & Geometry',
        uk: 'Фігури і геометрія'
      },
      description: {
        en: 'Explore shapes, patterns, and spatial reasoning',
        uk: 'Вивчай фігури, візерунки та просторове мислення'
      },
      emoji: '📐',
      color: 'from-purple-400 to-purple-600',
      subtopics: [
        {
          id: 'basic-shapes',
          title: {
            en: 'Basic Shapes',
            uk: 'Основні фігури'
          },
          description: {
            en: 'Learn about circles, squares, triangles and more!',
            uk: 'Вивчай кола, квадрати, трикутники та інше!'
          },
          emoji: '🔷',
          videos: [
            {
              id: 'shapes-video',
              title: {
                en: 'All About Shapes',
                uk: 'Все про фігури'
              },
              description: {
                en: 'Discover different shapes around us',
                uk: 'Відкрий для себе різні фігури навколо нас'
              },
              thumbnailEmoji: '🎬',
              duration: '5:00',
              url: 'https://www.youtube.com/embed/dQw4w9WgXcQ'
            }
          ],
          lectures: [
            {
              id: 'shapes-lecture',
              title: {
                en: 'Understanding Shapes',
                uk: 'Розуміння фігур'
              },
              content: {
                en: `Shapes are all around us! Let's learn about the most common shapes.

**Circle ⭕**
A circle is perfectly round with no corners. Examples: wheels, coins, pizza!

**Square ◻️**
A square has 4 equal sides and 4 corners. Examples: windows, crackers, chess board!

**Triangle 🔺**
A triangle has 3 sides and 3 corners. Examples: pizza slice, road signs, pyramids!`,
                uk: `Фігури навколо нас скрізь! Давай вивчимо найпоширеніші фігури.

**Коло ⭕**
Коло ідеально кругле, без кутів. Приклади: колеса, монети, піца!

**Квадрат ◻️**
Квадрат має 4 однакові сторони і 4 кути. Приклади: вікна, крекери, шахівниця!

**Трикутник 🔺**
Трикутник має 3 сторони і 3 кути. Приклади: шматочок піци, дорожні знаки, піраміди!`
              },
              keyPoints: [
                {
                  en: 'Circles are round with no corners',
                  uk: 'Кола круглі без кутів'
                },
                {
                  en: 'Squares have 4 equal sides',
                  uk: 'Квадрати мають 4 однакові сторони'
                },
                {
                  en: 'Triangles have 3 sides',
                  uk: 'Трикутники мають 3 сторони'
                },
                {
                  en: 'Look for shapes everywhere around you!',
                  uk: 'Шукай фігури скрізь навколо себе!'
                }
              ]
            }
          ],
          workedExamples: [],
          exercises: [
            {
              id: 'shapes-1',
              question: {
                en: 'Which shape has no corners?',
                uk: 'Яка фігура не має кутів?'
              },
              type: 'multiple-choice',
              options: ['Square', 'Triangle', 'Circle', 'Rectangle'],
              correctAnswer: 'Circle',
              hint: {
                en: '⭕ Think about something that rolls!',
                uk: '⭕ Подумай про щось, що котиться!'
              },
              explanation: {
                en: 'A circle has no corners! It\'s perfectly round and smooth.',
                uk: 'Коло не має кутів! Воно ідеально кругле і гладеньке.'
              },
              funFact: {
                en: '🍕 Pizzas are circles, but we cut them into triangular slices!',
                uk: '🍕 Піци - це кола, але ми ріжемо їх на трикутні шматочки!'
              }
            }
          ]
        }
      ]
    }
  ],
  english: [
    {
      id: 'phonics-reading',
      title: {
        en: 'Phonics & Reading',
        uk: 'Фонетика і читання'
      },
      description: {
        en: 'Learn sounds, letters, and how to read!',
        uk: 'Вивчай звуки, літери і як читати!'
      },
      emoji: '📖',
      color: 'from-green-400 to-green-600',
      subtopics: [
        {
          id: 'alphabet',
          title: {
            en: 'The Alphabet',
            uk: 'Алфавіт'
          },
          description: {
            en: 'Learn all 26 letters and their sounds',
            uk: 'Вивчи всі 26 літер та їх звуки'
          },
          emoji: '🔤',
          videos: [],
          lectures: [],
          workedExamples: [],
          exercises: []
        }
      ]
    }
  ],
  ukrainian: [
    {
      id: 'ukrainian-alphabet',
      title: {
        en: 'Ukrainian Alphabet',
        uk: 'Українська абетка'
      },
      description: {
        en: 'Learn Ukrainian letters and sounds',
        uk: 'Вивчай українські літери та звуки'
      },
      emoji: '🇺🇦',
      color: 'from-yellow-400 to-blue-500',
      subtopics: [
        {
          id: 'cyrillic-letters',
          title: {
            en: 'Cyrillic Letters',
            uk: 'Кирилиця'
          },
          description: {
            en: 'Ukrainian alphabet - 33 letters',
            uk: 'Український алфавіт - 33 літери'
          },
          emoji: '📝',
          videos: [],
          lectures: [],
          workedExamples: [],
          exercises: [
            {
              id: 'uk-1',
              question: {
                en: 'How many letters are in the Ukrainian alphabet?',
                uk: 'Скільки літер в українській абетці?'
              },
              type: 'multiple-choice',
              options: ['26', '30', '33', '35'],
              correctAnswer: '33',
              hint: {
                en: '🇺🇦 The Ukrainian alphabet is bigger than the English one!',
                uk: '🇺🇦 Українська абетка більша за англійську!'
              },
              explanation: {
                en: 'Correct! There are 33 letters in the Ukrainian alphabet.',
                uk: 'Правильно! В українській абетці 33 літери.'
              },
              funFact: {
                en: '🌟 The letter Ґ was restored to the alphabet in 1990!',
                uk: '🌟 Літера Ґ повернулася в абетку у 1990 році!'
              }
            }
          ]
        }
      ]
    }
  ]
};