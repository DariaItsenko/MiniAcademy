import { useState } from "react";
import { Plus, Edit2, Trash2, Save } from "lucide-react";

interface Task {
  id: string;
  question: string;
  options?: string[];
  correctAnswer: string;
  type: 'multiple-choice' | 'text-input';
}

interface AdminTaskManagerProps {
  subject: string;
}

export function AdminTaskManager({ subject }: AdminTaskManagerProps) {
  const [selectedLevel, setSelectedLevel] = useState(0);
  
  // Get number of levels for this subject
  const getLevelCount = () => {
    const levelData = localStorage.getItem("admin_level_data");
    if (!levelData) return 4;
    const data = JSON.parse(levelData);
    return data[subject]?.length || 4;
  };

  const levelCount = getLevelCount();
  const storageKey = `admin_tasks_${subject}_${selectedLevel}`;
  
  const [tasks, setTasks] = useState<Task[]>(() => {
    const stored = localStorage.getItem(storageKey);
    return stored ? JSON.parse(stored) : [];
  });

  const [newTask, setNewTask] = useState<Task>({
    id: '',
    question: '',
    options: ['', '', '', ''],
    correctAnswer: '',
    type: 'multiple-choice',
  });

  const [editingId, setEditingId] = useState<string | null>(null);

  const saveTasks = (updatedTasks: Task[]) => {
    localStorage.setItem(storageKey, JSON.stringify(updatedTasks));
    setTasks(updatedTasks);
  };

  const handleAddTask = () => {
    if (!newTask.question || !newTask.correctAnswer) {
      alert('Please fill in question and correct answer');
      return;
    }

    if (newTask.type === 'multiple-choice' && newTask.options?.some(opt => !opt)) {
      alert('Please fill in all options');
      return;
    }

    const taskToAdd = {
      ...newTask,
      id: Date.now().toString(),
      options: newTask.type === 'multiple-choice' ? newTask.options : undefined,
    };

    saveTasks([...tasks, taskToAdd]);
    setNewTask({
      id: '',
      question: '',
      options: ['', '', '', ''],
      correctAnswer: '',
      type: 'multiple-choice',
    });
  };

  const handleDeleteTask = (id: string) => {
    if (confirm('Delete this task?')) {
      saveTasks(tasks.filter(t => t.id !== id));
    }
  };

  const handleEditTask = (task: Task) => {
    setEditingId(task.id);
    setNewTask({ ...task });
  };

  const handleUpdateTask = () => {
    if (!newTask.question || !newTask.correctAnswer) {
      alert('Please fill in question and correct answer');
      return;
    }

    saveTasks(tasks.map(t => t.id === editingId ? { ...newTask, id: editingId } : t));
    setEditingId(null);
    setNewTask({
      id: '',
      question: '',
      options: ['', '', '', ''],
      correctAnswer: '',
      type: 'multiple-choice',
    });
  };

  return (
    <div className="bg-gradient-to-r from-indigo-50 to-purple-50 p-6 rounded-2xl shadow-md mb-6">
      <h3 className="text-2xl font-bold text-gray-800 mb-4 flex items-center gap-2">
        📝 Tasks for Level {selectedLevel + 1}
      </h3>

      {/* Level Selector */}
      <div className="mb-4">
        <label className="block text-sm font-bold text-gray-700 mb-2">Select Level</label>
        <select
          value={selectedLevel}
          onChange={(e) => setSelectedLevel(parseInt(e.target.value))}
          className="w-full p-3 border-2 border-gray-300 rounded-lg focus:border-purple-500 focus:outline-none"
        >
          {Array.from({ length: levelCount }, (_, i) => (
            <option key={i} value={i}>{i + 1}</option>
          ))}
        </select>
      </div>

      {/* Existing Tasks */}
      <div className="space-y-3 mb-6">
        {tasks.map((task, index) => (
          <div key={task.id} className="bg-white p-4 rounded-xl shadow-sm border-2 border-purple-200">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span className="bg-purple-500 text-white font-bold px-3 py-1 rounded-full text-xs">
                    Q{index + 1}
                  </span>
                  <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-xs font-medium">
                    {task.type}
                  </span>
                </div>
                <p className="font-semibold text-gray-800 mb-2">{task.question}</p>
                {task.options && (
                  <div className="text-sm text-gray-600 ml-4">
                    {task.options.map((opt, i) => (
                      <div key={i} className={opt === task.correctAnswer ? 'text-green-600 font-bold' : ''}>
                        • {opt} {opt === task.correctAnswer && '✓'}
                      </div>
                    ))}
                  </div>
                )}
                {!task.options && (
                  <p className="text-sm text-green-600 font-semibold ml-4">Answer: {task.correctAnswer}</p>
                )}
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => handleEditTask(task)}
                  className="p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
                >
                  <Edit2 size={16} />
                </button>
                <button
                  onClick={() => handleDeleteTask(task.id)}
                  className="p-2 bg-red-500 text-white rounded-lg hover:bg-red-600"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          </div>
        ))}
        {tasks.length === 0 && (
          <p className="text-center text-gray-500 py-4">No tasks yet. Add your first task below!</p>
        )}
      </div>

      {/* Add/Edit Task Form */}
      <div className="bg-white p-6 rounded-xl shadow-md border-4 border-purple-300">
        <h4 className="text-xl font-bold text-gray-800 mb-4">
          {editingId ? '✏️ Edit Task' : '➕ Add New Task'}
        </h4>

        {/* Task Type */}
        <div className="mb-4">
          <label className="block text-sm font-bold text-gray-700 mb-2">Task Type</label>
          <div className="flex gap-4">
            <button
              onClick={() => setNewTask({ ...newTask, type: 'multiple-choice', options: ['', '', '', ''] })}
              className={`px-4 py-2 rounded-lg font-medium ${
                newTask.type === 'multiple-choice'
                  ? 'bg-purple-500 text-white'
                  : 'bg-gray-200 text-gray-700'
              }`}
            >
              Multiple Choice
            </button>
            <button
              onClick={() => setNewTask({ ...newTask, type: 'text-input', options: undefined })}
              className={`px-4 py-2 rounded-lg font-medium ${
                newTask.type === 'text-input'
                  ? 'bg-purple-500 text-white'
                  : 'bg-gray-200 text-gray-700'
              }`}
            >
              Text Input
            </button>
          </div>
        </div>

        {/* Question */}
        <div className="mb-4">
          <label className="block text-sm font-bold text-gray-700 mb-2">Question</label>
          <textarea
            value={newTask.question}
            onChange={(e) => setNewTask({ ...newTask, question: e.target.value })}
            className="w-full p-3 border-2 border-gray-300 rounded-lg focus:border-purple-500 focus:outline-none"
            rows={2}
            placeholder="Enter your question..."
          />
        </div>

        {/* Options (for multiple choice) */}
        {newTask.type === 'multiple-choice' && (
          <div className="mb-4">
            <label className="block text-sm font-bold text-gray-700 mb-2">Options</label>
            <div className="space-y-2">
              {newTask.options?.map((opt, i) => (
                <input
                  key={i}
                  type="text"
                  value={opt}
                  onChange={(e) => {
                    const newOpts = [...(newTask.options || [])];
                    newOpts[i] = e.target.value;
                    setNewTask({ ...newTask, options: newOpts });
                  }}
                  className="w-full p-3 border-2 border-gray-300 rounded-lg focus:border-purple-500 focus:outline-none"
                  placeholder={`Option ${i + 1}`}
                />
              ))}
            </div>
          </div>
        )}

        {/* Correct Answer */}
        <div className="mb-4">
          <label className="block text-sm font-bold text-gray-700 mb-2">Correct Answer</label>
          {newTask.type === 'multiple-choice' ? (
            <select
              value={newTask.correctAnswer}
              onChange={(e) => setNewTask({ ...newTask, correctAnswer: e.target.value })}
              className="w-full p-3 border-2 border-gray-300 rounded-lg focus:border-purple-500 focus:outline-none"
            >
              <option value="">Select correct option...</option>
              {newTask.options?.filter(opt => opt).map((opt, i) => (
                <option key={i} value={opt}>{opt}</option>
              ))}
            </select>
          ) : (
            <input
              type="text"
              value={newTask.correctAnswer}
              onChange={(e) => setNewTask({ ...newTask, correctAnswer: e.target.value })}
              className="w-full p-3 border-2 border-gray-300 rounded-lg focus:border-purple-500 focus:outline-none"
              placeholder="Enter correct answer..."
            />
          )}
        </div>

        <button
          onClick={editingId ? handleUpdateTask : handleAddTask}
          className="w-full bg-gradient-to-r from-green-500 to-blue-500 text-white font-bold py-3 px-6 rounded-xl hover:from-green-600 hover:to-blue-600 transition-all flex items-center justify-center gap-2"
        >
          {editingId ? <><Save size={20} /> Update Task</> : <><Plus size={20} /> Add Task</>}
        </button>

        {editingId && (
          <button
            onClick={() => {
              setEditingId(null);
              setNewTask({
                id: '',
                question: '',
                options: ['', '', '', ''],
                correctAnswer: '',
                type: 'multiple-choice',
              });
            }}
            className="w-full mt-2 bg-gray-300 text-gray-700 font-bold py-2 px-6 rounded-xl hover:bg-gray-400"
          >
            Cancel
          </button>
        )}
      </div>
    </div>
  );
}