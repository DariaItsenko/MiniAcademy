import { useState, useEffect } from 'react';
import { CheckCircle, XCircle } from 'lucide-react';

interface Question {
  question: string;
  answer: string;
  options: string[];
  type: 'word' | 'sentence' | 'grammar';
}

interface EnglishExerciseProps {
  level: number;
  onComplete: (stars: number) => void;
}

const generateQuestions = (level: number): Question[] => {
  const questions: Question[] = [];
  
  const level1Questions = [
    { question: 'Which letter makes the "A" sound?', answer: 'A', options: ['A', 'B', 'C', 'D'], type: 'word' as const },
    { question: 'What sound does "C" make in "Cat"?', answer: '/k/', options: ['/k/', '/s/', '/t/', '/ch/'], type: 'word' as const },
    { question: 'Choose the word: Picture of 🐕', answer: 'dog', options: ['dog', 'cat', 'bird', 'fish'], type: 'word' as const },
    { question: 'Which word starts with "B"?', answer: 'Ball', options: ['Ball', 'Apple', 'Cat', 'Door'], type: 'word' as const },
    { question: 'What is this? 🌞', answer: 'sun', options: ['sun', 'moon', 'star', 'cloud'], type: 'word' as const },
    { question: 'Pick the correct word: 📕', answer: 'book', options: ['book', 'pen', 'desk', 'chair'], type: 'word' as const },
    { question: 'Which letter comes after "M"?', answer: 'N', options: ['N', 'L', 'O', 'K'], type: 'word' as const },
    { question: 'What rhymes with "cat"?', answer: 'hat', options: ['hat', 'dog', 'car', 'top'], type: 'word' as const },
    { question: 'Choose the vowel:', answer: 'E', options: ['E', 'B', 'C', 'D'], type: 'word' as const },
    { question: 'Which word means 🏠?', answer: 'house', options: ['house', 'tree', 'car', 'school'], type: 'word' as const }
  ];

  const level2Questions = [
    { question: 'Complete: The cat ___ on the mat.', answer: 'sat', options: ['sat', 'run', 'jump', 'fly'], type: 'sentence' as const },
    { question: 'Which sentence is correct?', answer: 'I like apples.', options: ['I like apples.', 'like I apples.', 'apples I like.', 'I apples like.'], type: 'sentence' as const },
    { question: 'What comes next? I see a ___', answer: 'dog', options: ['dog', 'runs', 'happy', 'and'], type: 'sentence' as const },
    { question: 'Choose the correct sentence:', answer: 'She is happy.', options: ['She is happy.', 'She happy is.', 'Is she happy.', 'Happy she is.'], type: 'sentence' as const },
    { question: 'The dog ___ fast.', answer: 'runs', options: ['runs', 'run', 'running', 'ran'], type: 'sentence' as const },
    { question: 'I ___ to school.', answer: 'go', options: ['go', 'goes', 'going', 'went'], type: 'sentence' as const },
    { question: 'Which is a complete sentence?', answer: 'Birds can fly.', options: ['Birds can fly.', 'Birds fly can.', 'Can birds fly.', 'Fly birds can.'], type: 'sentence' as const },
    { question: 'The sun is ___', answer: 'bright', options: ['bright', 'run', 'eat', 'walk'], type: 'sentence' as const },
    { question: '___ are you?', answer: 'How', options: ['How', 'What', 'Run', 'Jump'], type: 'sentence' as const },
    { question: 'I have ___ pencils.', answer: 'two', options: ['two', 'to', 'too', 'tue'], type: 'sentence' as const }
  ];

  const level3Questions = [
    { question: 'Once upon a time, there was a ___ princess.', answer: 'beautiful', options: ['beautiful', 'beauty', 'beautify', 'beautifully'], type: 'grammar' as const },
    { question: 'The boy ___ his homework yesterday.', answer: 'did', options: ['did', 'do', 'does', 'doing'], type: 'grammar' as const },
    { question: 'Choose the noun:', answer: 'table', options: ['table', 'run', 'happy', 'quickly'], type: 'grammar' as const },
    { question: 'Which word is a verb?', answer: 'jump', options: ['jump', 'tree', 'blue', 'happy'], type: 'grammar' as const },
    { question: 'My story has a beginning, middle, and ___', answer: 'end', options: ['end', 'start', 'top', 'side'], type: 'grammar' as const },
    { question: 'Choose the adjective:', answer: 'big', options: ['big', 'run', 'dog', 'quickly'], type: 'grammar' as const },
    { question: 'She ___ to the store tomorrow.', answer: 'will go', options: ['will go', 'went', 'goes', 'going'], type: 'grammar' as const },
    { question: 'Add punctuation: I like pizza___', answer: '.', options: ['.', '?', '!', ','], type: 'grammar' as const },
    { question: 'Which is plural?', answer: 'cats', options: ['cats', 'cat', 'cating', 'catting'], type: 'grammar' as const },
    { question: 'The ___ are playing in the park.', answer: 'children', options: ['children', 'child', 'childs', 'childrens'], type: 'grammar' as const }
  ];

  const level4Questions = [
    { question: 'Choose the correct tense: Yesterday, I ___ to school.', answer: 'went', options: ['went', 'go', 'will go', 'going'], type: 'grammar' as const },
    { question: 'Which sentence has correct punctuation?', answer: 'Hello, how are you?', options: ['Hello, how are you?', 'Hello how are you.', 'hello, how are you?', 'Hello how are you'], type: 'grammar' as const },
    { question: 'Choose the synonym for "happy":', answer: 'joyful', options: ['joyful', 'sad', 'angry', 'tired'], type: 'grammar' as const },
    { question: 'Which word is an adverb?', answer: 'quickly', options: ['quickly', 'quick', 'quicker', 'quickness'], type: 'grammar' as const },
    { question: 'Fix the sentence: he dont like apples', answer: 'He doesn\'t like apples.', options: ['He doesn\'t like apples.', 'he dont like apples.', 'He don\'t like apples.', 'he doesn\'t like apples'], type: 'grammar' as const },
    { question: 'Which is the past tense of "run"?', answer: 'ran', options: ['ran', 'runned', 'running', 'runs'], type: 'grammar' as const },
    { question: 'Choose the possessive form:', answer: 'Sarah\'s', options: ['Sarah\'s', 'Sarahs', 'Sarah', 'Sarahs\''], type: 'grammar' as const },
    { question: 'Which is a compound sentence?', answer: 'I like pizza, and she likes pasta.', options: ['I like pizza, and she likes pasta.', 'I like pizza.', 'She likes pasta.', 'Pizza and pasta.'], type: 'grammar' as const },
    { question: 'Choose the antonym for "big":', answer: 'small', options: ['small', 'large', 'huge', 'giant'], type: 'grammar' as const },
    { question: 'Which is correct?', answer: 'They\'re going to their house.', options: ['They\'re going to their house.', 'Their going to they\'re house.', 'There going to their house.', 'They\'re going to there house.'], type: 'grammar' as const }
  ];

  switch (level) {
    case 1:
      questions.push(...level1Questions);
      break;
    case 2:
      questions.push(...level2Questions);
      break;
    case 3:
      questions.push(...level3Questions);
      break;
    default:
      questions.push(...level4Questions);
  }
  
  return questions;
};

export function EnglishExercise({ level, onComplete }: EnglishExerciseProps) {
  const [questions] = useState<Question[]>(generateQuestions(level));
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);

  const handleAnswer = (answer: string) => {
    setSelectedAnswer(answer);
    const correct = answer === questions[currentQuestion].answer;
    setIsCorrect(correct);
    
    if (correct) {
      setScore(score + 1);
    }

    setTimeout(() => {
      if (currentQuestion < questions.length - 1) {
        setCurrentQuestion(currentQuestion + 1);
        setSelectedAnswer(null);
        setIsCorrect(null);
      } else {
        setShowResult(true);
      }
    }, 1000);
  };

  useEffect(() => {
    if (showResult) {
      const stars = score >= 9 ? 3 : score >= 7 ? 2 : score >= 5 ? 1 : 0;
      setTimeout(() => onComplete(stars), 2000);
    }
  }, [showResult, score, onComplete]);

  if (showResult) {
    const stars = score >= 9 ? 3 : score >= 7 ? 2 : score >= 5 ? 1 : 0;
    
    return (
      <div className="text-center py-12">
        <div className="mb-8">
          <div className="text-6xl mb-4">
            {stars === 3 ? '🌟🌟🌟' : stars === 2 ? '🌟🌟' : stars === 1 ? '🌟' : '📚'}
          </div>
          <h2 className="text-3xl font-bold text-gray-800 mb-2">
            {stars === 3 ? 'Excellent!' : stars === 2 ? 'Great Job!' : stars === 1 ? 'Good Try!' : 'Keep Practicing!'}
          </h2>
          <p className="text-xl text-gray-600">
            You scored {score} out of {questions.length}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto">
      <div className="mb-6">
        <div className="flex justify-between text-sm text-gray-600 mb-2">
          <span>Question {currentQuestion + 1} of {questions.length}</span>
          <span>Score: {score}/{questions.length}</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div
            className="bg-gradient-to-r from-green-500 to-teal-500 h-2 rounded-full transition-all"
            style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
          />
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-lg p-8 mb-6">
        <h3 className="text-2xl font-bold text-gray-800 mb-8 text-center">
          {questions[currentQuestion].question}
        </h3>

        <div className="grid grid-cols-1 gap-4">
          {questions[currentQuestion].options.map((option, index) => (
            <button
              key={index}
              onClick={() => handleAnswer(option)}
              disabled={selectedAnswer !== null}
              className={`p-4 rounded-lg font-semibold text-lg transition-all ${
                selectedAnswer === option
                  ? isCorrect
                    ? 'bg-green-500 text-white'
                    : 'bg-red-500 text-white'
                  : 'bg-gray-100 hover:bg-gray-200 text-gray-800'
              } ${selectedAnswer !== null ? 'cursor-not-allowed' : 'hover:shadow-md'}`}
            >
              <div className="flex items-center justify-between">
                <span>{option}</span>
                {selectedAnswer === option && (
                  isCorrect ? <CheckCircle size={24} /> : <XCircle size={24} />
                )}
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
