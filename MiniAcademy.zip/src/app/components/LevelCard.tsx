import { Star, Lock, CheckCircle, Video } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface LevelCardProps {
  level: number;
  title: string;
  description: string;
  status: 'locked' | 'available' | 'completed';
  stars: number;
  totalStars: number;
  videoUrl?: string;
  onStart?: () => void;
  onWatchVideo?: () => void;
}

export function LevelCard({ level, title, description, status, stars, totalStars, videoUrl, onStart, onWatchVideo }: LevelCardProps) {
  const { t } = useLanguage();
  const bgColor = status === 'locked' ? 'bg-gray-200' : status === 'completed' ? 'bg-green-50' : 'bg-blue-50';
  const borderColor = status === 'locked' ? 'border-gray-300' : status === 'completed' ? 'border-green-300' : 'border-blue-300';
  
  return (
    <div className={`${bgColor} ${borderColor} border-2 rounded-xl p-6 transition-all`}>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-3">
          <div className={`w-12 h-12 rounded-full flex items-center justify-center font-bold text-xl ${
            status === 'locked' ? 'bg-gray-300 text-gray-500' : 
            status === 'completed' ? 'bg-green-500 text-white' : 
            'bg-blue-500 text-white'
          }`}>
            {level}
          </div>
          <div>
            <h3 className="font-semibold text-lg text-gray-800">{title}</h3>
          </div>
        </div>
        
        <div>
          {status === 'locked' && <Lock size={24} className="text-gray-400" />}
          {status === 'completed' && <CheckCircle size={24} className="text-green-500" />}
        </div>
      </div>
      
      <p className="text-gray-600 text-sm mb-4">{description}</p>
      
      {status !== 'locked' && (
        <div className="flex items-center gap-1">
          {[...Array(totalStars)].map((_, i) => (
            <Star
              key={i}
              size={20}
              className={i < stars ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}
            />
          ))}
          <span className="ml-2 text-sm text-gray-600">{stars}/{totalStars}</span>
        </div>
      )}
      
      <div className="flex gap-2 mt-4">
        {status === 'available' && (
          <button 
            onClick={onStart}
            className="flex-1 bg-blue-500 text-white py-2 rounded-lg font-semibold hover:bg-blue-600 transition-colors"
          >
            {t('subjectView.start')}
          </button>
        )}
        
        {status === 'completed' && (
          <button 
            onClick={onStart}
            className="flex-1 bg-green-500 text-white py-2 rounded-lg font-semibold hover:bg-green-600 transition-colors"
          >
            {t('subjectView.continue')}
          </button>
        )}
        
        {videoUrl && status !== 'locked' && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onWatchVideo?.();
            }}
            className="flex items-center gap-2 px-4 py-2 bg-purple-500 text-white rounded-lg font-semibold hover:bg-purple-600 transition-colors"
          >
            <Video size={18} />
            {t('subjectView.watchVideo')}
          </button>
        )}
      </div>
    </div>
  );
}