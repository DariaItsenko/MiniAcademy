import { createContext, useContext, ReactNode } from 'react';

interface GradeTheme {
  grade: number;
  name: { en: string; uk: string };
  primaryGradient: string;
  secondaryGradient: string;
  cardBorder: string;
  buttonGradient: string;
  accentColor: string;
  backgroundColor: string;
  emoji: string;
  subjectColors: {
    math: string;
    english: string;
    ukrainian: string;
  };
}

export const gradeThemes: Record<number, GradeTheme> = {
  1: {
    grade: 1,
    name: { en: 'Rainbow Dreams', uk: 'Райдужні мрії' },
    primaryGradient: 'from-pink-300 via-purple-300 to-blue-300',
    secondaryGradient: 'from-yellow-300 via-orange-300 to-red-300',
    cardBorder: 'border-pink-400',
    buttonGradient: 'from-pink-500 to-purple-500',
    accentColor: 'text-pink-600',
    backgroundColor: 'bg-gradient-to-br from-pink-200 via-purple-200 to-blue-200',
    emoji: '🌈',
    subjectColors: {
      math: 'from-pink-400 to-pink-600',
      english: 'from-purple-400 to-purple-600',
      ukrainian: 'from-blue-400 to-blue-600'
    }
  },
  2: {
    grade: 2,
    name: { en: 'Sunny Garden', uk: 'Сонячний сад' },
    primaryGradient: 'from-yellow-300 via-green-300 to-teal-300',
    secondaryGradient: 'from-orange-300 via-yellow-300 to-lime-300',
    cardBorder: 'border-yellow-400',
    buttonGradient: 'from-yellow-500 to-green-500',
    accentColor: 'text-yellow-600',
    backgroundColor: 'bg-gradient-to-br from-yellow-200 via-green-200 to-teal-200',
    emoji: '🌻',
    subjectColors: {
      math: 'from-yellow-400 to-yellow-600',
      english: 'from-green-400 to-green-600',
      ukrainian: 'from-teal-400 to-teal-600'
    }
  },
  3: {
    grade: 3,
    name: { en: 'Ocean Adventure', uk: 'Морська пригода' },
    primaryGradient: 'from-cyan-300 via-blue-300 to-indigo-300',
    secondaryGradient: 'from-teal-300 via-cyan-300 to-sky-300',
    cardBorder: 'border-cyan-400',
    buttonGradient: 'from-cyan-500 to-blue-500',
    accentColor: 'text-cyan-600',
    backgroundColor: 'bg-gradient-to-br from-cyan-200 via-blue-200 to-indigo-200',
    emoji: '🌊',
    subjectColors: {
      math: 'from-cyan-400 to-cyan-600',
      english: 'from-blue-400 to-blue-600',
      ukrainian: 'from-indigo-400 to-indigo-600'
    }
  },
  4: {
    grade: 4,
    name: { en: 'Forest Magic', uk: 'Чарівний ліс' },
    primaryGradient: 'from-green-300 via-emerald-300 to-lime-300',
    secondaryGradient: 'from-lime-300 via-green-300 to-teal-300',
    cardBorder: 'border-green-400',
    buttonGradient: 'from-green-500 to-emerald-500',
    accentColor: 'text-green-600',
    backgroundColor: 'bg-gradient-to-br from-green-200 via-emerald-200 to-lime-200',
    emoji: '🌳',
    subjectColors: {
      math: 'from-green-400 to-green-600',
      english: 'from-emerald-400 to-emerald-600',
      ukrainian: 'from-lime-400 to-lime-600'
    }
  },
  5: {
    grade: 5,
    name: { en: 'Cosmic Galaxy', uk: 'Космічна галактика' },
    primaryGradient: 'from-purple-300 via-violet-300 to-fuchsia-300',
    secondaryGradient: 'from-indigo-300 via-purple-300 to-pink-300',
    cardBorder: 'border-purple-400',
    buttonGradient: 'from-purple-500 to-fuchsia-500',
    accentColor: 'text-purple-600',
    backgroundColor: 'bg-gradient-to-br from-purple-200 via-violet-200 to-fuchsia-200',
    emoji: '🌌',
    subjectColors: {
      math: 'from-purple-400 to-purple-600',
      english: 'from-violet-400 to-violet-600',
      ukrainian: 'from-fuchsia-400 to-fuchsia-600'
    }
  }
};

interface ThemeContextType {
  currentTheme: GradeTheme;
  getThemeForGrade: (grade: number) => GradeTheme;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

interface ThemeProviderProps {
  children: ReactNode;
  grade: number;
}

export function ThemeProvider({ children, grade }: ThemeProviderProps) {
  const getThemeForGrade = (gradeNum: number): GradeTheme => {
    return gradeThemes[gradeNum] || gradeThemes[1]; // Default to grade 1 if not found
  };

  const currentTheme = getThemeForGrade(grade);

  return (
    <ThemeContext.Provider value={{ currentTheme, getThemeForGrade }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
}
