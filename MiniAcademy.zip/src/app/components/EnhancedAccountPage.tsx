import { ArrowLeft, Star, Calendar, Award, Camera, ShoppingBag } from 'lucide-react';
import { useState, useRef } from 'react';
import { useLanguage } from '../contexts/LanguageContext';

interface UserProgress {
  math: { levels: Array<{ completed: boolean; stars: number }> };
  english: { levels: Array<{ completed: boolean; stars: number }> };
  ukrainian: { levels: Array<{ completed: boolean; stars: number }> };
}

interface Badge {
  id: string;
  name: string;
  nameUk: string;
  emoji: string;
  description: string;
  descriptionUk: string;
  earned: boolean;
}

interface EnhancedAccountPageProps {
  username: string;
  progress: UserProgress;
  grade: number;
  avatar: string;
  points: number;
  streak: number;
  badges: Badge[];
  profilePhoto: string | null;
  onBack: () => void;
  onGradeChange: (grade: number) => void;
  onAvatarShop: () => void;
  onPhotoUpload: (photo: string) => void;
  equippedItems?: string[];
  ownedItems?: string[];
  parentEmail?: string | null;
  lastReportSent?: string | null;
  onParentEmailUpdate?: (email: string) => void;
  onSendReport?: () => void;
}

export function EnhancedAccountPage({
  username,
  progress,
  grade,
  avatar,
  points,
  streak,
  badges,
  profilePhoto,
  onBack,
  onGradeChange,
  onAvatarShop,
  onPhotoUpload,
  equippedItems,
  ownedItems,
  parentEmail,
  lastReportSent,
  onParentEmailUpdate,
  onSendReport,
}: EnhancedAccountPageProps) {
  const { t, language } = useLanguage();
  const [showGradeSelector, setShowGradeSelector] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const calculateTotalStars = () => {
    let total = 0;
    Object.values(progress).forEach((subject) => {
      subject.levels.forEach((level) => {
        total += level.stars;
      });
    });
    return total;
  };

  const calculateOverallGrade = () => {
    const totalStars = calculateTotalStars();
    const maxPossibleStars = Object.values(progress).reduce(
      (acc, subject) => acc + subject.levels.length * 3,
      0
    );
    const percentage = (totalStars / maxPossibleStars) * 100;

    if (percentage >= 90) return 12;
    if (percentage >= 82) return 11;
    if (percentage >= 74) return 10;
    if (percentage >= 66) return 9;
    if (percentage >= 58) return 8;
    if (percentage >= 50) return 7;
    if (percentage >= 42) return 6;
    if (percentage >= 34) return 5;
    if (percentage >= 26) return 4;
    if (percentage >= 18) return 3;
    if (percentage >= 10) return 2;
    return 1;
  };

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        onPhotoUpload(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const avatarEmojis = {
    boy: '👦',
    girl: '👧',
    cat: '🐱',
    dog: '🐶',
  };

  // Helper functions to get equipped items
  const getEquippedSkin = () => {
    const skinItem = equippedItems?.find(id => id.startsWith('skin-'));
    return skinItem ? skinItem.replace('skin-', '') : 'light';
  };

  const getEquippedHair = () => {
    const shopItems = [
      'curly-blonde', 'curly-brown', 'curly-black', 'long-blonde', 'long-brown', 'long-red', 'short-blue', 'short-pink'
    ];
    return equippedItems?.find(id => shopItems.includes(id)) || 'none';
  };

  const getEquippedClothes = () => {
    const clothesItems = [
      'tshirt-blue', 'tshirt-red', 'dress-pink', 'dress-blue', 'hoodie-green', 'hoodie-pink', 'shirt-blue'
    ];
    return equippedItems?.find(id => clothesItems.includes(id)) || 'none';
  };

  const getEquippedAccessories = () => {
    const accessoryItems = [
      'glasses-round', 'glasses-cool', 'hat-red', 'cap-blue', 'crown-gold', 'backpack-blue'
    ];
    return equippedItems?.filter(id => accessoryItems.includes(id)) || [];
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-200 via-pink-200 to-yellow-200 p-8 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute top-20 right-20 text-7xl opacity-20 animate-pulse">🌟</div>
      <div className="absolute bottom-20 left-20 text-7xl opacity-20 animate-bounce">🏆</div>
      <div className="absolute top-1/2 left-10 text-6xl opacity-20">🎖️</div>

      <div className="max-w-6xl mx-auto relative z-10">
        <button
          onClick={onBack}
          className="flex items-center gap-2 bg-white px-6 py-3 rounded-full shadow-lg hover:shadow-xl transition-all transform hover:scale-105 mb-8 font-bold border-4 border-purple-300"
        >
          <ArrowLeft size={24} />
          {t('account.backToHome')}
        </button>

        {/* Profile Header */}
        <div className="bg-white rounded-3xl shadow-2xl p-8 mb-8 border-8 border-purple-400">
          <div className="flex flex-col md:flex-row items-center gap-8">
            {/* Avatar/Photo Section */}
            <div className="relative">
              {profilePhoto ? (
                <div className="w-40 h-40 rounded-full overflow-hidden border-8 border-yellow-400 shadow-xl">
                  <img src={profilePhoto} alt="Profile" className="w-full h-full object-cover" />
                </div>
              ) : (
                <div className="w-40 h-40 rounded-full bg-gradient-to-br from-purple-400 to-pink-500 flex items-center justify-center border-8 border-yellow-400 shadow-xl">
                  <span className="text-8xl animate-bounce">{avatarEmojis[avatar] || '😊'}</span>
                </div>
              )}
              <button
                onClick={() => fileInputRef.current?.click()}
                className="absolute bottom-0 right-0 bg-blue-500 text-white p-3 rounded-full shadow-lg hover:bg-blue-600 transform hover:scale-110 transition-all"
              >
                <Camera size={20} />
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handlePhotoChange}
                className="hidden"
              />
            </div>

            {/* User Info */}
            <div className="flex-1 text-center md:text-left">
              <h1 className="text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600 mb-2">
                {username}
              </h1>
              <div className="flex flex-wrap gap-4 justify-center md:justify-start mb-4">
                <div className="bg-gradient-to-r from-yellow-200 to-orange-300 px-6 py-3 rounded-full shadow-lg border-4 border-yellow-400">
                  <div className="flex items-center gap-2">
                    <Star className="text-yellow-600" size={24} />
                    <div>
                      <p className="text-xs text-gray-600 font-medium">Points</p>
                      <p className="text-2xl font-bold text-gray-800">{points}</p>
                    </div>
                  </div>
                </div>
                <div className="bg-gradient-to-r from-green-200 to-blue-300 px-6 py-3 rounded-full shadow-lg border-4 border-green-400">
                  <div className="flex items-center gap-2">
                    <Calendar className="text-green-600" size={24} />
                    <div>
                      <p className="text-xs text-gray-600 font-medium">Day Streak</p>
                      <p className="text-2xl font-bold text-gray-800">{streak} 🔥</p>
                    </div>
                  </div>
                </div>
                <div className="bg-gradient-to-r from-pink-200 to-purple-300 px-6 py-3 rounded-full shadow-lg border-4 border-pink-400">
                  <div className="flex items-center gap-2">
                    <Award className="text-purple-600" size={24} />
                    <div>
                      <p className="text-xs text-gray-600 font-medium">Grade</p>
                      <p className="text-2xl font-bold text-gray-800">{calculateOverallGrade()}/12</p>
                    </div>
                  </div>
                </div>
              </div>

              <button
                onClick={onAvatarShop}
                className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-8 py-4 rounded-full shadow-lg hover:shadow-xl transition-all transform hover:scale-105 font-bold text-lg flex items-center gap-2 mx-auto md:mx-0"
              >
                <ShoppingBag size={24} />
                {t('account.avatarShop')} 🛍️
              </button>
            </div>
          </div>
        </div>

        {/* Badges Section */}
        <div className="bg-white rounded-3xl shadow-2xl p-8 mb-8 border-8 border-yellow-400">
          <h2 className="text-3xl font-bold text-gray-800 mb-6 flex items-center gap-3">
            <Award size={36} className="text-yellow-500" />
            {t('account.achievementsAndBadges')}
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {badges.map((badge) => (
              <div 
                key={badge.id} 
                className={`p-4 rounded-2xl shadow-lg transition-all ${
                  badge.earned 
                    ? 'bg-gradient-to-r from-yellow-200 to-orange-200 border-4 border-yellow-400' 
                    : 'bg-gray-200 opacity-60 border-4 border-gray-400'
                }`}
              >
                <div className="flex items-center gap-3">
                  <span className={`text-4xl ${badge.earned ? '' : 'grayscale opacity-50'}`}>
                    {badge.earned ? badge.emoji : '🔒'}
                  </span>
                  <h3 className={`text-xl font-bold ${badge.earned ? 'text-gray-800' : 'text-gray-500'}`}>
                    {language === 'uk' ? badge.nameUk : badge.name}
                  </h3>
                </div>
                <p className={`text-sm font-medium mt-2 ${badge.earned ? 'text-gray-600' : 'text-gray-500'}`}>
                  {language === 'uk' ? badge.descriptionUk : badge.description}
                </p>
                {badge.earned && (
                  <div className="mt-2 text-center">
                    <p className="text-sm text-green-600 font-bold flex items-center justify-center gap-1">
                      <span className="text-2xl">✓</span> {t('account.earned')}
                    </p>
                  </div>
                )}
                {!badge.earned && (
                  <div className="mt-2 text-center">
                    <p className="text-xs text-gray-500 font-medium">🔒 {t('account.locked')}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Progress Section */}
        <div className="bg-white rounded-3xl shadow-2xl p-8 border-8 border-purple-400">
          <h2 className="text-3xl font-bold text-gray-800 mb-6">{t('account.learningProgress')}</h2>
          
          <div className="space-y-6">
            {Object.entries(progress).map(([subject, data]) => {
              const subjectStars = data.levels.reduce((acc, level) => acc + level.stars, 0);
              const maxStars = data.levels.length * 3;
              const percentage = (subjectStars / maxStars) * 100;

              const subjectEmojis = {
                math: '🔢',
                english: '📚',
                ukrainian: '🇺🇦',
              };

              const subjectColors = {
                math: 'from-blue-400 to-blue-600',
                english: 'from-green-400 to-green-600',
                ukrainian: 'from-yellow-400 to-orange-600',
              };

              return (
                <div key={subject} className="bg-gradient-to-r from-purple-50 to-pink-50 p-6 rounded-2xl border-4 border-purple-200">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <span className="text-4xl">{subjectEmojis[subject]}</span>
                      <h3 className="text-2xl font-bold text-gray-800 capitalize">{t(`subject.${subject}`)}</h3>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-gray-600 font-medium">Stars Earned</p>
                      <p className="text-3xl font-bold text-yellow-600">{subjectStars}/{maxStars} ⭐</p>
                    </div>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-6 overflow-hidden border-2 border-gray-300">
                    <div
                      className={`h-full bg-gradient-to-r ${subjectColors[subject]} transition-all duration-500 flex items-center justify-end px-3`}
                      style={{ width: `${percentage}%` }}
                    >
                      <span className="text-white font-bold text-sm">{Math.round(percentage)}%</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Grade Selection */}
          <div className="mt-8 bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-2xl border-4 border-blue-300">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-xl font-bold text-gray-800">{t('account.currentGrade')}</h3>
                <p className="text-3xl font-bold text-purple-600">{t(`grade.${grade}`)}</p>
              </div>
              <button
                onClick={() => setShowGradeSelector(!showGradeSelector)}
                className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-6 py-3 rounded-xl font-bold hover:from-purple-600 hover:to-pink-600 transition-all transform hover:scale-105"
              >
                {t('account.changeGrade')}
              </button>
            </div>
            {showGradeSelector && (
              <div className="grid grid-cols-5 gap-3 mt-4">
                {[1, 2, 3, 4, 5].map((g) => (
                  <button
                    key={g}
                    onClick={() => {
                      onGradeChange(g);
                      setShowGradeSelector(false);
                    }}
                    className={`py-4 rounded-xl font-bold text-xl transition-all transform hover:scale-110 ${
                      grade === g
                        ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white scale-110 shadow-lg'
                        : 'bg-gradient-to-r from-yellow-200 to-orange-200 text-gray-700 hover:from-yellow-300 hover:to-orange-300'
                    }`}
                  >
                    {g}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Parent Email & Progress Reports */}
        <div className="mt-8 bg-white rounded-3xl shadow-2xl p-8 border-8 border-green-400">
          <h2 className="text-3xl font-bold text-gray-800 mb-6 flex items-center gap-3">
            <span className="text-4xl">📧</span>
            Parent Progress Reports
          </h2>
          <div className="space-y-6">
            <div>
              <label className="block text-lg font-bold text-gray-700 mb-2">
                Parent's Email Address
              </label>
              <p className="text-sm text-gray-600 mb-3">
                📨 Weekly progress reports will be sent to this email automatically!
              </p>
              <div className="flex gap-3">
                <input
                  type="email"
                  value={parentEmail || ''}
                  onChange={(e) => onParentEmailUpdate?.(e.target.value)}
                  placeholder="parent@example.com"
                  className="flex-1 px-6 py-4 rounded-xl border-4 border-purple-300 text-lg font-medium focus:outline-none focus:border-purple-500 transition-all"
                />
                <button
                  onClick={onParentEmailUpdate && parentEmail ? () => onParentEmailUpdate(parentEmail) : undefined}
                  disabled={!parentEmail || !parentEmail.includes('@')}
                  className={`px-8 py-4 rounded-xl font-bold text-lg shadow-lg transition-all transform hover:scale-105 ${
                    parentEmail && parentEmail.includes('@')
                      ? 'bg-gradient-to-r from-green-500 to-blue-500 text-white hover:shadow-xl'
                      : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  }`}
                >
                  💾 Save
                </button>
              </div>
            </div>

            {parentEmail && parentEmail.includes('@') && (
              <div className="bg-gradient-to-r from-green-50 to-blue-50 p-6 rounded-2xl border-4 border-green-300">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-gray-800 mb-2 flex items-center gap-2">
                      <span className="text-2xl">✅</span>
                      Email Configured
                    </h3>
                    <p className="text-gray-700 font-medium mb-2">
                      Reports will be sent to: <span className="font-bold text-purple-600">{parentEmail}</span>
                    </p>
                    {lastReportSent && (
                      <p className="text-sm text-gray-600">
                        📅 Last report sent: {new Date(lastReportSent).toLocaleDateString()}
                      </p>
                    )}
                  </div>
                  <button
                    onClick={onSendReport}
                    className="bg-gradient-to-r from-blue-500 to-purple-500 text-white px-8 py-4 rounded-xl font-bold text-lg shadow-lg hover:shadow-xl transition-all transform hover:scale-105 whitespace-nowrap"
                  >
                    📤 Send Report Now
                  </button>
                </div>
                <div className="mt-4 bg-white p-4 rounded-xl">
                  <p className="text-sm font-bold text-gray-700 mb-2">📊 Report includes:</p>
                  <ul className="text-sm text-gray-600 space-y-1 ml-4">
                    <li>✨ Total stars earned: {calculateTotalStars()}</li>
                    <li>📈 Overall grade: {calculateOverallGrade()}/12</li>
                    <li>🔥 Current streak: {streak} days</li>
                    <li>💎 Points earned: {points}</li>
                    <li>📚 Progress in all subjects</li>
                    <li>🏆 Achievements & badges earned</li>
                  </ul>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}