import { useState, useEffect, Component, ReactNode } from 'react';
import { EmojiAvatar } from './EmojiAvatar';

interface AvatarWrapperProps {
  baseAvatar: string;
  skinTone?: string;
  hair?: string;
  clothes?: string;
  accessories?: string[];
  size?: 'small' | 'medium' | 'large';
  autoRotate?: boolean;
  previewItem?: string | null;
  showRotation?: boolean;
  animated?: boolean;
}

// Error Boundary for 3D Avatar
class Avatar3DErrorBoundary extends Component<
  { children: ReactNode; fallback: ReactNode },
  { hasError: boolean }
> {
  constructor(props: any) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error: any) {
    console.warn('3D Avatar failed to load, using 2D fallback:', error);
  }

  render() {
    if (this.state.hasError) {
      return this.props.fallback;
    }
    return this.props.children;
  }
}

// Main Avatar Wrapper - Now uses Emoji-based avatars
export function AvatarWrapper(props: AvatarWrapperProps) {
  return (
    <div className="relative">
      {/* Use emoji-based avatars that look like real game characters */}
      <EmojiAvatar
        baseAvatar={props.baseAvatar}
        size={props.size}
        showRotation={props.showRotation ?? false}
        animated={props.animated ?? true}
        accessories={props.accessories || []}
      />
    </div>
  );
}